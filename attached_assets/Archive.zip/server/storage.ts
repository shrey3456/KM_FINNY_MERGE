import { 
  users, type User, type InsertUser,
  products, type Product, type InsertProduct,
  scanHistory, type ScanHistory, type InsertScanHistory,
  loadingOperations, type LoadingOperation, type InsertLoadingOperation,
  loadingOpItems, type LoadingOpItem, type InsertLoadingOpItem,
  purchases, type Purchase, type InsertPurchase,
  sales, type Sale, type InsertSale,
  saleItems, type SaleItem, type InsertSaleItem,
  proformaSlips, type ProformaSlip, type InsertProformaSlip,
  proformaSlipItems, type ProformaSlipItem, type InsertProformaSlipItem,
  backupSettings, type BackupSettings, type InsertBackupSettings,
  scanHistoryBackup, type ScanHistoryBackup,
  loadingOpItemsBackup, type LoadingOpItemBackup,
  salesBackup, type SaleBackup,
  proformaSlipsBackup, type ProformaSlipBackup,
  proformaSlipItemsBackup, type ProformaSlipItemBackup,
  messages, type Message, type InsertMessage,
  activities, type Activity, type InsertActivity,
  vehicleInfo, type VehicleInfo, type InsertVehicleInfo
} from "@shared/schema";
import { and, gte, lte, lt, eq, asc, desc, sql, like, or, isNull, isNotNull, inArray } from "drizzle-orm";
import nodePersist from 'node-persist';
import { db } from "./db";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  updateUserPin(id: number, pin: string): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  listUsers(limit?: number, offset?: number): Promise<User[]>;
  getAllUsers(): Promise<User[]>; // Get all users without pagination

  // Product operations
  getProduct(id: number): Promise<Product | undefined>;
  getProductByBarcode(barcode: string): Promise<Product | undefined>;
  getProductsByIds(ids: number[]): Promise<Product[]>; // Batch get products by IDs
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  listProducts(limit?: number, offset?: number): Promise<Product[]>;
  getAllProducts(): Promise<Product[]>; // Get all products without pagination
  clearInventory(): Promise<void>; // Method to clear all inventory data
  resetInventoryStock(): Promise<number>; // Method to reset all inStock values to zero

  // Scan history operations
  createScanHistory(entry: InsertScanHistory): Promise<ScanHistory>;
  getScanHistory(id: number): Promise<ScanHistory | undefined>;
  deleteScanHistory(id: number): Promise<boolean>;
  listScanHistory(limit?: number, offset?: number): Promise<ScanHistory[]>;

  // Loading operations
  createLoadingOperation(operation: InsertLoadingOperation): Promise<LoadingOperation>;
  getLoadingOperation(id: number): Promise<LoadingOperation | undefined>;
  getLoadingOperationByReferenceNumber(referenceNumber: string): Promise<LoadingOperation | undefined>;
  updateLoadingOperation(id: number, operation: Partial<InsertLoadingOperation>): Promise<LoadingOperation | undefined>;
  deleteLoadingOperation(id: number): Promise<boolean>;
  listLoadingOperations(limit?: number, offset?: number, startDate?: Date, endDate?: Date, orderDate?: Date): Promise<LoadingOperation[]>;
  countLoadingOperationsByStatus(status: string, orderDate?: Date): Promise<number>;
  // For backward compatibility, keep this method but implement it to call getLoadingOperationItems
  getGJOperationItems(loadingOperationId: number): Promise<LoadingOpItem[]>;

  // Purchase operations
  createPurchase(purchase: InsertPurchase): Promise<Purchase>;
  getPurchase(id: number): Promise<Purchase | undefined>;
  updatePurchase(id: number, purchase: Partial<InsertPurchase>): Promise<Purchase | undefined>;
  deletePurchase(id: number): Promise<boolean>;
  listPurchases(limit?: number, offset?: number): Promise<Purchase[]>;

  // Sales operations
  createSale(sale: InsertSale): Promise<Sale>;
  getSale(id: number): Promise<Sale | undefined>;
  updateSale(id: number, sale: Partial<InsertSale>): Promise<Sale | undefined>;
  deleteSale(id: number): Promise<boolean>;
  listSales(limit?: number, offset?: number): Promise<Sale[]>;

  // Sale items operations (not stored in database, but in memory)
  setSaleItems(saleId: number, items: any[]): Promise<void>;
  getSaleItems(saleId: number): Promise<any[]>;
  deleteSaleItems(saleId: number): Promise<boolean>;

  // Proforma Slip operations
  createProformaSlip(slip: InsertProformaSlip): Promise<ProformaSlip>;
  getProformaSlip(id: number): Promise<ProformaSlip | undefined>;
  getProformaSlipByOrderNumber(orderNumber: string): Promise<ProformaSlip | undefined>;
  getProformaSlipsByOrderNumbers(orderNumbers: string[]): Promise<ProformaSlip[]>;
  updateProformaSlip(id: number, slip: Partial<InsertProformaSlip>): Promise<ProformaSlip | undefined>;
  deleteProformaSlip(id: number): Promise<boolean>;
  listProformaSlips(limit?: number, offset?: number): Promise<ProformaSlip[]>;

  // Proforma Slip Item operations
  createProformaSlipItem(item: InsertProformaSlipItem): Promise<ProformaSlipItem>;
  getProformaSlipItems(proformaSlipId: number): Promise<ProformaSlipItem[]>;
  getProformaSlipItemsByIds(itemIds: number[]): Promise<ProformaSlipItem[]>;
  getProformaSlipItem(id: number): Promise<ProformaSlipItem | undefined>;
  updateProformaSlipItem(id: number, item: Partial<InsertProformaSlipItem>): Promise<ProformaSlipItem | undefined>;
  deleteProformaSlipItem(id: number): Promise<boolean>;

  // Backup operations
  getBackupSettings(): Promise<BackupSettings | undefined>;
  createBackupSettings(settings: InsertBackupSettings): Promise<BackupSettings>;
  updateBackupSettings(id: number, settings: Partial<InsertBackupSettings>): Promise<BackupSettings | undefined>;

  // Backup retrieval operations for historical data
  backupScanHistory(scanHistoryId: number): Promise<ScanHistoryBackup>;
  backupSale(saleId: number): Promise<SaleBackup>;
  backupProformaSlip(proformaSlipId: number): Promise<ProformaSlipBackup>;
  backupProformaSlipItem(slipItemId: number, proformaSlipBackupId: number): Promise<ProformaSlipItemBackup>;

  // List historical data with date filtering
  listScanHistoryBackups(startDate?: Date, endDate?: Date, limit?: number, offset?: number): Promise<ScanHistoryBackup[]>;
  listSaleBackups(startDate?: Date, endDate?: Date, limit?: number, offset?: number): Promise<SaleBackup[]>;
  listProformaSlipBackups(startDate?: Date, endDate?: Date, limit?: number, offset?: number): Promise<ProformaSlipBackup[]>;
  listProformaSlipItemBackups(proformaSlipBackupId: number): Promise<ProformaSlipItemBackup[]>;

  // Backup items operations
  getSaleBackupItems(backupId: number): Promise<any[]>;
  deleteProformaSlipBackup(backupId: number): Promise<boolean>;
  deleteProformaSlipBackups(backupIds: number[]): Promise<number>;

  // Run a backup operation to move all non-backed up records to backup tables
  runBackupOperation(): Promise<{
    scansBackedUp: number,
    salesBackedUp: number,
    proformaSlipsBackedUp: number
  }>;

  // Apply data retention policies
  applyDataRetentionPolicies(): Promise<{
    loadingOpsDeleted: number
  }>;

  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessage(id: number): Promise<Message | undefined>;
  updateMessage(id: number, message: Partial<InsertMessage>): Promise<Message | undefined>;
  deleteMessage(id: number): Promise<boolean>;
  listMessages(limit?: number, offset?: number): Promise<Message[]>;

  // Get messages for a specific user (as recipient or from broadcasts)
  getMessagesForUser(userId: number, limit?: number, offset?: number): Promise<Message[]>;

  // Get conversations between users
  getConversation(user1Id: number, user2Id: number, limit?: number, offset?: number): Promise<Message[]>;

  // Mark message as read
  markMessageAsRead(id: number): Promise<Message | undefined>;

  // Get unread message count for a user
  getUnreadMessageCount(userId: number): Promise<number>;

  // Activity tracking operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  logActivity(activity: {
    pageName: string;
    action: string;
    entityType: string;
    entityId: string | number;
    details: string | object;
    userId?: number;
    userName?: string;
  }): Promise<Activity>;
  getActivity(id: number): Promise<Activity | undefined>;
  deleteActivity(id: number): Promise<boolean>;
  listActivities(limit?: number, offset?: number): Promise<Activity[]>;
  getActivitiesByPage(pageName: string, limit?: number, offset?: number): Promise<Activity[]>;
  getActivitiesByAction(action: string, limit?: number, offset?: number): Promise<Activity[]>;
  getEntityActivities(entityType: string, entityId: string, limit?: number): Promise<Activity[]>;
  // Delete activities older than 30 days
  deleteOldActivities(daysToKeep?: number): Promise<number>;
  // Delete test activities (pageName="Test")
  deleteTestActivities(): Promise<number>;

  // Vehicle Info operations
  createVehicleInfo(vehicle: InsertVehicleInfo): Promise<VehicleInfo>;
  getVehicleInfo(id: number): Promise<VehicleInfo | undefined>;
  getVehicleInfoByVehicleNumber(vehicleNumber: string): Promise<VehicleInfo | undefined>;
  updateVehicleInfo(id: number, vehicle: Partial<InsertVehicleInfo>): Promise<VehicleInfo | undefined>;
  deleteVehicleInfo(id: number): Promise<boolean>;
  listVehicleInfo(limit?: number, offset?: number): Promise<VehicleInfo[]>;
}

export class MemStorage implements IStorage {
  // Session store for authentication
  public sessionStore: session.Store;
  
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private scans: Map<number, ScanHistory>;
  private loadingOps: Map<number, LoadingOperation>;
  private gjOperationItems: Map<number, LoadingOpItem[]>; // Map loadingOpId to items
  private purchases: Map<number, Purchase>;
  private sales: Map<number, Sale>;
  private proformaSlips: Map<number, ProformaSlip>;
  private proformaSlipItems: Map<number, ProformaSlipItem>;

  // Sale items (not in database schema, stored in memory)
  private saleItems: Map<number, any[]>;

  // Backup data storage
  private backupSettings: Map<number, BackupSettings>;
  private scanHistoryBackups: Map<number, ScanHistoryBackup>;
  private loadingOpBackups: Map<number, LoadingOperationBackup>;
  private saleBackups: Map<number, SaleBackup>;
  private saleBackupItems: Map<number, any[]>; // Items for backed up sales
  private loadingOpBackupItems: Map<number, any[]>; // Items for backed up loading operations

  private userId: number;
  private productId: number;
  private scanId: number;
  private loadingOpId: number;
  private purchaseId: number;
  private saleId: number;
  private proformaSlipId: number;
  private proformaSlipItemId: number;
  private vehicleInfoId: number;

  // Backup data IDs
  private backupSettingsId: number;
  private scanHistoryBackupId: number;
  private loadingOpBackupId: number;
  private saleBackupId: number;
  private proformaSlipBackupId: number;
  private proformaSlipItemBackupId: number;

  // Messages
  private messages: Map<number, Message>;
  private messageId: number;

  // Activities
  private activities: Map<number, Activity>;
  private activityId: number;

  private initialized: boolean = false;

  constructor() {
    // Initialize session store for authentication
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    this.users = new Map();
    this.products = new Map();
    this.scans = new Map();
    this.loadingOps = new Map();
    this.gjOperationItems = new Map();
    this.purchases = new Map();
    this.sales = new Map();
    this.proformaSlips = new Map();
    this.proformaSlipItems = new Map();

    // Initialize sale items map
    this.saleItems = new Map();

    // Initialize backup storage maps
    this.backupSettings = new Map();
    this.scanHistoryBackups = new Map();
    this.loadingOpBackups = new Map();
    this.saleBackups = new Map();
    this.saleBackupItems = new Map();
    this.loadingOpBackupItems = new Map();
    this.proformaSlipBackups = new Map();
    this.proformaSlipItemBackups = new Map();

    // Initialize messages map
    this.messages = new Map();

    // Initialize activities map
    this.activities = new Map();

    this.userId = 1;
    this.productId = 1;
    this.scanId = 1;
    this.loadingOpId = 1;
    this.purchaseId = 1;
    this.saleId = 1;
    this.proformaSlipId = 1;
    this.proformaSlipItemId = 1;
    this.vehicleInfoId = 1;

    // Initialize backup IDs
    this.backupSettingsId = 1;
    this.scanHistoryBackupId = 1;
    this.loadingOpBackupId = 1;
    this.saleBackupId = 1;
    this.proformaSlipBackupId = 1;
    this.proformaSlipItemBackupId = 1;

    // Initialize message ID
    this.messageId = 1;

    // Initialize activity ID
    this.activityId = 1;

    // Initialize persistent storage
    this.init();
  }

  private async init() {
    try {
      await nodePersist.init({
        dir: './.data',
        stringify: JSON.stringify,
        parse: JSON.parse,
        encoding: 'utf8',
        logging: false,
        forgiveParseErrors: true // Enable forgiveness for parse errors
      });

      // Helper function to safely retrieve items
      const safeGetItem = async (key: string) => {
        try {
          return await nodePersist.getItem(key) || [];
        } catch (error) {
          console.error(`Error retrieving ${key}, initializing as empty array:`, error);
          // If the item can't be retrieved, reset it to avoid future errors
          await nodePersist.setItem(key, []);
          return [];
        }
      };

      // Load saved data with error handling
      const savedUsers = await safeGetItem('users');
      const savedProducts = await safeGetItem('products');
      const savedScans = await safeGetItem('scans');
      const savedLoadingOps = await safeGetItem('loadingOps');
      const savedPurchases = await safeGetItem('purchases');
      const savedSales = await safeGetItem('sales');
      const savedProformaSlips = await safeGetItem('proformaSlips');
      const savedProformaSlipItems = await safeGetItem('proformaSlipItems');
      const savedSaleItems = await safeGetItem('saleItems');
      const savedMessages = await safeGetItem('messages');
      const savedActivities = await safeGetItem('activities');

      // Load backup data with error handling
      const savedBackupSettings = await safeGetItem('backupSettings');
      const savedScanHistoryBackups = await safeGetItem('scanHistoryBackups');
      const savedLoadingOpBackups = await safeGetItem('loadingOpBackups');
      const savedSaleBackups = await safeGetItem('saleBackups');
      const savedSaleBackupItems = await safeGetItem('saleBackupItems');
      const savedLoadingOpBackupItems = await safeGetItem('loadingOpBackupItems');
      const savedProformaSlipBackups = await safeGetItem('proformaSlipBackups'); 
      const savedProformaSlipItemBackups = await safeGetItem('proformaSlipItemBackups');

      // Helper function to safely get counter values with data integrity check
      const safeGetCounter = async (key: string, data: any[]) => {
        try {
          const value = await nodePersist.getItem(key);
          if (value !== null && value !== undefined && !isNaN(Number(value))) {
            // Get the maximum ID from actual data to ensure counter is at least that high
            const maxId = data.length > 0 ? Math.max(...data.map(item => item.id || 0)) : 0;
            // Use the higher value of stored counter or highest ID + 1
            return Math.max(Number(value), maxId + 1);
          }

          // If counter not found or invalid, calculate from data
          const maxId = data.length > 0 ? Math.max(...data.map(item => item.id || 0)) : 0;
          return Math.max(1, maxId + 1); // Ensure at least 1
        } catch (error) {
          console.error(`Error retrieving counter ${key}, calculating from data:`, error);
          // Calculate safe starting value from data
          const maxId = data.length > 0 ? Math.max(...data.map(item => item.id || 0)) : 0;
          const safeCounter = Math.max(1, maxId + 1);

          // Update the counter in storage
          await nodePersist.setItem(key, safeCounter);
          return safeCounter;
        }
      };

      // Load counters safely with data integrity checks
      this.userId = await safeGetCounter('userId', savedUsers);
      this.productId = await safeGetCounter('productId', savedProducts);
      this.scanId = await safeGetCounter('scanId', savedScans);
      this.loadingOpId = await safeGetCounter('loadingOpId', savedLoadingOps);
      this.purchaseId = await safeGetCounter('purchaseId', savedPurchases);
      this.saleId = await safeGetCounter('saleId', savedSales);
      this.proformaSlipId = await safeGetCounter('proformaSlipId', savedProformaSlips);
      this.proformaSlipItemId = await safeGetCounter('proformaSlipItemId', savedProformaSlipItems);
      this.messageId = await safeGetCounter('messageId', savedMessages);

      // Load backup counters safely
      this.backupSettingsId = await safeGetCounter('backupSettingsId', savedBackupSettings);
      this.scanHistoryBackupId = await safeGetCounter('scanHistoryBackupId', savedScanHistoryBackups);
      this.loadingOpBackupId = await safeGetCounter('loadingOpBackupId', savedLoadingOpBackups);
      this.saleBackupId = await safeGetCounter('saleBackupId', savedSaleBackups);
      this.proformaSlipBackupId = await safeGetCounter('proformaSlipBackupId', savedProformaSlipBackups);
      this.proformaSlipItemBackupId = await safeGetCounter('proformaSlipItemBackupId', savedProformaSlipItemBackups);

      // Populate maps
      savedUsers.forEach((user: User) => this.users.set(user.id, user));
      savedProducts.forEach((product: Product) => this.products.set(product.id, product));
      savedScans.forEach((scan: ScanHistory) => this.scans.set(scan.id, scan));
      savedLoadingOps.forEach((op: LoadingOperation) => this.loadingOps.set(op.id, op));
      savedPurchases.forEach((purchase: Purchase) => this.purchases.set(purchase.id, purchase));
      savedSales.forEach((sale: Sale) => this.sales.set(sale.id, sale));
      savedProformaSlips.forEach((slip: ProformaSlip) => this.proformaSlips.set(slip.id, slip));
      savedProformaSlipItems.forEach((item: ProformaSlipItem) => this.proformaSlipItems.set(item.id, item));

      // Initialize saleItems map from saved data
      if (savedSaleItems && savedSaleItems.length > 0) {
        for (const [savedSaleId, savedItems] of savedSaleItems) {
          this.saleItems.set(parseInt(savedSaleId), savedItems);
        }
      }

      // Initialize saleBackupItems map from saved data
      if (savedSaleBackupItems && savedSaleBackupItems.length > 0) {
        for (const [savedBackupId, savedItems] of savedSaleBackupItems) {
          this.saleBackupItems.set(parseInt(savedBackupId), savedItems);
        }
      }

      // Initialize loadingOpBackupItems map from saved data
      if (savedLoadingOpBackupItems && savedLoadingOpBackupItems.length > 0) {
        for (const [savedBackupId, savedItems] of savedLoadingOpBackupItems) {
          this.loadingOpBackupItems.set(parseInt(savedBackupId), savedItems);
        }
      }

      // Populate backup maps
      savedBackupSettings.forEach((settings: BackupSettings) => this.backupSettings.set(settings.id, settings));
      savedScanHistoryBackups.forEach((backup: ScanHistoryBackup) => this.scanHistoryBackups.set(backup.id, backup));
      savedLoadingOpBackups.forEach((backup: LoadingOperationBackup) => this.loadingOpBackups.set(backup.id, backup));
      savedSaleBackups.forEach((backup: SaleBackup) => this.saleBackups.set(backup.id, backup));
      savedProformaSlipBackups.forEach((backup: ProformaSlipBackup) => this.proformaSlipBackups.set(backup.id, backup));
      savedProformaSlipItemBackups.forEach((backup: ProformaSlipItemBackup) => this.proformaSlipItemBackups.set(backup.id, backup));

      // Populate messages map
      savedMessages.forEach((message: Message) => this.messages.set(message.id, message));

      // Add default admin user if no users exist
      if (this.users.size === 0) {
        await this.createUser({
          username: "vraj@km-tribe",
          pin: "9999", // PIN set to 9999 as required
          name: "Vraj", 
          firstName: null,
          lastName: null,
          designation: null,
          department: "Management",
          accessType: null,
          role: "admin"
        });
      }

      // Create default backup settings if none exist
      if (this.backupSettings.size === 0) {
        const backupSettingsId = this.backupSettingsId++;
        const now = new Date();

        const backupSettings: BackupSettings = {
          id: backupSettingsId,
          lastBackupDate: now,
          autoBackupEnabled: true,
          backupFrequencyHours: 24,
          createdAt: now,
          updatedAt: now
        };

        this.backupSettings.set(backupSettingsId, backupSettings);
        await this.persistBackupSettings();
      }

      this.initialized = true;
      console.log('Storage initialized with persistent data');
    } catch (error) {
      console.error('Error initializing storage:', error);
    }
  }

  private async persistUsers() {
    await nodePersist.setItem('users', Array.from(this.users.values()));
    await nodePersist.setItem('userId', this.userId);
  }

  private async persistProducts() {
    await nodePersist.setItem('products', Array.from(this.products.values()));
    await nodePersist.setItem('productId', this.productId);
  }

  private async persistScans() {
    await nodePersist.setItem('scans', Array.from(this.scans.values()));
    await nodePersist.setItem('scanId', this.scanId);
  }

  private async persistLoadingOps() {
    await nodePersist.setItem('loadingOps', Array.from(this.loadingOps.values()));
    await nodePersist.setItem('loadingOpId', this.loadingOpId);
  }

  private async persistPurchases() {
    await nodePersist.setItem('purchases', Array.from(this.purchases.values()));
    await nodePersist.setItem('purchaseId', this.purchaseId);
  }

  private async persistSales() {
    await nodePersist.setItem('sales', Array.from(this.sales.values()));
    await nodePersist.setItem('saleId', this.saleId);
  }

  private async persistProformaSlips() {
    await nodePersist.setItem('proformaSlips', Array.from(this.proformaSlips.values()));
    await nodePersist.setItem('proformaSlipId', this.proformaSlipId);
  }

  private async persistProformaSlipItems() {
    await nodePersist.setItem('proformaSlipItems', Array.from(this.proformaSlipItems.values()));
    await nodePersist.setItem('proformaSlipItemId', this.proformaSlipItemId);
  }

  // Backup data persistence methods
  private async persistBackupSettings() {
    await nodePersist.setItem('backupSettings', Array.from(this.backupSettings.values()));
    await nodePersist.setItem('backupSettingsId', this.backupSettingsId);
  }

  private async persistScanHistoryBackups() {
    await nodePersist.setItem('scanHistoryBackups', Array.from(this.scanHistoryBackups.values()));
    await nodePersist.setItem('scanHistoryBackupId', this.scanHistoryBackupId);
  }

  private async persistLoadingOpBackups() {
    await nodePersist.setItem('loadingOpBackups', Array.from(this.loadingOpBackups.values()));
    await nodePersist.setItem('loadingOpBackupId', this.loadingOpBackupId);
  }

  private async persistSaleBackups() {
    await nodePersist.setItem('saleBackups', Array.from(this.saleBackups.values()));
    await nodePersist.setItem('saleBackupId', this.saleBackupId);
  }

  private async persistSaleBackupItems() {
    // Convert Map to array format for storage
    const saleBackupItemsArray = Array.from(this.saleBackupItems.entries());
    await nodePersist.setItem('saleBackupItems', saleBackupItemsArray);
  }

  private async persistLoadingOpBackupItems() {
    // Convert Map to array format for storage
    const loadingOpBackupItemsArray = Array.from(this.loadingOpBackupItems.entries());
    await nodePersist.setItem('loadingOpBackupItems', loadingOpBackupItemsArray);
  }

  private async persistProformaSlipBackups() {
    await nodePersist.setItem('proformaSlipBackups', Array.from(this.proformaSlipBackups.values()));
    await nodePersist.setItem('proformaSlipBackupId', this.proformaSlipBackupId);
  }

  private async persistProformaSlipItemBackups() {
    await nodePersist.setItem('proformaSlipItemBackups', Array.from(this.proformaSlipItemBackups.values()));
    await nodePersist.setItem('proformaSlipItemBackupId', this.proformaSlipItemBackupId);
  }

  private async persistMessages() {
    await nodePersist.setItem('messages', Array.from(this.messages.values()));
    await nodePersist.setItem('messageId', this.messageId);
  }

  private async persistActivities() {
    await nodePersist.setItem('activities', Array.from(this.activities.values()));
    await nodePersist.setItem('activityId', this.activityId);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    // Convert any undefined values to null
    const processedInsertUser = Object.fromEntries(
      Object.entries(insertUser).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const user: User = { ...processedInsertUser as any, id };
    this.users.set(id, user);

    // Persist to storage
    await this.persistUsers();

    return user;
  }

  async updateUser(id: number, userUpdate: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;

    // Convert any undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(userUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedUser = {
      ...existingUser,
      ...processedUpdate,
    };

    this.users.set(id, updatedUser);

    // Persist to storage
    await this.persistUsers();

    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = this.users.delete(id);

    // Persist to storage
    if (result) {
      await this.persistUsers();
    }

    return result;
  }

  async listUsers(limit = 10, offset = 0): Promise<User[]> {
    return Array.from(this.users.values())
      .slice(offset, offset + limit);
  }

  // Product operations
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductByBarcode(barcode: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.barcode === barcode,
    );
  }

  async getProductsByIds(ids: number[]): Promise<Product[]> {
    if (!ids || ids.length === 0) return [];
    
    const foundProducts: Product[] = [];
    
    for (const id of ids) {
      const product = this.products.get(id);
      if (product) {
        foundProducts.push(product);
      }
    }
    
    return foundProducts;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const now = new Date();

    // Convert undefined values to null
    const processedProduct = Object.fromEntries(
      Object.entries(insertProduct).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const product: Product = { 
      ...processedProduct as any,
      id,
      createdAt: now,
      updatedAt: now // Add the required updatedAt field
    };

    this.products.set(id, product);

    // Persist to storage
    await this.persistProducts();

    return product;
  }

  async updateProduct(id: number, productUpdate: Partial<InsertProduct>): Promise<Product | undefined> {
    const existingProduct = this.products.get(id);
    if (!existingProduct) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(productUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedProduct = {
      ...existingProduct,
      ...processedUpdate,
      updatedAt: new Date() // Update the updatedAt field
    };

    this.products.set(id, updatedProduct);

    // Persist to storage
    await this.persistProducts();

    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = this.products.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistProducts();
    }

    return result;
  }

  async listProducts(limit = 10, offset = 0): Promise<Product[]> {
    return Array.from(this.products.values())
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  // Scan history operations
  async createScanHistory(insertScan: InsertScanHistory): Promise<ScanHistory> {
    const id = this.scanId++;
    const now = new Date();

    // Convert undefined values to null
    const processedScan = Object.fromEntries(
      Object.entries(insertScan).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const scan: ScanHistory = {
      ...processedScan as any,
      id,
      scannedAt: now,
    };

    this.scans.set(id, scan);

    // Persist to storage
    await this.persistScans();

    return scan;
  }

  async getScanHistory(id: number): Promise<ScanHistory | undefined> {
    return this.scans.get(id);
  }

  async deleteScanHistory(id: number): Promise<boolean> {
    const result = this.scans.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistScans();
    }

    return result;
  }

  async listScanHistory(limit = 10, offset = 0): Promise<ScanHistory[]> {
    return Array.from(this.scans.values())
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.scannedAt instanceof Date ? a.scannedAt : a.scannedAt ? new Date(a.scannedAt) : null;
        const dateB = b.scannedAt instanceof Date ? b.scannedAt : b.scannedAt ? new Date(b.scannedAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  // Loading operations
  async createLoadingOperation(insertOperation: InsertLoadingOperation): Promise<LoadingOperation> {
    const id = this.loadingOpId++;
    const now = new Date();

    // Convert undefined values to null
    const processedOperation = Object.fromEntries(
      Object.entries(insertOperation).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const operation: LoadingOperation = {
      ...processedOperation as any,
      id,
      createdAt: now,
      completedAt: null,
    };

    this.loadingOps.set(id, operation);

    // Persist to storage
    await this.persistLoadingOps();

    return operation;
  }

  async getLoadingOperation(id: number): Promise<LoadingOperation | undefined> {
    return this.loadingOps.get(id);
  }

  async getLoadingOperationByReferenceNumber(referenceNumber: string): Promise<LoadingOperation| undefined> {
    return Array.from(this.loadingOps.values()).find(
      (operation) => operation.referenceNumber === referenceNumber
    );
  }

  async updateLoadingOperation(id: number, operationUpdate: Partial<InsertLoadingOperation>): Promise<LoadingOperation | undefined> {
    const existingOperation = this.loadingOps.get(id);
    if (!existingOperation) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(operationUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedOperation = {
      ...existingOperation,
      ...processedUpdate,
    };

    this.loadingOps.set(id, updatedOperation);

    // Persist to storage
    await this.persistLoadingOps();

    return updatedOperation;
  }

  async deleteLoadingOperation(id: number): Promise<boolean> {
    const result = this.loadingOps.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistLoadingOps();
    }

    return result;
  }

  async listLoadingOperations(limit = 10, offset = 0, startDate?: Date, endDate?: Date): Promise<LoadingOperation[]> {
    let loadingOperations = Array.from(this.loadingOps.values());

    // Apply date filtering if specified
    if (startDate && endDate) {
      loadingOperations = loadingOperations.filter(op => {
        const opDate = op.createdAt instanceof Date ? op.createdAt : op.createdAt ? new Date(op.createdAt) : null;
        if (!opDate) return false;

        return opDate >= startDate && opDate <= endDate;
      });
    }

    return loadingOperations
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  async countLoadingOperationsByStatus(status: string): Promise<number> {
    return Array.from(this.loadingOps.values())
      .filter(op => op.status === status)
      .length;
  }

  async getGJOperationItems(loadingOperationId: number): Promise<LoadingOpItem[]> {
    // Return items for the specified GJ operation from the gjOperationItems map
    // If no items found, return an empty array
    return this.gjOperationItems.get(loadingOperationId) || [];
  }

  // Purchase operations
  async createPurchase(insertPurchase: InsertPurchase): Promise<Purchase> {
    const id = this.purchaseId++;
    const now = new Date();

    // Convert undefined values to null
    const processedPurchase = Object.fromEntries(
      Object.entries(insertPurchase).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const purchase: Purchase = {
      ...processedPurchase as any,
      id,
      createdAt: now,
    };

    this.purchases.set(id, purchase);

    // Persist to storage
    await this.persistPurchases();

    return purchase;
  }

  async getPurchase(id: number): Promise<Purchase | undefined> {
    return this.purchases.get(id);
  }

  async updatePurchase(id: number, purchaseUpdate: Partial<InsertPurchase>): Promise<Purchase | undefined> {
    const existingPurchase = this.purchases.get(id);
    if (!existingPurchase) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(purchaseUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedPurchase = {
      ...existingPurchase,
      ...processedUpdate,
    };

    this.purchases.set(id, updatedPurchase);

    // Persist to storage
    await this.persistPurchases();

    return updatedPurchase;
  }

  async deletePurchase(id: number): Promise<boolean> {
    const result = this.purchases.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistPurchases();
    }

    return result;
  }

  async listPurchases(limit = 10, offset = 0): Promise<Purchase[]> {
    return Array.from(this.purchases.values())
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  // Sales operations
  async createSale(insertSale: InsertSale): Promise<Sale> {
    const id = this.saleId++;
    const now = new Date();

    // Convert undefined values to null
    const processedSale = Object.fromEntries(
      Object.entries(insertSale).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const sale: Sale = {
      ...processedSale as any,
      id,
      createdAt: now,
    };

    this.sales.set(id, sale);

    // Persist to storage
    await this.persistSales();

    return sale;
  }

  async getSale(id: number): Promise<Sale | undefined> {
    return this.sales.get(id);
  }

  async updateSale(id: number, saleUpdate: Partial<InsertSale>): Promise<Sale | undefined> {
    const existingSale = this.sales.get(id);
    if (!existingSale) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(saleUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedSale = {
      ...existingSale,
      ...processedUpdate,
    };

    this.sales.set(id, updatedSale);

    // Persist to storage
    await this.persistSales();

    return updatedSale;
  }

  async deleteSale(id: number): Promise<boolean> {
    const result = this.sales.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistSales();
    }

    return result;
  }

  async listSales(limit = 10, offset = 0): Promise<Sale[]> {
    return Array.from(this.sales.values())
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  // Sale items operations
  async setSaleItems(saleId: number, items: any[]): Promise<void> {
    // Store the items for this sale
    this.saleItems.set(saleId, items);

    // Persist to storage
    await nodePersist.setItem('saleItems', Array.from(this.saleItems.entries()));
  }

  async getSaleItems(saleId: number): Promise<any[]> {
    // Retrieve and load sale items if needed
    if (!this.saleItems.has(saleId)) {
      // Try to load from persistent storage
      const savedSaleItems = await nodePersist.getItem('saleItems') || [];

      // Initialize the sale items map from stored data
      if (savedSaleItems && savedSaleItems.length > 0) {
        for (const [savedSaleId, savedItems] of savedSaleItems) {
          this.saleItems.set(parseInt(savedSaleId), savedItems);
        }
      }
    }

    // Return the items or an empty array if none found
    return this.saleItems.get(saleId) || [];
  }

  async deleteSaleItems(saleId: number): Promise<boolean> {
    const result = this.saleItems.delete(saleId);

    // Persist changes if successful
    if (result) {
      await nodePersist.setItem('saleItems', Array.from(this.saleItems.entries()));
    }

    return result;
  }

  // Clear all inventory data
  async clearInventory(): Promise<void> {
    // Clear the products map
    this.products.clear();

    // Reset the product ID counter
    this.productId = 1;

    // Persist the empty products and updated counter
    await this.persistProducts();

    console.log('Inventory data cleared successfully');
  }

  // Reset all inStock and sold values to zero
  async resetInventoryStock(): Promise<number> {
    let updatedCount = 0;

    // Get all products as an array
    const products = Array.from(this.products.values());

    // Update all products to have inStock = 0 and sold = 0
    products.forEach(product => {
      this.products.set(product.id, {
        ...product,
        inStock: 0,
        sold: 0,
        lastUpdated: new Date()
      });
      updatedCount++;
    });

    // Persist the updated products
    await this.persistProducts();

    console.log(`Reset inStock and sold values to zero for ${updatedCount} products`);
    return updatedCount;
  }

  // Method to reset only the sold counts to zero
  async resetSoldCounts(): Promise<number> {
    let updatedCount = 0;

    // Get all products as an array
    const products = Array.from(this.products.values());

    // Update all products to have sold = 0 (but keep inStock as is)
    products.forEach(product => {
      this.products.set(product.id, {
        ...product,
        sold: 0,
        lastUpdated: new Date()
      });
      updatedCount++;
    });

    // Persist the updated products
    await this.persistProducts();

    console.log(`Reset sold counts to zero for ${updatedCount} products`);
    return updatedCount;
  };

  // Activity tracking operations - using database only
  async createActivity(activity: InsertActivity): Promise<Activity> {
    // Use the database directly
    return await db.insert(activities).values(activity).returning().then(res => res[0]);
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    // Use the database directly
    return await db.select().from(activities).where(eq(activities.id, id)).then(res => res[0]);
  }

  async deleteActivity(id: number): Promise<boolean> {
    // Use the database directly
    return await db.delete(activities).where(eq(activities.id, id)).then(() => true);
  }

  async deleteOldActivities(daysToKeep: number = 30): Promise<number> {
    // Calculate cutoff date (activities older than this will be deleted)
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    // Delete activities older than the cutoff date
    const result = await db.delete(activities)
      .where(lt(activities.createdAt, cutoffDate))
      .returning({ id: activities.id });

    console.log(`Deleted ${result.length} activities older than ${daysToKeep} days (before ${cutoffDate.toISOString()})`);
    return result.length;
  }

  async deleteTestActivities(): Promise<number> {
    // Delete activities with pageName='Test' or action='test'
    const result = await db.delete(activities)
      .where(or(
        eq(activities.pageName, 'Test'),
        eq(activities.action, 'test')
      ))
      .returning({ id: activities.id });

    console.log(`Deleted ${result.length} test activities`);
    return result.length;
  }

  async listActivities(limit = 100, offset = 0): Promise<Activity[]> {
    // Use the database directly
    return await db.select().from(activities).orderBy(desc(activities.createdAt)).limit(limit).offset(offset);
  }

  async getActivitiesByPage(pageName: string, limit = 100, offset = 0): Promise<Activity[]> {
    // Use the database directly
    return await db.select().from(activities)
      .where(eq(activities.pageName, pageName))
      .orderBy(desc(activities.createdAt))
      .limit(limit).offset(offset);
  }

  async getActivitiesByAction(action: string, limit = 100, offset = 0): Promise<Activity[]> {
    // Use the database directly
    return await db.select().from(activities)
      .where(eq(activities.action, action))
      .orderBy(desc(activities.createdAt))
      .limit(limit).offset(offset);
  }

  async getEntityActivities(entityType: string, entityId: string, limit = 100): Promise<Activity[]> {
    // Use the database directly
    return await db.select().from(activities)
      .where(and(
        eq(activities.entityType, entityType),
        eq(activities.entityId, entityId)
      ))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }



  // Backup settings operations
  async getBackupSettings(): Promise<BackupSettings | undefined> {
    // Since we should only have one settings entry, get the first one
    return Array.from(this.backupSettings.values())[0];
  }

  async createBackupSettings(settings: InsertBackupSettings): Promise<BackupSettings> {
    const id = this.backupSettingsId++;
    const now = new Date();

    // Convert undefined values to null
    const processedSettings = Object.fromEntries(
      Object.entries(settings).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const backupSettings: BackupSettings = {
      ...processedSettings as any,
      id,
      createdAt: now,
      updatedAt: now
    };

    this.backupSettings.set(id, backupSettings);

    // Persist to storage
    await this.persistBackupSettings();

    return backupSettings;
  }

  async updateBackupSettings(id: number, settingsUpdate: Partial<InsertBackupSettings>): Promise<BackupSettings | undefined> {
    const existingSettings = this.backupSettings.get(id);
    if (!existingSettings) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(settingsUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedSettings = {
      ...existingSettings,
      ...processedUpdate,
      updatedAt: new Date()
    };

    this.backupSettings.set(id, updatedSettings);

    // Persist to storage
    await this.persistBackupSettings();

    return updatedSettings;
  }

  // Backup operations for scan history
  async backupScanHistory(scanHistoryId: number): Promise<ScanHistoryBackup> {
    const scanHistory = this.scans.get(scanHistoryId);
    if (!scanHistory) {
      throw new Error(`Scan history record with ID ${scanHistoryId} not found`);
    }

    // Create backup record
    const backupId = this.scanHistoryBackupId++;
    const backupRecord: ScanHistoryBackup = {
      id: backupId,
      originalId: scanHistory.id,
      barcode: scanHistory.barcode,
      productId: scanHistory.productId,
      productName: scanHistory.productName,
      productSku: scanHistory.productSku,
      scannedById: scanHistory.scannedById,
      scannerName: scanHistory.scannerName,
      scannerDepartment: scanHistory.scannerDepartment,
      scannedAt: scanHistory.scannedAt,
      action: scanHistory.action,
      quantity: scanHistory.quantity,
      notes: scanHistory.notes,
      backupDate: new Date()
    };

    // Add to backup storage
    this.scanHistoryBackups.set(backupId, backupRecord);

    // Mark original as backed up
    const updatedScanHistory = {
      ...scanHistory,
      isBackedUp: true
    };
    this.scans.set(scanHistoryId, updatedScanHistory);

    // Persist both updates
    await this.persistScanHistoryBackups();
    await this.persistScans();

    return backupRecord;
  }

  // Backup operations for loading operations
  async backupLoadingOperation(loadingOperationId: number): Promise<LoadingOperationBackup> {
    const loadingOperation = this.loadingOps.get(loadingOperationId);
    if (!loadingOperation) {
      throw new Error(`Loading operation with ID ${loadingOperationId} not found`);
    }

    // Create backup record
    const backupId = this.loadingOpBackupId++;

    // Find associated proforma slip to get vehicle number
    let vehicleNumber = null;
    if (loadingOperation.referenceNumber) {
      const proformaSlip = Array.from(this.proformaSlips.values()).find(
        slip => slip.orderNumber === loadingOperation.referenceNumber
      );
      if (proformaSlip && proformaSlip.vehicleNumber) {
        vehicleNumber = proformaSlip.vehicleNumber;
      }
    }

    const backupRecord: LoadingOperationBackup = {
      id: backupId,
      originalId: loadingOperation.id,
      status: loadingOperation.status,
      referenceNumber: loadingOperation.referenceNumber,
      vehicleNumber,
      createdById: loadingOperation.createdById,
      createdAt: loadingOperation.createdAt,
      completedAt: loadingOperation.completedAt,
      notes: loadingOperation.notes,
      backupDate: new Date()
    };

    // Add to backup storage
    this.loadingOpBackups.set(backupId, backupRecord);

    // Mark original as backed up
    const updatedLoadingOperation = {
      ...loadingOperation,
      isBackedUp: true
    };
    this.loadingOps.set(loadingOperationId, updatedLoadingOperation);

    // Check if we need to backup related items (proforma slip items)
    if (loadingOperation.referenceNumber) {
      // Find the proforma slip with this order number
      const proformaSlip = Array.from(this.proformaSlips.values()).find(
        slip => slip.orderNumber === loadingOperation.referenceNumber
      );

      if (proformaSlip) {
        // Get all items for this proforma slip
        const items = Array.from(this.proformaSlipItems.values()).filter(
          item => item.proformaSlipId === proformaSlip.id
        );

        // Store these items for this backup
        if (items && items.length > 0) {
          this.loadingOpBackupItems.set(backupId, items);
          await this.persistLoadingOpBackupItems();
        }
      }
    }

    // Persist both updates
    await this.persistLoadingOpBackups();
    await this.persistLoadingOps();

    return backupRecord;
  }

  // Backup operations for sales
  async backupSale(saleId: number): Promise<SaleBackup> {
    const sale = this.sales.get(saleId);
    if (!sale) {
      throw new Error(`Sale with ID ${saleId} not found`);
    }

    // Create backup record
    const backupId = this.saleBackupId++;
    const backupRecord: SaleBackup = {
      id: backupId,
      originalId: sale.id,
      orderNumber: sale.orderNumber,
      date: sale.date,
      dealer: sale.dealer,
      plant: sale.plant,
      status: sale.status,
      quantity: sale.quantity,
      amount: sale.amount,
      vehicleNumber: sale.vehicleNumber, // Adding vehicleNumber to match schema
      createdById: sale.createdById,
      createdAt: sale.createdAt,
      notes: sale.notes,
      backupDate: new Date()
    };

    // Add to backup storage
    this.saleBackups.set(backupId, backupRecord);

    // Get the sale items and back them up
    const saleItems = await this.getSaleItems(saleId);
    if (saleItems && saleItems.length > 0) {
      this.saleBackupItems.set(backupId, saleItems);
      await this.persistSaleBackupItems();
    }

    // Mark original as backed up
    const updatedSale = {
      ...sale,
      isBackedUp: true
    };
    this.sales.set(saleId, updatedSale);

    // Persist both updates
    await this.persistSaleBackups();
    await this.persistSales();

    return backupRecord;
  }

  // Proforma Slip operations
  async createProformaSlip(insertSlip: InsertProformaSlip): Promise<ProformaSlip> {
    const id = this.proformaSlipId++;
    const now = new Date();

    // Convert undefined values to null
    const processedSlip = Object.fromEntries(
      Object.entries(insertSlip).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const slip: ProformaSlip = {
      ...processedSlip as any,
      id,
      createdAt: now,
    };

    this.proformaSlips.set(id, slip);

    // Persist to storage
    await this.persistProformaSlips();

    return slip;
  }

  async getProformaSlip(id: number): Promise<ProformaSlip | undefined> {
    return this.proformaSlips.get(id);
  }

  async getProformaSlipByOrderNumber(orderNumber: string): Promise<ProformaSlip | undefined> {
    return Array.from(this.proformaSlips.values()).find(
      (slip) => slip.orderNumber === orderNumber
    );
  }

  async getProformaSlipsByOrderNumbers(orderNumbers: string[]): Promise<ProformaSlip[]> {
    if (!orderNumbers.length) return [];

    return Array.from(this.proformaSlips.values()).filter(
      (slip) => slip.orderNumber && orderNumbers.includes(slip.orderNumber)
    );
  }

  async updateProformaSlip(id: number, slipUpdate: Partial<InsertProformaSlip>): Promise<ProformaSlip | undefined> {
    console.log(`[storage] updateProformaSlip called with id: ${id}, update:`, slipUpdate);

    const existingSlip = this.proformaSlips.get(id);
    if (!existingSlip) {
      console.log(`[storage] No slip found with id: ${id}`);
      return undefined;
    }

    console.log(`[storage] Existing slip:`, existingSlip);

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(slipUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    console.log(`[storage] Processed update:`, processedUpdate);

    const updatedSlip = {
      ...existingSlip,
      ...processedUpdate,
    };

    console.log(`[storage] Updated slip (before saving):`, updatedSlip);

    this.proformaSlips.set(id, updatedSlip);

    // Persist to storage
    await this.persistProformaSlips();

    // Verify the updated slip was saved correctly
    const verifiedSlip = this.proformaSlips.get(id);
    console.log(`[storage] Verified slip after save:`, verifiedSlip);

    return updatedSlip;
  }

  async deleteProformaSlip(id: number): Promise<boolean> {
    const result = this.proformaSlips.delete(id);

    // If slip is deleted successfully, also delete all related items
    if (result) {
      // Find and delete all items for this slip
      const itemsToDelete = Array.from(this.proformaSlipItems.values())
        .filter(item => item.proformaSlipId === id)
        .map(item => item.id);

      itemsToDelete.forEach(itemId => this.proformaSlipItems.delete(itemId));

      // Persist both slips and items
      await this.persistProformaSlips();
      await this.persistProformaSlipItems();
    }

    return result;
  }

  async listProformaSlips(limit = 10, offset = 0): Promise<ProformaSlip[]> {
    return Array.from(this.proformaSlips.values())
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  // Proforma Slip Item operations
  async createProformaSlipItem(insertItem: InsertProformaSlipItem): Promise<ProformaSlipItem> {
    const id = this.proformaSlipItemId++;
    const now = new Date();

    // Convert undefined values to null
    const processedItem = Object.fromEntries(
      Object.entries(insertItem).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const item: ProformaSlipItem = {
      ...processedItem as any,
      id,
      createdAt: now,
    };

    this.proformaSlipItems.set(id, item);

    // Persist to storage
    await this.persistProformaSlipItems();

    return item;
  }

  async getProformaSlipItems(proformaSlipId: number): Promise<ProformaSlipItem[]> {
    return Array.from(this.proformaSlipItems.values())
      .filter(item => item.proformaSlipId === proformaSlipId);
  }

  async getProformaSlipItemsByIds(itemIds: number[]): Promise<ProformaSlipItem[]> {
    return Array.from(this.proformaSlipItems.values())
      .filter(item => itemIds.includes(item.id));
  }

  async updateProformaSlipItem(id: number, itemUpdate: Partial<InsertProformaSlipItem>): Promise<ProformaSlipItem | undefined> {
    const existingItem = this.proformaSlipItems.get(id);
    if (!existingItem) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(itemUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedItem = {
      ...existingItem,
      ...processedUpdate,
    };

    this.proformaSlipItems.set(id, updatedItem);

    // Persist to storage
    await this.persistProformaSlipItems();

    return updatedItem;
  }

  async deleteProformaSlipItem(id: number): Promise<boolean> {
    const result = this.proformaSlipItems.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistProformaSlipItems();
    }

    return result;
  }

  // List historical data with date filtering
  async listScanHistoryBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0): Promise<ScanHistoryBackup[]> {
    return Array.from(this.scanHistoryBackups.values())
      .filter(backup => {
        if (!startDate && !endDate) return true;

        // Safely handle nullable date
        if (!backup.backupDate) return false;

        const backupDate = backup.backupDate instanceof Date 
          ? backup.backupDate 
          : new Date(backup.backupDate);

        if (startDate && endDate) {
          return backupDate >= startDate && backupDate <= endDate;
        } else if (startDate) {
          return backupDate >= startDate;
        } else if (endDate) {
          return backupDate <= endDate;
        }

        return true;
      })
      .sort((a, b) => {
        // Safely handle nullable dates
        if (!a.backupDate) return 1;  // Sort nulls to the end
        if (!b.backupDate) return -1; // Sort nulls to the end

        const dateA = a.backupDate instanceof Date ? a.backupDate : new Date(a.backupDate);
        const dateB = b.backupDate instanceof Date ? b.backupDate : new Date(b.backupDate);
        return dateB.getTime() - dateA.getTime(); // Sort from newest to oldest
      })
      .slice(offset, offset + limit);
  }

  async listLoadingOperationBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0, orderDate?: Date): Promise<LoadingOperationBackup[]> {
    // First check for orderDate parameter (exact date filter)
    if (orderDate) {
      const startOfDay = new Date(orderDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(orderDate);
      endOfDay.setHours(23, 59, 59, 999);

      return Array.from(this.loadingOpBackups.values())
        .filter(backup => {
          if (!backup.orderDate) return false;

          const date = backup.orderDate instanceof Date
            ? backup.orderDate
            : new Date(backup.orderDate);

          return date >= startOfDay && date <= endOfDay;
        })
        .sort((a, b) => {
          const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt || 0);
          const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt || 0);
          return dateB.getTime() - dateA.getTime();
        })
        .slice(offset, offset + limit);
    }

    // Then check for date range parameters
    return Array.from(this.loadingOpBackups.values())
      .filter(backup => {
        if (!startDate && !endDate) return true;

        // Safely handle nullable date
        if (!backup.backupDate) return false;

        const backupDate = backup.backupDate instanceof Date 
          ? backup.backupDate 
          : new Date(backup.backupDate);

        if (startDate && endDate) {
          return backupDate >= startDate && backupDate <= endDate;
        } else if (startDate) {
          return backupDate >= startDate;
        } else if (endDate) {
          return backupDate <= endDate;
        }

        return true;
      })
      .sort((a, b) => {
        // Safely handle nullable dates
        if (!a.backupDate) return 1;  // Sort nulls to the end
        if (!b.backupDate) return -1; // Sort nulls to the end

        const dateA = a.backupDate instanceof Date ? a.backupDate : new Date(a.backupDate);
        const dateB = b.backupDate instanceof Date ? b.backupDate : new Date(b.backupDate);
        return dateB.getTime() - dateA.getTime(); // Sort from newest to oldest
      })
      .slice(offset, offset + limit);
  }

  async listSaleBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0): Promise<SaleBackup[]> {
    return Array.from(this.saleBackups.values())
      .filter(backup => {
        if (!startDate && !endDate) return true;

        // Safely handle nullable date
        if (!backup.backupDate) return false;

        const backupDate = backup.backupDate instanceof Date 
          ? backup.backupDate 
          : new Date(backup.backupDate);

        if (startDate && endDate) {
          return backupDate >= startDate && backupDate <= endDate;
        } else if (startDate) {
          return backupDate >= startDate;
        } else if (endDate) {
          return backupDate <= endDate;
        }

        return true;
      })
      .sort((a, b) => {
        // Safely handle nullable dates
        if (!a.backupDate) return 1;  // Sort nulls to the end
        if (!b.backupDate) return -1; // Sort nulls to the end

        const dateA = a.backupDate instanceof Date ? a.backupDate : new Date(a.backupDate);
        const dateB = b.backupDate instanceof Date ? b.backupDate : new Date(b.backupDate);
        return dateB.getTime() - dateA.getTime(); // Sort from newest to oldest
      })
      .slice(offset, offset + limit);
  }

  // Get items for a backed up sale
  async getSaleBackupItems(backupId: number): Promise<any[]> {
    try {
      // If we have a direct mapping of backup sale items, use that
      if (this.saleBackupItems.has(backupId)) {
        return this.saleBackupItems.get(backupId) || [];
      }

      // Otherwise, check if the backup corresponds to an existing sale
      const backup = this.saleBackups.get(backupId);
      if (!backup) return [];

      // If the backup has an originalId, try to get items from the original sale
      if (backup.originalId) {
        const items = await this.getSaleItems(backup.originalId);



        // Cache these items in the backup items map for future use
        if (items && items.length > 0) {
          this.saleBackupItems.set(backupId, items);
          await this.persistSaleBackupItems();
        }

        return items;
      }

      return [];
    } catch (error) {
      console.error("Error getting backup sale items:", error);
      return [];    }
  }

  // Get items for a loading operation backup
  async getLoadingOperationBackupItems(backupId: number): Promise<any[]> {
    try {
      // If we have a direct mapping of backup loading operation items, use that
      if (this.loadingOpBackupItems.has(backupId)) {
        return this.loadingOpBackupItems.get(backupId) || [];
      }

      // Otherwise, check if the backup corresponds to an existing loading operation
      const backup = this.loadingOpBackups.get(backupId);
      if (!backup) return [];

      // If the backup has an originalId, try to get items from the proforma slip
      if (backup.originalId && backup.referenceNumber) {
        // We need to find the proforma slip that matches the reference number
        const proformaSlip = Array.from(this.proformaSlips.values()).find(
          slip => slip.orderNumber === backup.referenceNumber
        );

        if (proformaSlip) {
          // Get all items for this proforma slip
          const items = Array.from(this.proformaSlipItems.values()).filter(
            item => item.proformaSlipId === proformaSlip.id
          );

          // Cache these items in the backup items map for future use
          if (items && items.length > 0) {
            this.loadingOpBackupItems.set(backupId, items);
            await this.persistLoadingOpBackupItems();
          }

          return items;
        }
      }

      return [];
    } catch (error) {
      console.error("Error getting backup loading operation items:", error);
      return [];
    }
  }

  // Delete a loading operation backup by ID
  async deleteLoadingOperationBackup(backupId: number): Promise<boolean> {
    try {
      // Check if the backup exists
      if (!this.loadingOpBackups.has(backupId)) {
        return false;
      }

      // Delete the backup
      this.loadingOpBackups.delete(backupId);

      // Also delete any associated backup items
      if (this.loadingOpBackupItems.has(backupId)) {
        this.loadingOpBackupItems.delete(backupId);
        await this.persistLoadingOpBackupItems();
      }

      // Persist the changes
      await this.persistLoadingOpBackups();

      return true;
    } catch (error) {
      console.error(`Error deleting loading operation backup with ID ${backupId}:`, error);
      return false;
    }
  }

  // Delete a sale backup by ID
  async deleteSaleBackup(backupId: number): Promise<boolean> {
    try {
      // Check if the backup exists
      if (!this.saleBackups.has(backupId)) {
        return false;
      }

      // Delete the backup
      this.saleBackups.delete(backupId);

      // Also delete any associated backup items
      if (this.saleBackupItems.has(backupId)) {
        this.saleBackupItems.delete(backupId);
        await this.persistSaleBackupItems();
      }

      // Persist the changes
      await this.persistSaleBackups();

      return true;
    } catch (error) {
      console.error(`Error deleting sale backup with ID ${backupId}:`, error);
      return false;
    }
  }

  // Run a backup operation
  async backupProformaSlip(proformaSlipId: number): Promise<ProformaSlipBackup> {
    const slip = this.proformaSlips.get(proformaSlipId);
    if (!slip) {
      throw new Error(`Proforma slip with ID ${proformaSlipId} not found`);
    }

    // Mark original as backed up
    const updatedSlip = {
      ...slip,
      isBackedUp: true
    };
    this.proformaSlips.set(proformaSlipId, updatedSlip);
    await this.persistProformaSlips();

    // Create a backup entry
    const backupIds = Array.from(this.proformaSlipBackups.values()).map(b => b.id);
    const nextBackupId = backupIds.length > 0 ? Math.max(...backupIds) + 1 : 1;
    const backup: ProformaSlipBackup = {
      id: nextBackupId,
      originalId: slip.id,
      orderDate: slip.orderDate,
      orderNumber: slip.orderNumber,
      partyName: slip.partyName,
      plant: slip.plant,
      totalQuantity: slip.totalQuantity,
      totalVolume: slip.totalVolume,
      vehicleNumber: slip.vehicleNumber,
      driverName: slip.driverName,
      createdById: slip.createdById,
      createdAt: slip.createdAt,
      notes: slip.notes,
      backupDate: new Date()
    };

    // Save the backup entry
    this.proformaSlipBackups.set(nextBackupId, backup);
    await this.persistProformaSlipBackups();

    // Also back up all items for this slip
    const items = Array.from(this.proformaSlipItems.values())
      .filter(item => item.proformaSlipId === proformaSlipId);

    for (const item of items) {
      // Mark item as backed up
      const updatedItem = {
        ...item,
        isBackedUp: true
      };
      this.proformaSlipItems.set(item.id, updatedItem);

      // And create a backup of the item
      await this.backupProformaSlipItem(item.id, nextBackupId);
    }

    // Persist the updated items
    await this.persistProformaSlipItems();

    return backup;
  }

  async backupProformaSlipItem(slipItemId: number, proformaSlipBackupId: number): Promise<ProformaSlipItemBackup> {
    const item = this.proformaSlipItems.get(slipItemId);
    if (!item) {
      throw new Error(`Proforma slip item with ID ${slipItemId} not found`);
    }

    // Mark original as backed up
    const updatedItem = {
      ...item,
      isBackedUp: true
    };
    this.proformaSlipItems.set(slipItemId, updatedItem);
    await this.persistProformaSlipItems();

    // Create a backup entry
    const itemBackupIds = Array.from(this.proformaSlipItemBackups.values()).map(b => b.id);
    const nextBackupId = itemBackupIds.length > 0 ? Math.max(...itemBackupIds) + 1 : 1;
    const backup: ProformaSlipItemBackup = {
      id: nextBackupId,
      originalId: item.id,
      proformaSlipId: item.proformaSlipId, 
      proformaSlipBackupId: proformaSlipBackupId,
      productId: item.productId,
      quantity: item.quantity,
      loaded: item.loaded,
      createdAt: item.createdAt,
      backupDate: new Date()
    };

    // Save the backup entry
    this.proformaSlipItemBackups.set(nextBackupId, backup);
    await this.persistProformaSlipItemBackups();

    return backup;
  }

  async listProformaSlipBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0): Promise<ProformaSlipBackup[]> {
    let backups = Array.from(this.proformaSlipBackups.values());

    // Apply date filters if provided
    if (startDate) {
      backups = backups.filter(backup => {
        if (!backup.createdAt) return false;
        const backupDate = backup.createdAt instanceof Date ? backup.createdAt : new Date(backup.createdAt);
        return backupDate >= startDate;
      });
    }

    if (endDate) {
      backups = backups.filter(backup => {
        if (!backup.createdAt) return false;
        const backupDate = backup.createdAt instanceof Date ? backup.createdAt : new Date(backup.createdAt);
        return backupDate <= endDate;
      });
    }

    // Sort by creation date (newest first)
    backups.sort((a, b) => {
      // Handle missing dates
      if (!a.createdAt && !b.createdAt) return 0;
      if (!a.createdAt) return 1; // null dates sort to the end
      if (!b.createdAt) return -1;

      const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(a.createdAt);
      const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });

    // Apply pagination
    return backups.slice(offset, offset + limit);
  }

  async listProformaSlipItemBackups(proformaSlipBackupId: number): Promise<ProformaSlipItemBackup[]> {
    return Array.from(this.proformaSlipItemBackups.values())
      .filter(item => item.proformaSlipBackupId === proformaSlipBackupId);
  }

  // Delete a proforma slip backup by ID
  async deleteProformaSlipBackup(backupId: number): Promise<boolean> {
    try {
      // Check if the backup exists
      if (!this.proformaSlipBackups.has(backupId)) {
        return false;
      }

      // Delete the backup
      this.proformaSlipBackups.delete(backupId);

      // Delete associated proforma slip item backups
      const itemBackups = await this.listProformaSlipItemBackups(backupId);
      for (const itemBackup of itemBackups) {
        this.proformaSlipItemBackups.delete(itemBackup.id);
      }

      // Persist the changes
      await this.persistProformaSlipBackups();
      await this.persistProformaSlipItemBackups();

      return true;
    } catch (error) {
      console.error(`Error deleting proforma slip backup with ID ${backupId}:`, error);
      return false;
    }
  }

  // Delete multiple proforma slip backups by ID
  async deleteProformaSlipBackups(backupIds: number[]): Promise<number> {
    try {
      let deletedCount = 0;

      for (const backupId of backupIds) {
        if (await this.deleteProformaSlipBackup(backupId)) {
          deletedCount++;
        }
      }

      return deletedCount;
    } catch (error) {
      console.error(`Error deleting multiple proforma slip backups:`, error);
      return 0;
    }
  }

  // These methods are properly implemented earlier
  // No duplicate implementation needed

  async runBackupOperation(): Promise<{
    scansBackedUp: number,
    loadingOpsBackedUp: number,
    salesBackedUp: number,
    proformaSlipsBackedUp: number
  }> {
    let scansBackedUp = 0;
    let loadingOpsBackedUp = 0;
    let salesBackedUp = 0;
    let proformaSlipsBackedUp = 0;

    // Backup scan history records that haven't been backed up yet
    const scanHistoryToBackup = Array.from(this.scans.values())
      .filter(scan => !scan.isBackedUp);

    for (const scan of scanHistoryToBackup) {
      await this.backupScanHistory(scan.id);
      scansBackedUp++;
    }

    // Backup loading operations that haven't been backed up yet
    const loadingOpsToBackup = Array.from(this.loadingOps.values())
      .filter(op => !op.isBackedUp);

    for (const op of loadingOpsToBackup) {
      await this.backupLoadingOperation(op.id);
      loadingOpsBackedUp++;
    }

    // Backup sales that haven't been backed up yet
    const salesToBackup = Array.from(this.sales.values())
      .filter(sale => !sale.isBackedUp);

    for (const sale of salesToBackup) {
      await this.backupSale(sale.id);
      salesBackedUp++;
    }

    // Backup proforma slips that haven't been backed up yet
    const proformaSlipsToBackup = Array.from(this.proformaSlips.values())
      .filter(slip => !slip.isBackedUp);

    for (const slip of proformaSlipsToBackup) {
      await this.backupProformaSlip(slip.id);
      proformaSlipsBackedUp++;
    }

    // Update the last backup date in settings
    const settings = await this.getBackupSettings();
    if (settings) {
      await this.updateBackupSettings(settings.id, {
        lastBackupDate: new Date()
      });
    }

    // Apply data retention policies after backup
    await this.applyDataRetentionPolicies();

    return {
      scansBackedUp,
      loadingOpsBackedUp,
      salesBackedUp,
      proformaSlipsBackedUp
    };
  }

  /**
   * Apply data retention policies:
   * - Keep scan history, sales data, and proforma slips indefinitely
   * - Delete loading operations data older than 6 months
   */
  async applyDataRetentionPolicies(): Promise<{
    loadingOpsDeleted: number
  }> {
    let loadingOpsDeleted = 0;

    // Calculate date 6 months ago
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    // Find loading operation backups older than 6 months
    const oldLoadingOpBackups = Array.from(this.loadingOpBackups.values())
      .filter(backup => {
        // Skip records without backup date
        if (!backup.backupDate) return false;

        const backupDate = backup.backupDate instanceof Date 
          ? backup.backupDate 
          : new Date(backup.backupDate);

        return backupDate < sixMonthsAgo;
      });

    // Delete old loading operation backups
    for (const backup of oldLoadingOpBackups) {
      this.loadingOpBackups.delete(backup.id);
      loadingOpsDeleted++;
    }

    // Persist changes if any records were deleted
    if (loadingOpsDeleted > 0) {
      await this.persistLoadingOpBackups();
      console.log(`Deleted ${loadingOpsDeleted} loading operations older than 6 months`);
    }

    return {
      loadingOpsDeleted
    };
  }

  // Message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();

    // Convert undefined values to null
    const processedMessage = Object.fromEntries(
      Object.entries(insertMessage).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const message: Message = {
      ...processedMessage as any,
      id,
      createdAt: now,
    };

    this.messages.set(id, message);

    // Persist to storage
    await this.persistMessages();

    return message;
  }

  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async updateMessage(id: number, messageUpdate: Partial<InsertMessage>): Promise<Message | undefined> {
    const existingMessage = this.messages.get(id);
    if (!existingMessage) return undefined;

    // Convert undefined values to null
    const processedUpdate = Object.fromEntries(
      Object.entries(messageUpdate).map(([key, value]) => [key, value === undefined ? null : value])
    );

    const updatedMessage = {
      ...existingMessage,
      ...processedUpdate,
    };

    this.messages.set(id, updatedMessage);

    // Persist to storage
    await this.persistMessages();

    return updatedMessage;
  }

  async deleteMessage(id: number): Promise<boolean> {
    const result = this.messages.delete(id);

    // Persist to storage if deletion was successful
    if (result) {
      await this.persistMessages();
    }

    return result;
  }

  async listMessages(limit = 10, offset = 0): Promise<Message[]> {
    return Array.from(this.messages.values())
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  async getMessagesForUser(userId: number, limit = 10, offset = 0): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        // Messages directly for this user
        message.recipientId === userId || 
        // Broadcast messages to all
        message.broadcastToAll === true ||
        // Messages for the user's department
        (message.broadcastToDepartment && 
          this.users.get(userId)?.department === message.broadcastToDepartment) ||
        // Messages for the user's designation
        (message.broadcastToDesignation && 
          this.users.get(userId)?.designation === message.broadcastToDesignation)
      )
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  async getConversation(user1Id: number, user2Id: number, limit = 20, offset = 0): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        // Messages between these two users in either direction
        (message.senderId === user1Id && message.recipientId === user2Id) ||
        (message.senderId === user2Id && message.recipientId === user1Id)
      )
      .sort((a, b) => {
        // Handle dates that might be strings when loaded from storage
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateA?.getTime() || 0) - (dateB?.getTime() || 0); // Ascending order for conversations
      })
      .slice(offset, offset + limit);
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;

    const updatedMessage = {
      ...message,
      isRead: true
    };

    this.messages.set(id, updatedMessage);

    // Persist to storage
    await this.persistMessages();

    return updatedMessage;
  }

  async getUnreadMessageCount(userId: number): Promise<number> {
    return Array.from(this.messages.values())
      .filter(message => 
        // Count unread messages directly for this user
        !message.isRead && 
        (message.recipientId === userId || 
         // Or broadcast messages
         message.broadcastToAll === true ||
         // Messages for the user's department
         (message.broadcastToDepartment && 
          this.users.get(userId)?.department === message.broadcastToDepartment) ||
         // Messages for the user's designation
         (message.broadcastToDesignation && 
          this.users.get(userId)?.designation === message.broadcastToDesignation))
      )
      .length;
  }
}

// Use the database connection imported at the top of the file

// PostgreSQL database storage implementation
export class DBStorage implements IStorage {
  // Session store for authentication
  public sessionStore: session.Store;

  constructor() {
    console.log('Initializing DBStorage with PostgreSQL database');
    
    // Initialize PostgreSQL session store
    const PostgresSessionStore = connectPg(session);
    
    // Create session store but disable table creation to prevent "relation already exists" errors
    this.sessionStore = new PostgresSessionStore({
      pool,
      // Don't try to create the table as it already exists
      createTableIfMissing: false,
      tableName: 'session'
    });
    
    // Suppress error logging for the session table
    pool.on('error', (err) => {
      // Only log errors that aren't related to the session table
      if (!err.message.includes('session_pkey')) {
        console.error('Postgres pool error:', err);
      }
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    try {
      const result = await db.insert(users).values(user).returning();
      return result[0];
    } catch (error: any) {
      // Check if the error is a primary key violation
      if (error.code === '23505' && error.constraint === 'users_pkey') {
        console.log(`User with ID ${user.id} already exists. Using existing user.`);
        
        // If the user provided an explicit ID that already exists, try to get that user
        if (user.id) {
          const existingUser = await this.getUser(user.id);
          if (existingUser) {
            return existingUser;
          }
        }
      }
      
      // Re-throw if it's not a handled error or we couldn't recover
      throw error;
    }
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users).set(user).where(eq(users.id, id)).returning();
    return result.length ? result[0] : undefined;
  }
  
  async updateUserPin(id: number, pin: string): Promise<User | undefined> {
    console.log(`Updating PIN for user ID ${id}`);
    const result = await db.update(users).set({ pin }).where(eq(users.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id)).returning({ id: users.id });
    return result.length > 0;
  }

  async listUsers(limit = 100, offset = 0): Promise<User[]> {
    return await db.select().from(users).limit(limit).offset(offset);
  }
  
  async getAllUsers(): Promise<User[]> {
    try {
      // Get all users without pagination
      const allUsers = await db.select().from(users);
      console.log(`Retrieved ${allUsers.length} users from database for PIN validation`);
      return allUsers;
    } catch (error) {
      console.error('Error in getAllUsers:', error);
      return [];
    }
  }

  // Product operations
  async getProduct(id: number): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async getProductByBarcode(barcode: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.barcode, barcode)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async getProductsByIds(ids: number[]): Promise<Product[]> {
    if (!ids || ids.length === 0) return [];
    
    console.log(`Fetching ${ids.length} products by IDs`);
    return await db.select().from(products).where(inArray(products.id, ids));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(product).returning();
    return result[0];
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    // Process the update data to ensure proper types for database
    const updateData: Record<string, any> = {};

    // Copy and process all properties except lastUpdated
    for (const [key, value] of Object.entries(product)) {
      if (key !== 'lastUpdated') {
        // Special handling for volumeInCuFt to ensure it's saved properly
        if (key === 'volumeInCuFt') {
          // Make sure it's stored as string, even if empty
          updateData[key] = value === null ? '' : String(value);
        } else {
          updateData[key] = value;
        }
      }
    }

    // Handle lastUpdated separately
    if (product.lastUpdated) {
      try {
        if (typeof product.lastUpdated === 'string') {
          // If lastUpdated is a string, convert to Date
          updateData.updatedAt = new Date(product.lastUpdated);
        } else if (product.lastUpdated instanceof Date) {
          // If it's already a Date, use it directly
          updateData.updatedAt = product.lastUpdated;
        }
      } catch (error) {
        console.error("Error converting lastUpdated:", error);
        // Use current date as fallback
        updateData.updatedAt = new Date();
      }
    } else {
      // If no lastUpdated provided, use current date
      updateData.updatedAt = new Date();
    }

    console.log("Updating product with processed data:", JSON.stringify(updateData, null, 2));

    const result = await db.update(products).set(updateData).where(eq(products.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id)).returning({ id: products.id });
    return result.length > 0;
  }

  async listProducts(limit = 1000, offset = 0): Promise<Product[]> {
    console.log(`Fetching products with limit: ${limit}, offset: ${offset}`);
    const result = await db
      .select()
      .from(products)
      .orderBy(products.srNo)
      .limit(limit)
      .offset(offset);
    console.log(`Found ${result.length} products`);
    return result;
  }
  
  async getAllProducts(): Promise<Product[]> {
    try {
      console.log('Fetching ALL products (no pagination)');
      // Get all products without pagination
      const allProducts = await db
        .select()
        .from(products)
        .orderBy(products.srNo);
      console.log(`Retrieved ${allProducts.length} products from database`);
      return allProducts;
    } catch (error) {
      console.error('Error in getAllProducts:', error);
      return [];
    }
  }

  async clearInventory(): Promise<void> {
    try {
      console.log("Attempting to clear all products from inventory...");
      // Remove all constraints first so we can clear the table
      await db.delete(products);
      console.log("All products deleted successfully");
    } catch (error) {
      console.error("Error in clearInventory:", error);
      throw error;
    }
  }

  async resetInventoryStock(): Promise<number> {
    const result = await db.update(products).set({ inStock: 0 }).returning({ id: products.id });
    return result.length;
  }

  // Scan history operations
  async createScanHistory(entry: InsertScanHistory): Promise<ScanHistory> {
    const result = await db.insert(scanHistory).values(entry).returning();
    return result[0];
  }

  async getScanHistory(id: number): Promise<ScanHistory | undefined> {
    const result = await db.select().from(scanHistory).where(eq(scanHistory.id, id)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async deleteScanHistory(id: number): Promise<boolean> {
    const result = await db.delete(scanHistory).where(eq(scanHistory.id, id)).returning({ id: scanHistory.id });
    return result.length > 0;
  }

  async listScanHistory(limit = 100, offset = 0): Promise<ScanHistory[]> {
    return await db.select().from(scanHistory).orderBy(desc(scanHistory.scannedAt)).limit(limit).offset(offset);
  }

  // Loading operations
  async createLoadingOperation(operation: InsertLoadingOperation): Promise<LoadingOperation> {
    // Process the operation data to ensure all fields have correct types
    const processedOperation = { ...operation };

    // Convert orderDate to proper Date object if it's a string
    if (processedOperation.orderDate && typeof processedOperation.orderDate === 'string') {
      try {
        // Create a Date object and ensure it's valid by parsing the date parts
        let dateObj: Date;

        // Try to handle various date formats (DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD)
        if (processedOperation.orderDate.includes('/') || processedOperation.orderDate.includes('-')) {
          const parts = processedOperation.orderDate.split(/[-\/]/);
          // Check if format is YYYY-MM-DD
          if (parts[0].length === 4) {
            // Assume YYYY-MM-DD format
            dateObj = new Date(processedOperation.orderDate);
          } else {
            // Assume DD/MM/YYYY or DD-MM-YYYY format
            const day = parseInt(parts[0], 10);
            const month = parseInt(parts[1], 10) - 1; // Month is 0-based in Date
            const year = parseInt(parts[2], 10);
            dateObj = new Date(year, month, day);
          }
        } else {
          // Default - just try to parse as is
          dateObj = new Date(processedOperation.orderDate);
        }

        // Validate the date is valid
        if (isNaN(dateObj.getTime())) {
          throw new Error(`Invalid date: ${processedOperation.orderDate}`);
        }

        processedOperation.orderDate = dateObj;
        console.log(`Converted orderDate string to Date object: ${processedOperation.orderDate}`);
      } catch (error) {
        console.error(`Failed to convert orderDate string to Date: ${processedOperation.orderDate}`, error);
        // Set to null if conversion fails
        processedOperation.orderDate = null;
      }
    }

    try {
      // Get the maximum ID and add a large increment to avoid conflicts
      const maxIdResult = await db.select({ maxId: sql`MAX(id)` }).from(loadingOperations);
      const maxId = maxIdResult[0]?.maxId || 0;
      
      // Start at 1000 if no operations exist, otherwise add 1000 to the max ID
      const nextId = Math.max(1000, Number(maxId) + 1000);
      
      console.log(`Using safe ID (well above existing IDs) for loading operation: ${nextId}`);

      // Use insert method instead of raw SQL to avoid syntax issues
      const result = await db.insert(loadingOperations).values({
        id: nextId,
        status: processedOperation.status || 'LOADING',
        referenceNumber: processedOperation.referenceNumber,
        vehicleNumber: processedOperation.vehicleNumber,
        createdById: processedOperation.createdById,
        notes: processedOperation.notes,
        orderDate: processedOperation.orderDate,
        isBackedUp: processedOperation.isBackedUp || false,
        createdAt: new Date(),
        plant: processedOperation.plant || null
      }).returning();
      
      // Parse the result - drizzle returns the rows directly, not in a rows property
      if (result && result.length > 0) {
        return result[0] as LoadingOperation;
      } else {
        throw new Error("Failed to create loading operation: No rows returned");
      }
    } catch (error) {
      console.error("Error creating loading operation with custom ID:", error);
      throw error;
    }
  }

  async getLoadingOperation(id: number): Promise<LoadingOperation | undefined> {
    const result = await db.select({
      id: loadingOperations.id,
      status: loadingOperations.status,
      referenceNumber: loadingOperations.referenceNumber,
      vehicleNumber: loadingOperations.vehicleNumber,
      createdById: loadingOperations.createdById,
      createdAt: loadingOperations.createdAt,
      completedAt: loadingOperations.completedAt,
      notes: loadingOperations.notes,
      orderDate: loadingOperations.orderDate,
      isBackedUp: loadingOperations.isBackedUp,
      // Include user details
      creatorName: users.name,
      creatorUsername: users.username,
      creatorRole: users.role
    })
    .from(loadingOperations)
    .leftJoin(users, eq(loadingOperations.createdById, users.id))
    .where(eq(loadingOperations.id, id))
    .limit(1);
    
    if (result.length) {
      return {
        id: result[0].id,
        status: result[0].status,
        referenceNumber: result[0].referenceNumber,
        vehicleNumber: result[0].vehicleNumber,
        createdById: result[0].createdById,
        createdAt: result[0].createdAt,
        completedAt: result[0].completedAt,
        notes: result[0].notes,
        orderDate: result[0].orderDate,
        isBackedUp: result[0].isBackedUp,
        creatorName: result[0].creatorName,
        creatorUsername: result[0].creatorUsername,
        creatorRole: result[0].creatorRole
      };
    }
    
    return undefined;
  }

  async getLoadingOperationByReferenceNumber(referenceNumber: string): Promise<LoadingOperation | undefined> {
    const result = await db.select({
      id: loadingOperations.id,
      status: loadingOperations.status,
      referenceNumber: loadingOperations.referenceNumber,
      vehicleNumber: loadingOperations.vehicleNumber,
      createdById: loadingOperations.createdById,
      createdAt: loadingOperations.createdAt,
      completedAt: loadingOperations.completedAt,
      notes: loadingOperations.notes,
      orderDate: loadingOperations.orderDate,
      isBackedUp: loadingOperations.isBackedUp,
      // Include user details
      creatorName: users.name,
      creatorUsername: users.username,
      creatorRole: users.role
    })
    .from(loadingOperations)
    .leftJoin(users, eq(loadingOperations.createdById, users.id))
    .where(eq(loadingOperations.referenceNumber, referenceNumber))
    .limit(1);
    
    if (result.length) {
      return {
        id: result[0].id,
        status: result[0].status,
        referenceNumber: result[0].referenceNumber,
        vehicleNumber: result[0].vehicleNumber,
        createdById: result[0].createdById,
        createdAt: result[0].createdAt,
        completedAt: result[0].completedAt,
        notes: result[0].notes,
        orderDate: result[0].orderDate,
        isBackedUp: result[0].isBackedUp,
        creatorName: result[0].creatorName,
        creatorUsername: result[0].creatorUsername,
        creatorRole: result[0].creatorRole
      };
    }
    
    return undefined;
  }

  async updateLoadingOperation(id: number, operation: Partial<InsertLoadingOperation>): Promise<LoadingOperation | undefined> {
    // Process the operation data to ensure all fields have correct types
    const processedOperation = { ...operation };

    // Convert orderDate to proper Date object if it's a string
    if (processedOperation.orderDate && typeof processedOperation.orderDate === 'string') {
      try {
        // Create a Date object and ensure it's valid by parsing the date parts
        let dateObj: Date;

        // Try to handle various date formats (DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD)
        if (processedOperation.orderDate.includes('/') || processedOperation.orderDate.includes('-')) {
          const parts = processedOperation.orderDate.split(/[-\/]/);
          // Check if format is YYYY-MM-DD
          if (parts[0].length === 4) {
            // Assume YYYY-MM-DD format
            dateObj = new Date(processedOperation.orderDate);
          } else {
            // Assume DD/MM/YYYY or DD-MM-YYYY format
            const day = parseInt(parts[0], 10);
            const month = parseInt(parts[1], 10) - 1; // Month is 0-based in Date
            const year = parseInt(parts[2], 10);
            dateObj = new Date(year, month, day);
          }
        } else {
          // Default - just try to parse as is
          dateObj = new Date(processedOperation.orderDate);
        }

        // Validate the date is valid
        if (isNaN(dateObj.getTime())) {
          throw new Error(`Invalid date: ${processedOperation.orderDate}`);
        }

        processedOperation.orderDate = dateObj;
        console.log(`Converted orderDate string to Date object in update: ${processedOperation.orderDate}`);
      } catch (error) {
        console.error(`Failed to convert orderDate string to Date in update: ${processedOperation.orderDate}`, error);
        // Set to null if conversion fails
        processedOperation.orderDate = null;
      }
    }

    const result = await db.update(loadingOperations).set(processedOperation).where(eq(loadingOperations.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deleteLoadingOperation(id: number): Promise<boolean> {
    const result = await db.delete(loadingOperations).where(eq(loadingOperations.id, id)).returning({ id: loadingOperations.id });
    return result.length > 0;
  }

  async listLoadingOperations(limit = 100, offset = 0, startDate?: Date, endDate?: Date, orderDate?: Date): Promise<LoadingOperation[]> {
    // Base query with user information
    const baseQuery = db.select({
      id: loadingOperations.id,
      status: loadingOperations.status,
      referenceNumber: loadingOperations.referenceNumber,
      vehicleNumber: loadingOperations.vehicleNumber,
      createdById: loadingOperations.createdById,
      createdAt: loadingOperations.createdAt,
      completedAt: loadingOperations.completedAt,
      notes: loadingOperations.notes,
      orderDate: loadingOperations.orderDate,
      isBackedUp: loadingOperations.isBackedUp,
      // Include user details
      creatorName: users.name,
      creatorUsername: users.username,
      creatorRole: users.role
    })
    .from(loadingOperations)
    .leftJoin(users, eq(loadingOperations.createdById, users.id));

    // If exact order date is provided, use it for filtering
    if (orderDate) {
      // Create start and end of the specified day
      const startOfDay = new Date(orderDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(orderDate);
      endOfDay.setHours(23, 59, 59, 999);

      const result = await baseQuery
        .where(
          and(
            gte(loadingOperations.orderDate, startOfDay),
            lte(loadingOperations.orderDate, endOfDay)
          )
        )
        .orderBy(desc(loadingOperations.createdAt))
        .limit(limit)
        .offset(offset);
      
      // Convert the result to the LoadingOperation type
      return result.map(op => ({
        id: op.id,
        status: op.status,
        referenceNumber: op.referenceNumber,
        vehicleNumber: op.vehicleNumber,
        createdById: op.createdById,
        createdAt: op.createdAt,
        completedAt: op.completedAt,
        notes: op.notes,
        orderDate: op.orderDate,
        isBackedUp: op.isBackedUp,
        creatorName: op.creatorName,
        creatorUsername: op.creatorUsername,
        creatorRole: op.creatorRole
      }));
    }

    // If date range is provided, filter by created date
    if (startDate && endDate) {
      const result = await baseQuery
        .where(
          and(
            gte(loadingOperations.createdAt, startDate),
            lte(loadingOperations.createdAt, endDate)
          )
        )
        .orderBy(desc(loadingOperations.createdAt))
        .limit(limit)
        .offset(offset);
      
      // Convert the result to the LoadingOperation type
      return result.map(op => ({
        id: op.id,
        status: op.status,
        referenceNumber: op.referenceNumber,
        vehicleNumber: op.vehicleNumber,
        createdById: op.createdById,
        createdAt: op.createdAt,
        completedAt: op.completedAt,
        notes: op.notes,
        orderDate: op.orderDate,
        isBackedUp: op.isBackedUp,
        creatorName: op.creatorName,
        creatorUsername: op.creatorUsername,
        creatorRole: op.creatorRole
      }));
    }

    // Otherwise return all operations
    const result = await baseQuery
      .orderBy(desc(loadingOperations.createdAt))
      .limit(limit)
      .offset(offset);
    
    // Convert the result to the LoadingOperation type
    return result.map(op => ({
      id: op.id,
      status: op.status,
      referenceNumber: op.referenceNumber,
      vehicleNumber: op.vehicleNumber,
      createdById: op.createdById,
      createdAt: op.createdAt,
      completedAt: op.completedAt,
      notes: op.notes,
      orderDate: op.orderDate,
      isBackedUp: op.isBackedUp,
      creatorName: op.creatorName,
      creatorUsername: op.creatorUsername,
      creatorRole: op.creatorRole
    }));
  }

  async countLoadingOperationsByStatus(status: string, orderDate?: Date): Promise<number> {
    // If exact order date is provided, use it for filtering
    if (orderDate) {
      // Create start and end of the specified day
      const startOfDay = new Date(orderDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(orderDate);
      endOfDay.setHours(23, 59, 59, 999);

      const result = await db.select({ count: sql<number>`count(*)` })
        .from(loadingOperations)
        .where(
          and(
eq(loadingOperations.status, status),
            gte(loadingOperations.orderDate, startOfDay),
            lte(loadingOperations.orderDate, endOfDay)
          )
        );
      return result[0]?.count || 0;
    }

    // Without date filter, just count by status
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(loadingOperations)      .where(eq(loadingOperations.status, status));
    return result[0]?.count || 0;
  }

  async getLoadingOperationItems(loadingOperationId: number): Promise<LoadingOpItem[]> {
    try {
      // Query the loading_operations_items table for items associated with the given loadingOperationId
      const items = await db
        .select()
        .from(loadingOpItems)
        .where(eq(loadingOpItems.gjOperationsId, loadingOperationId));

      return items;
    } catch (error) {
      console.error(`Error fetching load operation items for load operation ID ${loadingOperationId}:`, error);
      return [];
    }
  }
  
  // Keep backwards compatibility with old method name
  // Legacy method renamed to match new naming convention
  async getGJOperationItems(loadingOperationId: number): Promise<LoadingOpItem[]> {
    return this.getLoadingOperationItems(loadingOperationId);
  }
  
  // Add a new item to a loading operation
  async createLoadingOperationItem(item: InsertLoadingOpItem): Promise<LoadingOpItem> {
    try {
      const result = await db.insert(loadingOpItems).values(item).returning();
      return result[0];
    } catch (error) {
      console.error(`Error creating loading operation item:`, error);
      throw error;
    }
  }
  
  // Create multiple loading operation items in a batch
  async createLoadingOperationItems(items: InsertLoadingOpItem[]): Promise<LoadingOpItem[]> {
    if (!items.length) return [];
    
    try {
      // Make sure ID field is excluded for each item to allow auto-generation
      const cleanedItems = items.map(item => {
        // Create a new object without the 'id' property
        const { id, ...cleanedItem } = item as any;
        
        // Ensure gjOperationsId is set if loadOperationsId is provided
        if (cleanedItem.loadOperationsId && !cleanedItem.gjOperationsId) {
          cleanedItem.gjOperationsId = cleanedItem.loadOperationsId;
          // Remove the virtual field that's not in the database
          delete cleanedItem.loadOperationsId;
        }
        
        console.log(`Creating load operation item: ${JSON.stringify(cleanedItem)}`);
        return cleanedItem;
      });
      
      const result = await db.insert(loadingOpItems).values(cleanedItems).returning();
      return result;
    } catch (error) {
      console.error(`Error creating multiple loading operation items:`, error);
      throw error;
    }
  }

  // Purchase operations
  async createPurchase(purchase: InsertPurchase): Promise<Purchase> {
    const result = await db.insert(purchases).values(purchase).returning();
    return result[0];
  }

  async getPurchase(id: number): Promise<Purchase | undefined> {
    const result = await db.select().from(purchases).where(eq(purchases.id, id)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async updatePurchase(id: number, purchase: Partial<InsertPurchase>): Promise<Purchase | undefined> {
    const result = await db.update(purchases).set(purchase).where(eq(purchases.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deletePurchase(id: number): Promise<boolean> {
    const result = await db.delete(purchases).where(eq(purchases.id, id)).returning({ id: purchases.id });
    return result.length > 0;
  }

  async listPurchases(limit = 100, offset = 0): Promise<Purchase[]> {
    return await db.select().from(purchases).orderBy(desc(purchases.createdAt)).limit(limit).offset(offset);
  }

  // Sales operations
  async createSale(sale: InsertSale): Promise<Sale> {
    const result = await db.insert(sales).values(sale).returning();
    return result[0];
  }

  async getSale(id: number): Promise<Sale | undefined> {
    const result = await db.select().from(sales).where(eq(sales.id, id)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async updateSale(id: number, sale: Partial<InsertSale>): Promise<Sale | undefined> {
    const result = await db.update(sales).set(sale).where(eq(sales.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deleteSale(id: number): Promise<boolean> {
    const result = await db.delete(sales).where(eq(sales.id, id)).returning({ id: sales.id });
    return result.length > 0;
  }

  async listSales(limit = 100, offset = 0): Promise<Sale[]> {
    return await db.select().from(sales).orderBy(desc(sales.createdAt)).limit(limit).offset(offset);
  }

  // Sale items operations using the database
  async setSaleItems(saleId: number, items: any[]): Promise<void> {
    try {
      console.log(`Setting ${items.length} items for sale ID ${saleId}`);
      
      // Special case: for problematic sales IDs (e.g., 1631), use a different approach
      const PROBLEMATIC_SALES = [1631, 1485, 1562];
      
      if (PROBLEMATIC_SALES.includes(saleId)) {
        console.log(`Special handling for known problematic sale ID ${saleId}`);
        
        // First: we need to delete ALL items in the sale_items table for this sale
        try {
          // Regular deletion may fail due to constraints
          await db.delete(saleItems).where(eq(saleItems.saleId, saleId));
          console.log(`Successfully cleared items for problematic sale ID ${saleId}`);
        } catch (deleteError) {
          console.log(`Standard deletion failed for sale ${saleId}, trying raw SQL deletion`);
          
          try {
            // Attempt to force delete with raw SQL
            await db.execute(sql`DELETE FROM "sale_items" WHERE "sale_id" = ${saleId}`);
            console.log(`Successfully cleared items using raw SQL for sale ID ${saleId}`);
          } catch (rawDeleteError) {
            console.error(`Failed to delete items for sale ${saleId} even with raw SQL:`, rawDeleteError);
          }
        }
      } else {
        // For non-problematic sales, use standard deletion
        try {
          await db.delete(saleItems).where(eq(saleItems.saleId, saleId));
          console.log(`Deleted existing items for sale ID ${saleId}`);
        } catch (deleteError) {
          console.warn(`Error deleting existing items for sale ID ${saleId}:`, deleteError);
        }
      }
      
      // Check if we have any items after deletion (should be zero, but check to be sure)
      const checkItems = await db.select({ count: sql`count(*)` }).from(saleItems).where(eq(saleItems.saleId, saleId));
      console.log(`After deletion, sale ${saleId} has ${Number(checkItems[0]?.count || 0)} items`);
      
      // Then insert all the new items
      if (items && items.length > 0) {
        // Map each item, NEVER include the original item's ID to avoid primary key conflicts
        const saleItemsToInsert = items.map(item => {
          // Create a clean object without any id field
          return {
            saleId,
            sku: item.sku || null,
            barcode: item.barcode || null,
            name: item.name || item.itemName || "Unknown Item",
            quantity: item.quantity || 0,
            unitPrice: item.unitPrice?.toString() || "0",
            totalPrice: item.totalPrice?.toString() || 
                      ((item.unitPrice || 0) * (item.quantity || 0)).toString(),
            category: item.category || null,
            hsn: item.hsn || null,
            originalQuantity: item.originalQuantity || item.quantity || 0
          };
        });
        
        // Generate inserts with explicit SQL to avoid id conflicts
        let successCount = 0;
        let errorCount = 0;
        
        // Use a single approach for ALL sales - raw SQL with explicit column names (no id)
        // This prevents any primary key conflicts by letting the database handle auto-increment
        for (const item of saleItemsToInsert) {
          try {
            await db.execute(sql`
              INSERT INTO "sale_items" 
              ("sale_id", "sku", "barcode", "name", "quantity", "unit_price", "total_price", "category", "hsn", "original_quantity") 
              VALUES 
              (${item.saleId}, ${item.sku}, ${item.barcode}, ${item.name}, ${item.quantity}, ${item.unitPrice}, 
               ${item.totalPrice}, ${item.category}, ${item.hsn}, ${item.originalQuantity})
            `);
            successCount++;
          } catch (insertError) {
            console.error(`Failed to insert item with raw SQL:`, insertError);
            errorCount++;
          }
        }
        
        console.log(`Completed item insertion for sale ID ${saleId}: ${successCount} successful, ${errorCount} failed`);
      }
      
      // Check if we managed to insert any items at all
      const itemCount = await db.select({ count: sql`count(*)` }).from(saleItems).where(eq(saleItems.saleId, saleId));
      const count = Number(itemCount[0]?.count || 0);
      
      if (count > 0) {
        console.log(`Successfully set ${count} items for sale ID ${saleId}`);
      } else {
        console.warn(`No items were successfully inserted for sale ID ${saleId}`);
      }
    } catch (error) {
      console.error(`Error setting items for sale ID ${saleId}:`, error);
      throw error;
    }
  }

  async getSaleItems(saleId: number): Promise<any[]> {
    try {
      const items = await db.select().from(saleItems).where(eq(saleItems.saleId, saleId));
      return items.map(item => ({
        ...item,
        unitPrice: item.unitPrice ? parseFloat(item.unitPrice) : 0,
        totalPrice: item.totalPrice ? parseFloat(item.totalPrice) : 0,
      }));
    } catch (error) {
      console.error(`Error retrieving sale items for ID ${saleId}:`, error);
      return [];
    }
  }

  async deleteSaleItems(saleId: number): Promise<boolean> {
    const result = await db.delete(saleItems).where(eq(saleItems.saleId, saleId));
    return true;
  }

  // Proforma Slip operations
  async createProformaSlip(slip: InsertProformaSlip): Promise<ProformaSlip> {
    const result = await db.insert(proformaSlips).values(slip).returning();
    return result[0];
  }

  async getProformaSlip(id: number): Promise<ProformaSlip | undefined> {
    const result = await db.select().from(proformaSlips).where(eq(proformaSlips.id, id)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async getProformaSlipByOrderNumber(orderNumber: string): Promise<ProformaSlip | undefined> {
    const result = await db.select().from(proformaSlips).where(eq(proformaSlips.orderNumber, orderNumber)).limit(1);
    return result.length ? result[0] : undefined;
  }

  async getProformaSlipsByOrderNumbers(orderNumbers: string[]): Promise<ProformaSlip[]> {
    if (!orderNumbers.length) return [];

    // Use the 'in' operator to fetch multiple slips in a single query
    const result = await db.select()
      .from(proformaSlips)
      .where(inArray(proformaSlips.orderNumber, orderNumbers));

    return result || [];
  }

  async updateProformaSlip(id: number, slip: Partial<InsertProformaSlip>): Promise<ProformaSlip | undefined> {
    const result = await db.update(proformaSlips).set(slip).where(eq(proformaSlips.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deleteProformaSlip(id: number): Promise<boolean> {
    // First delete all items
    await db.delete(proformaSlipItems).where(eq(proformaSlipItems.proformaSlipId, id));
    // Then delete the slip
    const result = await db.delete(proformaSlips).where(eq(proformaSlips.id, id)).returning({ id: proformaSlips.id });
    return result.length > 0;
  }

  async listProformaSlips(limit = 100, offset = 0): Promise<ProformaSlip[]> {
    return await db.select().from(proformaSlips).orderBy(desc(proformaSlips.createdAt)).limit(limit).offset(offset);
  }

  // Proforma Slip Item operations
  async createProformaSlipItem(item: InsertProformaSlipItem): Promise<ProformaSlipItem> {
    const result = await db.insert(proformaSlipItems).values(item).returning();
    return result[0];
  }

  // Batch create multiple items at once for better performance
  async batchCreateProformaSlipItems(items: InsertProformaSlipItem[]): Promise<ProformaSlipItem[]> {
    if (items.length === 0) {
      return [];
    }

    console.log(`Batch creating ${items.length} proforma slip items`);
    const result = await db.insert(proformaSlipItems).values(items).returning();
    return result;
  }

  async getProformaSlipItems(proformaSlipId: number): Promise<ProformaSlipItem[]> {
    return await db.select()
      .from(proformaSlipItems)
      .where(eq(proformaSlipItems.proformaSlipId, proformaSlipId))
      .orderBy(asc(proformaSlipItems.id));
  }

  async getProformaSlipItemsByIds(itemIds: number[]): Promise<ProformaSlipItem[]> {
    if (!itemIds || itemIds.length === 0) {
      return [];
    }

    return await db.select()
      .from(proformaSlipItems)
      .where(inArray(proformaSlipItems.id, itemIds))
      .orderBy(asc(proformaSlipItems.id));
  }
  
  async getProformaSlipItem(id: number): Promise<ProformaSlipItem | undefined> {
    const items = await db.select()
      .from(proformaSlipItems)
      .where(eq(proformaSlipItems.id, id))
      .limit(1);
    
    return items.length > 0 ? items[0] : undefined;
  }

  async updateProformaSlipItem(id: number, item: Partial<InsertProformaSlipItem>): Promise<ProformaSlipItem | undefined> {
    const result = await db.update(proformaSlipItems).set(item).where(eq(proformaSlipItems.id, id)).returning();
    return result.length ? result[0] : undefined;
  }

  async deleteProformaSlipItem(id: number): Promise<boolean> {
    const result = await db.delete(proformaSlipItems).where(eq(proformaSlipItems.id, id)).returning({ id: proformaSlipItems.id });
    return result.length > 0;
  }

  // Backup operations - still using MemStorage for compatibility
  private backupSettings = new Map<number, BackupSettings>();
  private scanHistoryBackups = new Map<number, ScanHistoryBackup>();
  private loadingOpBackups = new Map<number, LoadingOperationBackup>();
  private saleBackups = new Map<number, SaleBackup>();
  private proformaSlipBackups = new Map<number, ProformaSlipBackup>();
  private proformaSlipItemBackups = new Map<number, ProformaSlipItemBackup>();
  private saleBackupItems = new Map<number, any[]>();
  private loadingOpBackupItems = new Map<number, any[]>();

  private backupSettingsId = 1;
  private scanHistoryBackupId = 1;
  private loadingOpBackupId = 1;
  private saleBackupId = 1;
  private proformaSlipBackupId = 1;
  private proformaSlipItemBackupId = 1;

  // Backup settings
  async getBackupSettings(): Promise<BackupSettings | undefined> {
    const result = await db.select().from(backupSettings).limit(1);
    return result.length ? result[0] : undefined;
  }

  async createBackupSettings(settings: InsertBackupSettings): Promise<BackupSettings> {
    // Use in-memory for backup settings
    const id = this.backupSettingsId++;
    const now = new Date();
    const newSettings: BackupSettings = {
      id,
      frequency: settings.frequency,
      lastRun: null,
      retentionPeriod: settings.retentionPeriod,
      createdAt: now,
      updatedAt: now,
    };
    this.backupSettings.set(id, newSettings);
    return newSettings;
  }

  async updateBackupSettings(id: number, settings: Partial<InsertBackupSettings>): Promise<BackupSettings | undefined> {
    const existingSettings = this.backupSettings.get(id);
    if (!existingSettings) return undefined;

    const updatedSettings = {
      ...existingSettings,
      ...settings,
      updatedAt: new Date()
    };

    this.backupSettings.set(id, updatedSettings);
    return updatedSettings;
  }

  // Message operations
  private messages = new Map<number, Message>();
  private messageId = 1;

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();
    const newMessage: Message = {
      id,
      ...message,
      isRead: false,
      createdAt: now,
      updatedAt: now,
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async updateMessage(id: number, message: Partial<InsertMessage>): Promise<Message | undefined> {
    const existingMessage = this.messages.get(id);
    if (!existingMessage) return undefined;

    const updatedMessage = {
      ...existingMessage,
      ...message,
      updatedAt: new Date()
    };

    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }

  async deleteMessage(id: number): Promise<boolean> {
    return this.messages.delete(id);
  }

  async listMessages(limit = 10, offset = 0): Promise<Message[]> {
    return Array.from(this.messages.values())
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  async getMessagesForUser(userId: number, limit = 10, offset = 0): Promise<Message[]> {
    // Get user for department/designation checks
    const user = await this.getUser(userId);

    return Array.from(this.messages.values())
      .filter(message => 
        message.recipientId === userId || 
        message.broadcastToAll === true ||
        (message.broadcastToDepartment && user?.department === message.broadcastToDepartment) ||
        (message.broadcastToDesignation && user?.designation === message.broadcastToDesignation)
      )
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  async getConversation(user1Id: number, user2Id: number, limit = 20, offset = 0): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        (message.senderId === user1Id && message.recipientId === user2Id) ||
        (message.senderId === user2Id && message.recipientId === user1Id)
      )
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : a.createdAt ? new Date(a.createdAt) : null;
        const dateB = b.createdAt instanceof Date ? b.createdAt : b.createdAt ? new Date(b.createdAt) : null;

        return (dateA?.getTime() || 0) - (dateB?.getTime() || 0);
      })
      .slice(offset, offset + limit);
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;

    const updatedMessage = {
      ...message,
      isRead: true
    };

    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }

  async getUnreadMessageCount(userId: number): Promise<number> {
    // Get user for department/designation checks
    const user = await this.getUser(userId);

    return Array.from(this.messages.values())
      .filter(message => 
        !message.isRead && 
        (message.recipientId === userId || 
         message.broadcastToAll === true ||
         (message.broadcastToDepartment && user?.department === message.broadcastToDepartment) ||
         (message.broadcastToDesignation && user?.designation === message.broadcastToDesignation))
      )
      .length;
  }

  // Following methods are implemented using in-memory storage for compatibility
  // These can be migrated to database tables in the future if needed

  async backupScanHistory(scanHistoryId: number): Promise<ScanHistoryBackup> {
    const id = this.scanHistoryBackupId++;
    const now = new Date();
    const backup: ScanHistoryBackup = {
      id,
      scanHistoryId,
      details: JSON.stringify({}),
      createdAt: now,
      updatedAt: now,
    };
    this.scanHistoryBackups.set(id, backup);
    return backup;
  }

  async backupLoadingOperation(loadingOperationId: number): Promise<LoadingOperationBackup> {
    const id = this.loadingOpBackupId++;
    const now = new Date();
    const backup: LoadingOperationBackup = {
      id,
      loadingOperationId,
      details: JSON.stringify({}),
      createdAt: now,
      updatedAt: now,
    };
    this.loadingOpBackups.set(id, backup);
    return backup;
  }

  async backupSale(saleId: number): Promise<SaleBackup> {
    const id = this.saleBackupId++;
    const now = new Date();
    const backup: SaleBackup = {
      id,
      saleId,
      details: JSON.stringify({}),
      createdAt: now,
      updatedAt: now,
    };
    this.saleBackups.set(id, backup);
    return backup;
  }

  async backupProformaSlip(proformaSlipId: number): Promise<ProformaSlipBackup> {
    const id = this.proformaSlipBackupId++;
    const now = new Date();
    const backup: ProformaSlipBackup = {
      id,
      proformaSlipId,
      details: JSON.stringify({}),
      createdAt: now,
      updatedAt: now,
    };
    this.proformaSlipBackups.set(id, backup);
    return backup;
  }

  async backupProformaSlipItem(slipItemId: number, proformaSlipBackupId: number): Promise<ProformaSlipItemBackup> {
    const id = this.proformaSlipItemBackupId++;
    const now = new Date();
    const backup: ProformaSlipItemBackup = {
      id,
      slipItemId,
      proformaSlipBackupId,
      details: JSON.stringify({}),
      createdAt: now,
      updatedAt: now,
    };
    this.proformaSlipItemBackups.set(id, backup);
    return backup;
  }

  async listScanHistoryBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0): Promise<ScanHistoryBackup[]> {
    return [];
  }

  async listLoadingOperationBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0, orderDate?: Date): Promise<LoadingOperationBackup[]> {
    // Return empty array as loadingOperationsBackup table isn't defined yet
    // This prevents the 500 error when accessing backup endpoints
    return [];
  }

  async listSaleBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0): Promise<SaleBackup[]> {
    return [];
  }

  async listProformaSlipBackups(startDate?: Date, endDate?: Date, limit = 100, offset = 0): Promise<ProformaSlipBackup[]> {
    return [];
  }

  async listProformaSlipItemBackups(proformaSlipBackupId: number): Promise<ProformaSlipItemBackup[]> {
    return [];
  }

  async getSaleBackupItems(backupId: number): Promise<any[]> {
    return this.saleBackupItems.get(backupId) || [];
  }

  async getLoadingOperationBackupItems(backupId: number): Promise<any[]> {
    return this.loadingOpBackupItems.get(backupId) || [];
  }

  async deleteLoadingOperationBackup(backupId: number): Promise<boolean> {
    return this.loadingOpBackups.delete(backupId);
  }

  async deleteProformaSlipBackup(backupId: number): Promise<boolean> {
    return this.proformaSlipBackups.delete(backupId);
  }

  async deleteProformaSlipBackups(backupIds: number[]): Promise<number> {
    let deletedCount = 0;
    for (const id of backupIds) {
      if (this.proformaSlipBackups.delete(id)) {
        deletedCount++;
      }
    }
    return deletedCount;
  }

  async runBackupOperation(): Promise<{
    scansBackedUp: number,
    loadingOpsBackedUp: number,
    salesBackedUp: number,
    proformaSlipsBackedUp: number
  }> {
    return {
      scansBackedUp: 0,
      loadingOpsBackedUp: 0,
      salesBackedUp: 0,
      proformaSlipsBackedUp: 0
    };
  }

  async applyDataRetentionPolicies(): Promise<{
    loadingOpsDeleted: number
  }> {
    return {
      loadingOpsDeleted: 0
    };
  }

  // Method to reset only the sold counts to zero
  async resetSoldCounts(): Promise<number> {
    let updatedCount = 0;

    // Get all products
    const allProducts = await db.select().from(products);

    // Update each product's sold count to 0
    for (const product of allProducts) {
      await db.update(products)
        .set({ sold: 0, lastUpdated: new Date() })
        .where(eq(products.id, product.id));
      updatedCount++;
    }

    console.log(`Reset sold counts to zero for ${updatedCount} products`);
    return updatedCount;
  }

  // Method to delete a sale backup
  async deleteSaleBackup(backupId: number): Promise<boolean> {
    const result = await db.delete(salesBackup)
      .where(eq(salesBackup.id, backupId))
      .returning({ id: salesBackup.id });

    return result.length > 0;
  }

  // Activity tracking operations
  async createActivity(activity: InsertActivity): Promise<Activity> {
    return await db.insert(activities).values(activity).returning().then(res => res[0]);
  }

  async logActivity(activity: {
    pageName: string;
    action: string;
    entityType: string;
    entityId: string | number;
    details: string | object;
    userId?: number;
    userName?: string;
  }): Promise<Activity> {
    // Format details if it's an object
    const detailsStr = typeof activity.details === 'string' 
      ? activity.details 
      : JSON.stringify(activity.details);
    
    // Convert entityId to string if it's a number
    const entityIdStr = typeof activity.entityId === 'number' 
      ? activity.entityId.toString() 
      : activity.entityId;
    
    // Create activity entry
    return await this.createActivity({
      pageName: activity.pageName,
      action: activity.action,
      entityType: activity.entityType,
      entityId: entityIdStr,
      details: detailsStr,
      userId: activity.userId,
      userName: activity.userName
    });
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    return await db.select().from(activities).where(eq(activities.id, id)).then(res => res[0]);
  }

  async deleteActivity(id: number): Promise<boolean> {
    return await db.delete(activities).where(eq(activities.id, id)).then(() => true);
  }

  async listActivities(limit: number = 100, offset: number = 0): Promise<Activity[]> {
    return await db.select().from(activities).orderBy(desc(activities.createdAt)).limit(limit).offset(offset);
  }

  async getActivitiesByPage(pageName: string, limit: number = 100, offset: number = 0): Promise<Activity[]> {
    return await db.select().from(activities)
      .where(eq(activities.pageName, pageName))
      .orderBy(desc(activities.createdAt))
      .limit(limit).offset(offset);
  }

  async getActivitiesByAction(action: string, limit: number = 100, offset: number = 0): Promise<Activity[]> {
    return await db.select().from(activities)
      .where(eq(activities.action, action))
      .orderBy(desc(activities.createdAt))
      .limit(limit).offset(offset);
  }

  async getEntityActivities(entityType: string, entityId: string, limit: number = 100): Promise<Activity[]> {
    return await db.select().from(activities)
      .where(and(
        eq(activities.entityType, entityType),
        eq(activities.entityId, entityId)
      ))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }

  // Delete activities older than 30 days
  async deleteOldActivities(daysToKeep: number = 30): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    const result = await db.delete(activities)
      .where(lt(activities.createdAt, cutoffDate.toISOString()))
      .returning();

    console.log(`Deleted ${result.length} activities older than ${daysToKeep} days (before ${cutoffDate.toISOString()})`);
    return result.length;
  }

  // Delete test activities
  async deleteTestActivities(): Promise<number> {
    // Delete activities with pageName='Test' or action='test'
    const result = await db.delete(activities)
      .where(or(
        eq(activities.pageName, 'Test'),
        eq(activities.action, 'test')
      ))
      .returning();

    console.log(`Deleted ${result.length} test activities`);
    return result.length;
  }

  // Vehicle Info operations
  async createVehicleInfo(vehicle: InsertVehicleInfo): Promise<VehicleInfo> {
    try {
      const now = new Date();
      // Set the creation and last edited timestamps
      const vehicleData = {
        ...vehicle,
        lastEditedAt: now,
        createdAt: now
      };

      const [result] = await db.insert(vehicleInfo).values(vehicleData).returning();
      return result;
    } catch (error) {
      console.error("Error creating vehicle info:", error);
      throw error;
    }
  }

  async getVehicleInfo(id: number): Promise<VehicleInfo | undefined> {
    try {
      const [result] = await db.select().from(vehicleInfo).where(eq(vehicleInfo.id, id)).limit(1);
      return result;
    } catch (error) {
      console.error("Error getting vehicle info:", error);
      return undefined;
    }
  }

  async getVehicleInfoByVehicleNumber(vehicleNumber: string): Promise<VehicleInfo | undefined> {
    try {
      const [result] = await db.select().from(vehicleInfo).where(eq(vehicleInfo.vehicleNumber, vehicleNumber)).limit(1);
      return result;
    } catch (error) {
      console.error("Error getting vehicle info by vehicle number:", error);
      return undefined;
    }
  }

  async updateVehicleInfo(id: number, vehicle: Partial<InsertVehicleInfo>): Promise<VehicleInfo | undefined> {
    try {
      // Update the last edited timestamp
      const updatedVehicle = {
        ...vehicle,
        lastEditedAt: new Date(),
      };

      const [result] = await db.update(vehicleInfo)
        .set(updatedVehicle)
        .where(eq(vehicleInfo.id, id))
        .returning();

      return result;
    } catch (error) {
      console.error("Error updating vehicle info:", error);
      return undefined;
    }
  }

  async deleteVehicleInfo(id: number): Promise<boolean> {
    try {
      await db.delete(vehicleInfo).where(eq(vehicleInfo.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting vehicle info:", error);
      return false;
    }
  }

  async listVehicleInfo(limit = 100, offset = 0): Promise<VehicleInfo[]> {
    try {
      const results = await db.select()
        .from(vehicleInfo)
        .orderBy(asc(vehicleInfo.srNo))
        .limit(limit)
        .offset(offset);

      return results;
    } catch (error) {
      console.error("Error listing vehicle info:", error);
      return [];
    }
  }
}

// Initialize the database storage
export const storage = new DBStorage();