/**
 * This module provides functions for deleting all existing sales entries 
 * and regenerating them based on loading operations with READY≈DESP status.
 */

import { db } from './db';
import { sql, eq, like } from 'drizzle-orm';
import { sales, saleItems, loadingOperations, loadingOpItems, proformaSlips, activities, users } from '../shared/schema';

// Main function to regenerate all sales data
export async function regenerateAllSales() {
  console.log('Starting sales regeneration...');
  
  try {
    // Step 1: Count existing sales and sale items for reporting
    const existingSalesCount = await db.select({ count: sql`count(*)` }).from(sales);
    const existingSaleItemsCount = await db.select({ count: sql`count(*)` }).from(saleItems);
    
    console.log(`Found ${existingSalesCount[0].count} existing sales with ${existingSaleItemsCount[0].count} items`);
    
    // Step 2: Delete all sale items first (due to foreign key constraints)
    console.log('Deleting all sale items...');
    await db.delete(saleItems);
    
    // Step 3: Delete all sales
    console.log('Deleting all sales...');
    await db.delete(sales);
    
    // Step 4: Get all loading operations with READY≈DESP status
    // Note: We check both "READY≈DESP" and "READY DESP" and "PENDING DESP" for compatibility
    console.log('Finding loading operations with READY≈DESP status...');
    const readyOps = await db.select()
      .from(loadingOperations)
      .where(
        sql`(${loadingOperations.status} LIKE '%READY%DESP%' OR ${loadingOperations.status} = 'PENDING DESP')`
      );
    
    console.log(`Found ${readyOps.length} loading operations with READY≈DESP status`);
    
    // Step 5: Create sales entries for each ready loading operation
    console.log('Creating new sales entries...');
    
    let createdSalesCount = 0;
    let createdItemsCount = 0;
    let errorCount = 0;
    
    for (const op of readyOps) {
      try {
        // Get the operation items to calculate total quantity
        const opItems = await db.select()
          .from(loadingOpItems)
          .where(eq(loadingOpItems.gjOperationsId, op.id));
        
        // Get the corresponding proforma slip to get party name and plant
        let proformaData = null;
        if (op.referenceNumber) {
          const proformaResults = await db.select()
            .from(proformaSlips)
            .where(eq(proformaSlips.orderNumber, op.referenceNumber));
          
          if (proformaResults.length > 0) {
            proformaData = proformaResults[0];
            console.log(`Found matching proforma slip for order ${op.referenceNumber}`);
          } else {
            console.log(`No matching proforma slip found for order ${op.referenceNumber}`);
          }
        }
        
        // Calculate total quantity - use loaded_quantity but fall back to original_quantity or quantity
        const totalQuantity = opItems.reduce((sum, item) => {
          // If loadedQuantity is available and > 0, use it; otherwise use originalQuantity or quantity
          const itemQuantity = item.loadedQuantity > 0 
            ? item.loadedQuantity 
            : item.originalQuantity > 0 
              ? item.originalQuantity 
              : item.quantity || 0;
          return sum + itemQuantity;
        }, 0);
        
        // Prepare the dealer/party name
        // First try to get from proforma slip, then from notes
        const dealerName = (proformaData && proformaData.partyName) 
          ? proformaData.partyName 
          : extractDealerFromNotes(op.notes) || 'Unknown';
        
        // Prepare the date (use createdAt if available, otherwise use current date)
        const dateStr = op.createdAt 
          ? formatDate(op.createdAt) 
          : formatDate(new Date());
        
        // Create the sale entry
        const newSale = {
          orderNumber: op.referenceNumber,
          date: dateStr,
          status: 'READY≈DESP',
          createdById: 1, // Admin user ID
          quantity: totalQuantity, // This is already an integer
          notes: op.notes || '',
          dealer: dealerName, // We correctly map party_name to dealer field in sales table
          vehicleNumber: op.vehicleNumber || '',
          plant: (proformaData && proformaData.plant) ? proformaData.plant : null,
          // Convert amount to integer as per DB schema
          amount: parseInt(calculateTotalAmount(opItems)) || 0
        };
        
        console.log("Creating new sale:", JSON.stringify(newSale));
        
        // Insert the sale record
        const [createdSale] = await db.insert(sales).values(newSale).returning();
        createdSalesCount++;
        
        console.log(`Created sale #${createdSale.id} for order ${op.referenceNumber} with ${opItems.length} items`);
        
        // Log activity for creating a sale during regeneration
        try {
          // Create activity details
          const activityDetails = JSON.stringify({
            orderNumber: createdSale.orderNumber,
            dealer: createdSale.dealer,
            quantity: createdSale.quantity,
            amount: createdSale.amount,
            status: createdSale.status
          });
          
          // Determine user name (if available)
          const userId = op.createdById || 1;
          let userName = "System (Regeneration)";
          
          // Get user info if possible
          if (userId) {
            const userResult = await db.select().from(users).where(eq(users.id, userId)).limit(1);
            if (userResult.length > 0) {
              userName = userResult[0].name || userResult[0].username || "Unknown User";
            }
          }
          
          // Create the activity record
          await db.insert(activities).values({
            pageName: "Sales",
            action: "create",
            entityType: "sale",
            entityId: String(createdSale.id),
            details: activityDetails,
            userId: userId,
            userName: userName
          });
          
          console.log(`Created activity record for regenerated sale #${createdSale.id}`);
        } catch (activityError) {
          console.error(`Error creating activity for regenerated sale #${createdSale.id}:`, activityError);
          // Don't fail the process if activity creation fails
        }
        
        // Now create sale items for each loading operation item
        if (opItems.length > 0) {
          // For each item in the load operation, create a corresponding sale item
          const saleItemsToInsert = opItems.map(item => {
            // Use loaded_quantity if available and > 0, otherwise fall back to original_quantity or quantity
            const quantity = (item.loadedQuantity && item.loadedQuantity > 0) 
              ? item.loadedQuantity 
              : (item.originalQuantity && item.originalQuantity > 0) 
                ? item.originalQuantity 
                : (item.quantity && item.quantity > 0) 
                  ? item.quantity 
                  : 0;
            
            const unitPrice = calculateUnitPrice(item);
            const totalPrice = unitPrice * quantity;
            
            return {
              saleId: createdSale.id,
              sku: item.barcode || null, // Use barcode as SKU
              barcode: item.barcode || null, // Store barcode for display in SAP code field
              name: item.itemName || 'Unknown Item',
              // Use the properly calculated quantity value
              quantity: quantity, 
              unitPrice: unitPrice.toString(), // Convert to string for DB
              // Calculate total price properly from quantity and unit price
              totalPrice: totalPrice.toString(), // Convert to string for DB
              category: null, // We don't have this info in the loading op items
              hsn: null, // We don't have this info in the loading op items
              originalQuantity: item.originalQuantity || quantity || 0,
              // Set proper defaults for the extra fields
              remainQuantity: item.originalQuantity || quantity || 0,
              extraQuantity: 0
            };
          });
          
          // Insert items in batches of 50
          const BATCH_SIZE = 50;
          for (let i = 0; i < saleItemsToInsert.length; i += BATCH_SIZE) {
            const batch = saleItemsToInsert.slice(i, i + BATCH_SIZE);
            await db.insert(saleItems).values(batch);
            createdItemsCount += batch.length;
          }
          
          console.log(`Created ${saleItemsToInsert.length} items for sale #${createdSale.id}`);
        } else {
          console.log(`Warning: No items found for operation ${op.id}, sale created with 0 items`);
        }
      } catch (error) {
        console.error(`Error processing operation ${op.id}:`, error);
        errorCount++;
      }
    }
    
    // Final report
    const report = `
    Sales regeneration completed:
    - Created ${createdSalesCount} new sales (from ${readyOps.length} operations)
    - Created ${createdItemsCount} new sale items
    - Encountered errors with ${errorCount} operations
    `;
    
    console.log(report);
    return { 
      success: true,
      message: report,
      stats: {
        salesCreated: createdSalesCount,
        itemsCreated: createdItemsCount,
        errors: errorCount,
        totalOperations: readyOps.length
      }
    };
    
  } catch (error) {
    console.error('Fatal error during sales regeneration:', error);
    return { 
      success: false, 
      message: `Error during sales regeneration: ${error.message || error}`,
      error: error 
    };
  }
}

// Helper function to extract dealer name from notes field
function extractDealerFromNotes(notes: string | null): string | null {
  if (!notes) return null;
  
  // Common pattern in notes: "Party: NAME" or "Dealer: NAME"
  const partyMatch = notes.match(/Party:\s*([^,\n]+)/i);
  if (partyMatch && partyMatch[1]) return partyMatch[1].trim();
  
  const dealerMatch = notes.match(/Dealer:\s*([^,\n]+)/i);
  if (dealerMatch && dealerMatch[1]) return dealerMatch[1].trim();
  
  return null;
}

// Helper function to calculate unit price (this is approximate since we don't have actual price data)
function calculateUnitPrice(item: any): number {
  // If we have a price directly, use it
  if (item.price && !isNaN(parseFloat(item.price))) {
    return parseFloat(item.price);
  }
  
  // Default prices based on common product types
  return 750; // Default price if we don't have pricing data
}

// Helper function to calculate total amount
function calculateTotalAmount(items: any[]): string {
  const total = items.reduce((sum, item) => {
    const unitPrice = calculateUnitPrice(item);
    // Use loaded_quantity if available and > 0, otherwise fall back to original_quantity or quantity
    const quantity = item.loadedQuantity > 0 
      ? item.loadedQuantity 
      : item.originalQuantity > 0 
        ? item.originalQuantity 
        : item.quantity || 0;
    return sum + (unitPrice * quantity);
  }, 0);
  
  return total.toString();
}

// Helper function to format dates
function formatDate(date: Date | string): string {
  const d = date instanceof Date ? date : new Date(date);
  const day = d.getDate().toString().padStart(2, '0');
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const year = d.getFullYear();
  return `${day}-${month}-${year}`;
}