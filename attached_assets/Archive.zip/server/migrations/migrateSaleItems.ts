import nodePersist from 'node-persist';
import { storage } from '../storage';
import { eq } from 'drizzle-orm';
import { db } from '../db';
import { sales, saleItems, loadingOpItems } from '@shared/schema';

/**
 * Helper function to generate and store sale items from a list of items
 * Works with both loading operation items and proforma slip items
 */
async function generateSaleItemsFromItems(saleId: number, saleData: any, items: any[]) {
  try {
    // Generate sale items from the provided items
    const generatedItems = [];
    
    for (const item of items) {
      // Get product details if available
      let product = null;
      if (item.productId) {
        product = await storage.getProduct(item.productId);
      }
      
      // Get the actual loaded quantity
      const quantity = item.loadedQuantity || item.quantity || 0;
      
      if (quantity > 0) {
        // Set default values
        let name = item.itemName || 'Unknown Item';
        let barcode = null;
        let sku = '';
        let category = null;
        let hsn = null;
        let unitPrice = 0;
        
        // Override with product data if available
        if (product) {
          name = product.name || name;
          barcode = product.barcode || barcode;
          sku = product.srNo || sku;
          category = product.category || category;
          hsn = product.hsnCode || hsn;
          unitPrice = product.sellingPrice ? parseFloat(product.sellingPrice) : 0;
        }
        
        const totalPrice = unitPrice * quantity;
        
        // Get original quantity from the item
        const originalItemQuantity = item.originalQuantity || quantity;
        
        console.log(`Generated Item - Product: ${name}, Quantity: ${quantity}, Unit Price: ${unitPrice}, Total: ${totalPrice}`);
        
        generatedItems.push({
          sku: barcode, // Use barcode as SKU to match sales dialog display
          barcode: barcode,
          name: name,
          quantity: quantity,
          originalQuantity: originalItemQuantity,
          unitPrice: unitPrice,
          totalPrice: totalPrice,
          category: category,
          hsn: hsn
        });
      }
    }
    
    if (generatedItems.length === 0) {
      console.log(`No items with quantity found for sale ID ${saleId}`);
      return false;
    }
    
    // Store the generated items
    try {
      console.log(`Storing ${generatedItems.length} generated items for sale ID ${saleId}`);
      await storage.setSaleItems(saleId, generatedItems);
      console.log(`Successfully generated and stored items for sale ID ${saleId}`);
      return true;
    } catch (error: any) {
      console.error(`Error storing generated items for sale ID ${saleId}:`, error?.message || String(error));
      return false;
    }
  } catch (error: any) {
    console.error(`Error processing items for sale ID ${saleId}:`, error?.message || String(error));
    return false;
  }
}

/**
 * Generates sale items for a specific sale ID based on its corresponding loading operation
 * This is used to fix sales that don't have items in the database
 */
export async function generateItemsForSale(saleId: number) {
  console.log(`Attempting to generate items for sale ID ${saleId}...`);
  
  try {
    // First check if this sale already has items
    const existingItems = await db.select().from(saleItems).where(eq(saleItems.saleId, saleId));
    
    if (existingItems.length > 0) {
      console.log(`Sale ID ${saleId} already has ${existingItems.length} items, skipping generation`);
      return false;
    }
    
    // Get the sale details
    const sale = await db.select().from(sales).where(eq(sales.id, saleId)).limit(1);
    
    if (!sale.length) {
      console.log(`Sale ID ${saleId} not found in the database`);
      return false;
    }
    
    const saleData = sale[0];
    
    if (!saleData.orderNumber) {
      console.log(`Sale ID ${saleId} has no order number, cannot find corresponding operation`);
      return false;
    }
    
    // Find the corresponding load operation - try multiple approaches
    let operation = null;
    
    // First try finding by reference number (most common case)
    console.log(`Looking for loading operation with reference number ${saleData.orderNumber}`);
    operation = await storage.getLoadingOperationByReferenceNumber(saleData.orderNumber);
    
    // If not found, try by order number
    if (!operation) {
      console.log(`Looking for loading operation with order number ${saleData.orderNumber}`);
      try {
        // The method might not exist in the storage interface
        if (typeof storage.getLoadingOperationByOrderNumber === 'function') {
          operation = await storage.getLoadingOperationByOrderNumber(saleData.orderNumber);
        } else {
          console.log(`Method getLoadingOperationByOrderNumber not available, trying alternative searches`);
          
          // Get the first few loading operations and search manually
          const operations = await storage.listLoadingOperations(100, 0);
          operation = operations.find(op => 
            op.orderNumber === saleData.orderNumber || 
            (op.referenceNumber && op.referenceNumber.includes(saleData.orderNumber))
          );
          
          if (operation) {
            console.log(`Found operation ${operation.id} by manual search`);
          }
        }
      } catch (err) {
        console.log(`Error when searching by order number: ${err.message}`);
      }
    }
    
    // Try with common prefixes
    if (!operation) {
      for (const prefix of ['LB-', 'OR-', 'PO-', '#']) {
        const prefixedNumber = `${prefix}${saleData.orderNumber}`;
        console.log(`Trying variation of order number: ${prefixedNumber}`);
        
        try {
          operation = await storage.getLoadingOperationByReferenceNumber(prefixedNumber);
          if (operation) {
            console.log(`Found operation with reference number ${prefixedNumber}`);
            break;
          }
          
          // Try by order number if the method exists
          if (typeof storage.getLoadingOperationByOrderNumber === 'function') {
            operation = await storage.getLoadingOperationByOrderNumber(prefixedNumber);
            if (operation) {
              console.log(`Found operation with order number ${prefixedNumber}`);
              break;
            }
          }
        } catch (err) {
          console.log(`Error searching for variant ${prefixedNumber}: ${err.message}`);
        }
      }
    }
    
    // Last attempt: try to match by simple string comparison against all operations
    if (!operation) {
      try {
        console.log(`Trying a final search for operations related to order ${saleData.orderNumber}`);
        // Get all operations up to a reasonable limit
        const operations = await storage.listLoadingOperations(500, 0);
        
        operation = operations.find(op => {
          // Check exact matches first
          if (op.referenceNumber === saleData.orderNumber) return true;
          if (op.orderNumber === saleData.orderNumber) return true;
          
          // Then check partial matches
          if (op.referenceNumber?.includes(saleData.orderNumber)) return true;
          if (saleData.orderNumber?.includes(op.referenceNumber)) return true;
          
          return false;
        });
        
        if (operation) {
          console.log(`Found matching operation ${operation.id} in final search`);
        }
      } catch (err) {
        console.log(`Error during final operation search: ${err.message}`);
      }
    }
    
    if (!operation) {
      console.log(`No loading operation found for order number ${saleData.orderNumber}, trying proforma slip...`);
      
      // Try to find a matching proforma slip for this order number
      const proformaSlip = await storage.getProformaSlipByOrderNumber(saleData.orderNumber);
      
      if (!proformaSlip) {
        console.log(`No proforma slip found for order number ${saleData.orderNumber}`);
        return false;
      }
      
      console.log(`Found proforma slip ID ${proformaSlip.id} for order number ${saleData.orderNumber}`);
      
      // Get proforma slip items
      const proformaItems = await storage.getProformaSlipItems(proformaSlip.id);
      
      if (!proformaItems || proformaItems.length === 0) {
        console.log(`No items found for proforma slip ID ${proformaSlip.id}`);
        return false;
      }
      
      console.log(`Found ${proformaItems.length} items for proforma slip ID ${proformaSlip.id}`);
      
      // Use proforma slip items to generate sale items
      // Convert proforma slip items to the format expected by the rest of the function
      const convertedItems = proformaItems.map(item => ({
        ...item,
        loadedQuantity: item.quantity,
        itemName: item.itemName
      }));
      
      // Generate and store sale items from proforma items
      return await generateSaleItemsFromItems(saleId, saleData, convertedItems);
    }
    
    console.log(`Found loading operation ID ${operation.id} for sale ID ${saleId}`);
    
    // Get load operation items
    const loadItems = await storage.getLoadingOperationItems(operation.id);
    
    if (!loadItems || loadItems.length === 0) {
      console.log(`No items found for load operation ID ${operation.id}, checking proforma slips...`);
      
      // Try to find a matching proforma slip for this order number
      const proformaSlip = await storage.getProformaSlipByOrderNumber(saleData.orderNumber);
      
      if (!proformaSlip) {
        console.log(`No proforma slip found for order number ${saleData.orderNumber}`);
        return false;
      }
      
      console.log(`Found proforma slip ID ${proformaSlip.id} for order number ${saleData.orderNumber}`);
      
      // Get proforma slip items
      const proformaItems = await storage.getProformaSlipItems(proformaSlip.id);
      
      if (!proformaItems || proformaItems.length === 0) {
        console.log(`No items found for proforma slip ID ${proformaSlip.id}`);
        return false;
      }
      
      console.log(`Found ${proformaItems.length} items for proforma slip ID ${proformaSlip.id}`);
      
      // Use proforma slip items instead of load operation items
      // Convert proforma slip items to the format expected by the rest of the function
      const convertedItems = proformaItems.map(item => ({
        ...item,
        loadedQuantity: item.quantity,
        itemName: item.itemName
      }));
      
      // Replace loadItems with the converted proforma items
      return await generateSaleItemsFromItems(saleId, saleData, convertedItems);
    } else {
      console.log(`Found ${loadItems.length} items for load operation ID ${operation.id} (Sale ID ${saleId})`);
    }
    
    console.log(`Found ${loadItems.length} items for load operation ID ${operation.id}`);
    
    // Process load operation items
    return await generateSaleItemsFromItems(saleId, saleData, loadItems);
  } catch (error: any) {
    console.error(`Error generating items for sale ID ${saleId}:`, error?.message || String(error));
    return false;
  }
}

/**
 * Migrates sale items from nodePersist to the database
 * This is a one-time migration script
 */
export async function migrateSaleItemsToDatabase() {
  console.log('Starting migration of sale items from nodePersist to database...');
  
  try {
    // Initialize node-persist
    await nodePersist.init({
      dir: './.data',
      stringify: JSON.stringify,
      parse: JSON.parse,
      encoding: 'utf8',
      logging: false,
      forgiveParseErrors: true
    });
    
    // Get all sales from the database
    let allSales = [];
    try {
      allSales = await db.select().from(sales);
      console.log(`Found ${allSales.length} sales to check for migration`);
    } catch (error: any) {
      console.log('Database connection error during sales retrieval:', error?.message || String(error));
      console.log('Skipping database migration due to connection issues');
      return;
    }
    
    let migratedItemsCount = 0;
    let errorCount = 0;
    let skippedCount = 0;
    
    // For each sale, check if it has items in node-persist
    for (const sale of allSales) {
      try {
        // Get sale items from node-persist
        const oldSaleItemsKey = `saleItems-${sale.id}`;
        const oldSaleItems = await nodePersist.getItem(oldSaleItemsKey);
        
        if (oldSaleItems && Array.isArray(oldSaleItems) && oldSaleItems.length > 0) {
          // Check if this sale already has items in the database
          const existingItems = await db.select().from(saleItems).where(eq(saleItems.saleId, sale.id));
          
          if (existingItems.length > 0) {
            console.log(`Sale ID ${sale.id} already has ${existingItems.length} items in the database, skipping migration`);
            skippedCount++;
            continue;
          }
          
          // Migrate items to the database
          console.log(`Migrating ${oldSaleItems.length} items for Sale ID ${sale.id}`);
          try {
            await storage.setSaleItems(sale.id, oldSaleItems);
            migratedItemsCount += oldSaleItems.length;
            
            // Remove the old entry from node-persist
            await nodePersist.removeItem(oldSaleItemsKey);
            console.log(`Successfully migrated and removed old data for Sale ID ${sale.id}`);
          } catch (error: any) {
            console.error(`Storage error during migration for Sale ID ${sale.id}:`, error?.message || String(error));
            errorCount++;
          }
        }
      } catch (error: any) {
        console.error(`Error migrating sale items for Sale ID ${sale.id}:`, error?.message || String(error));
        errorCount++;
      }
    }
    
    console.log(`
    Sale items migration completed:
    - Migrated ${migratedItemsCount} items
    - Skipped ${skippedCount} sales (already had database items)
    - Encountered errors with ${errorCount} sales
    `);
    
  } catch (error: any) {
    console.error('Failed to migrate sale items:', error?.message || String(error));
    // Don't re-throw the error, so the application can still start
  }
}