import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Activities schema to track all user actions in the app
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  pageName: text("page_name").notNull(), // Which page generated this activity
  action: text("action").notNull(), // The action performed (e.g., "create", "update", "delete")
  entityType: text("entity_type").notNull(), // Type of entity affected (e.g., "product", "slip", "sale")
  entityId: text("entity_id"), // ID or reference of the affected entity
  details: text("details"), // Additional details about the activity in JSON format
  userId: integer("user_id"), // Who performed the action
  userName: text("user_name"), // Cache the user name for quick display
  createdAt: timestamp("created_at").defaultNow(), // When the action occurred
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  pageName: true,
  action: true,
  entityType: true,
  entityId: true,
  details: true,
  userId: true,
  userName: true,
});

// Load Operations schema
export const loadingOperations = pgTable("load_operations", {
  id: serial("id").primaryKey(),
  status: text("status").default("in progress"),
  referenceNumber: text("reference_number"),
  vehicleNumber: text("vehicle_number"), // Added vehicle number field to match proforma slips
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
  orderDate: timestamp("order_date"), // Added order date field to match proforma slips
  isBackedUp: boolean("is_backed_up").default(false), // Flag to indicate if this record has been backed up
  plant: text("plant"), // Plant field for location information
});

export const insertLoadingOperationSchema = createInsertSchema(loadingOperations, {
  // Override the orderDate field to accept both Date and string
  orderDate: z.union([z.date(), z.string()]).optional(),
  // Add plant field validation
  plant: z.string().optional()
}).pick({
  status: true,
  referenceNumber: true,
  vehicleNumber: true,
  createdById: true,
  notes: true,
  orderDate: true,
  isBackedUp: true,
  plant: true,
});

// GJ Operations Items schema (previously Loading Operation Items)
export const loadingOpItems = pgTable("load_operations_items", { //Renamed table
  id: serial("id").primaryKey(),
  gjOperationsId: integer("load_operations_id").references(() => loadingOperations.id), //Renamed column
  productId: integer("product_id").references(() => products.id),
  quantity: integer("quantity").default(0),
  originalQuantity: integer("original_quantity"), // Track the original proforma quantity
  loadedQuantity: integer("loaded_quantity").default(0), // Track how many items were actually loaded
  loaded: boolean("loaded").default(false), // Track whether the item has been loaded (checkbox state)
  createdAt: timestamp("created_at").defaultNow(),
  srNo: text("sr_no"), // Serial number for the item
  barcode: text("barcode"), // Barcode for the item
  itemName: text("item_name"), // Name of the item
  srNoDisplay: text("sr_no_display"), // Display field for Sr.No. column in UI
});

// Create a schema with an optional loadOperationsId field for the new name
export const insertLoadingOpItemSchema = createInsertSchema(loadingOpItems, {
  // Add this virtual field to accept either name
  loadOperationsId: z.number().optional()
}).pick({
  gjOperationsId: true,
  loadOperationsId: true, // Add this as an accepted field
  productId: true,
  quantity: true,
  originalQuantity: true,
  loadedQuantity: true,
  loaded: true,
  srNo: true,
  barcode: true,
  itemName: true,
  srNoDisplay: true,
});

// Purchase schema
export const purchases = pgTable("purchases", {
  id: serial("id").primaryKey(),
  date: date("date").defaultNow(),
  item: text("item").notNull(),
  quantity: integer("quantity").default(0),
  priceDetails: text("price_details"),
  notes: text("notes"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPurchaseSchema = createInsertSchema(purchases, {
  // Override the date field to accept both Date and string for DD-MM-YYYY format
  date: z.union([z.date(), z.string()])
}).pick({
  date: true,
  item: true,
  quantity: true,
  priceDetails: true,
  notes: true,
  userId: true,
});

// Sales schema
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number"),
  date: text("date"), // Changed to text for storing date in DD-MM-YYYY format
  dealer: text("dealer"),
  plant: text("plant"),
  status: text("status").default("loading"),
  quantity: integer("quantity").default(0),
  amount: integer("amount").default(0),
  vehicleNumber: text("vehicle_number"), // Added vehicle number field from proforma slips
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  notes: text("notes"),
  isBackedUp: boolean("is_backed_up").default(false), // Flag to indicate if this record has been backed up
  // We can't add a proper items field to the database table, so we'll handle this in the application layer
});

export const insertSaleSchema = createInsertSchema(sales, {
  // Override the date field to accept both Date and string for DD-MM-YYYY format
  date: z.union([z.date(), z.string()]),
}).pick({
  orderNumber: true,
  date: true,
  dealer: true,
  plant: true,
  status: true,
  quantity: true,
  amount: true,
  vehicleNumber: true,
  createdById: true,
  notes: true,
  isBackedUp: true,
});

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  pin: text("pin").notNull(), // Changed from password to pin
  firstName: text("first_name"),
  lastName: text("last_name"),
  name: text("name"),
  designation: text("designation"),
  department: text("department"),
  accessType: text("access_type").default("read"),
  role: text("role").default("user"),
});

// Recreate the insert schema with the new pin field
export const insertUserSchema = createInsertSchema(users);

// Product schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  srNo: text("sr_no"), // Sr. No. from CSV
  itemNo: text("item_no"), // SKU or internal item number
  barcode: text("barcode").notNull().unique(),
  name: text("name").notNull(),
  category: text("category"),
  volumeInCuFt: text("volume_in_cu_ft"), // Cu. ft. volume
  hsnCode: text("hsn_code"),
  sapCode: text("sap_code"),
  purchased: integer("purchased").default(0),
  sold: integer("sold").default(0),
  inStock: integer("in_stock").default(0),
  itemsPerPallet: integer("items_per_pallet").default(0),
  pallets: integer("pallets").default(0),
  purchasePrice: text("purchase_price"),
  sellingPrice: text("selling_price"),
  lastUpdated: timestamp("last_updated"),
  description: text("description"),
  status: text("status").default("in stock"),
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products, {
  // Override the lastUpdated field to accept both Date and string
  lastUpdated: z.union([z.date(), z.string()]).optional(),
}).pick({
  srNo: true,
  itemNo: true,
  barcode: true,
  name: true,
  category: true,
  volumeInCuFt: true,
  hsnCode: true,
  sapCode: true,
  purchased: true,
  sold: true,
  inStock: true,
  itemsPerPallet: true,
  pallets: true,
  purchasePrice: true,
  sellingPrice: true,
  lastUpdated: true,
  description: true,
  status: true,
  createdById: true,
});

// Scan history schema
export const scanHistory = pgTable("scan_history", {
  id: serial("id").primaryKey(),
  barcode: text("barcode").notNull(),
  productId: integer("product_id").references(() => products.id),
  scannedById: integer("scanned_by_id").references(() => users.id),
  scannedAt: timestamp("scanned_at").defaultNow(),
  action: text("action").notNull(), // e.g., "add", "remove", "update"
  quantity: integer("quantity").default(1),
  notes: text("notes"),
  productSku: text("product_sku"), // Added to support SKU in scan history
  scannerName: text("scanner_name"), // User's display name who scanned the barcode
  scannerDepartment: text("scanner_department"), // User's department
  productName: text("product_name"), // Store the product name for better historical records
  isBackedUp: boolean("is_backed_up").default(false), // Flag to indicate if this record has been backed up
  orderNumber: text("order_number"), // Reference to associated order number
});

export const insertScanHistorySchema = createInsertSchema(scanHistory).pick({
  barcode: true,
  productId: true,
  scannedById: true,
  action: true,
  quantity: true,
  notes: true,
  productSku: true,
  scannerName: true,
  scannerDepartment: true,
  productName: true,
  isBackedUp: true,
  orderNumber: true,
});

// Types for frontend and backend use
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type ScanHistory = typeof scanHistory.$inferSelect;
export type InsertScanHistory = z.infer<typeof insertScanHistorySchema>;

export type Purchase = typeof purchases.$inferSelect;
export type InsertPurchase = z.infer<typeof insertPurchaseSchema>;

export type Sale = typeof sales.$inferSelect;
export type InsertSale = z.infer<typeof insertSaleSchema>;

export type LoadingOperation = typeof loadingOperations.$inferSelect & {
  creatorName?: string;
  creatorUsername?: string;
  creatorRole?: string;
};
export type InsertLoadingOperation = z.infer<typeof insertLoadingOperationSchema>;

export type LoadingOpItem = typeof loadingOpItems.$inferSelect;
export type InsertLoadingOpItem = z.infer<typeof insertLoadingOpItemSchema>;


// Extended schemas for validation
export const scanEntrySchema = z.object({
  barcode: z.string().min(1, "Barcode is required"),
  quantity: z.number().int().positive().default(1),
  name: z.string().optional(),
  description: z.string().optional(),
  category: z.string().optional(),
  action: z.enum(["add", "remove", "update"]).default("add"),
  notes: z.string().optional(),
  productId: z.number().optional(), // Added to support direct product reference
  productSku: z.string().optional(), // Added to support SKU display in scan history
  scannerName: z.string().optional(), // User's display name who scanned the barcode
  scannerDepartment: z.string().optional(), // User's department
  scannedById: z.number().optional(), // The user ID of who performed the scan
  productName: z.string().optional(), // Store the product name for better historical records
  isBackedUp: z.boolean().optional(), // Flag to indicate if this record has been backed up
  orderNumber: z.string().optional(), // Reference to the order number for matching with load operations
});

export type ScanEntry = z.infer<typeof scanEntrySchema>;

// Proforma Slip schema
export const proformaSlips = pgTable("proforma_slips", {
  id: serial("id").primaryKey(),
  orderDate: date("order_date").defaultNow(),
  orderNumber: text("order_number").notNull(),
  partyName: text("party_name").notNull(),
  plant: text("plant"),
  totalQuantity: integer("total_quantity").default(0),
  totalVolume: text("total_volume"),
  vehicleNumber: text("vehicle_number"),
  driverName: text("driver_name"),
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  notes: text("notes"),
  isBackedUp: boolean("is_backed_up").default(false), // Flag to indicate if this record has been backed up
});

export const insertProformaSlipSchema = createInsertSchema(proformaSlips, {
  // Override the orderDate field to accept both Date and string for DD-MM-YYYY format
  orderDate: z.union([z.date(), z.string()])
}).pick({
  orderDate: true,
  orderNumber: true,
  partyName: true,
  plant: true,
  totalQuantity: true,
  totalVolume: true,
  vehicleNumber: true,
  driverName: true,
  createdById: true,
  notes: true,
  isBackedUp: true,
});

// Proforma Slip Items schema
export const proformaSlipItems = pgTable("proforma_slip_items", {
  id: serial("id").primaryKey(),
  proformaSlipId: integer("proforma_slip_id").references(() => proformaSlips.id),
  productId: integer("product_id").references(() => products.id),
  quantity: integer("quantity").default(0),
  originalQuantity: integer("original_quantity"), // Track the original proforma quantity
  loadedQuantity: integer("loaded_quantity").default(0), // Track how many items were actually loaded
  loaded: boolean("loaded").default(false), // Track whether the item has been loaded (checkbox state)
  createdAt: timestamp("created_at").defaultNow(),
  srNo: text("sr_no"), // Serial number for the item
  barcode: text("barcode"), // Barcode for the item
  itemName: text("item_name"), // Name of the item
});

export const insertProformaSlipItemSchema = createInsertSchema(proformaSlipItems).pick({
  proformaSlipId: true,
  productId: true,
  quantity: true,
  originalQuantity: true,
  loadedQuantity: true,
  loaded: true,
  srNo: true,
  barcode: true,
  itemName: true,
});

export type ProformaSlip = typeof proformaSlips.$inferSelect;
export type InsertProformaSlip = z.infer<typeof insertProformaSlipSchema>;

export type ProformaSlipItem = typeof proformaSlipItems.$inferSelect;
export type InsertProformaSlipItem = z.infer<typeof insertProformaSlipItemSchema>;

// Vehicle Info schema
export const vehicleInfo = pgTable("vehicle_info", {
  id: serial("id").primaryKey(),
  srNo: integer("sr_no").notNull(),
  rtoNumber: text("rto_number").notNull(),
  vehicleNumber: text("vehicle_number").notNull().unique(),
  lastEditedById: integer("last_edited_by_id").references(() => users.id),
  lastEditedAt: timestamp("last_edited_at").defaultNow(),
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVehicleInfoSchema = createInsertSchema(vehicleInfo).pick({
  srNo: true,
  rtoNumber: true, 
  vehicleNumber: true,
  lastEditedById: true,
  createdById: true,
});

export type VehicleInfo = typeof vehicleInfo.$inferSelect;
export type InsertVehicleInfo = z.infer<typeof insertVehicleInfoSchema>;


// Data Backup schema
export const backupSettings = pgTable("backup_settings", {
  id: serial("id").primaryKey(),
  lastBackupDate: timestamp("last_backup_date").defaultNow(),
  autoBackupEnabled: boolean("auto_backup_enabled").default(true),
  backupFrequencyHours: integer("backup_frequency_hours").default(24), // Default to daily backups
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBackupSettingsSchema = createInsertSchema(backupSettings).pick({
  lastBackupDate: true,
  autoBackupEnabled: true,
  backupFrequencyHours: true,
});

// Backup tables for historical data
export const scanHistoryBackup = pgTable("scan_history_backup", {
  id: serial("id").primaryKey(),
  originalId: integer("original_id"), // Reference to the original record ID
  barcode: text("barcode").notNull(),
  productId: integer("product_id"),
  productName: text("product_name"),
  productSku: text("product_sku"),
  scannedById: integer("scanned_by_id"),
  scannerName: text("scanner_name"),
  scannerDepartment: text("scanner_department"),
  scannedAt: timestamp("scanned_at"),
  action: text("action"),
  quantity: integer("quantity"),
  notes: text("notes"),
  backupDate: timestamp("backup_date").defaultNow(), // When the record was backed up
});


export const salesBackup = pgTable("sales_backup", {
  id: serial("id").primaryKey(),
  originalId: integer("original_id"), // Reference to the original record ID
  orderNumber: text("order_number"),
  date: text("date"), // Changed to text for storing date in DD-MM-YYYY format
  dealer: text("dealer"),
  plant: text("plant"),
  status: text("status"),
  quantity: integer("quantity"),
  amount: integer("amount"),
  vehicleNumber: text("vehicle_number"), // Added vehicle number field to match sales
  createdById: integer("created_by_id"),
  createdAt: timestamp("created_at"),
  notes: text("notes"),
  backupDate: timestamp("backup_date").defaultNow(), // When the record was backed up
});

// Proforma Slip backup schema
export const proformaSlipsBackup = pgTable("proforma_slips_backup", {
  id: serial("id").primaryKey(),
  originalId: integer("original_id"), // Reference to the original record ID
  orderDate: date("order_date"),
  orderNumber: text("order_number"),
  partyName: text("party_name"),
  plant: text("plant"),
  totalQuantity: integer("total_quantity"),
  totalVolume: text("total_volume"),
  vehicleNumber: text("vehicle_number"),
  driverName: text("driver_name"),
  createdById: integer("created_by_id"),
  createdAt: timestamp("created_at"),
  notes: text("notes"),
  backupDate: timestamp("backup_date").defaultNow(), // When the record was backed up
});

// Proforma Slip Items backup schema
export const proformaSlipItemsBackup = pgTable("proforma_slip_items_backup", {
  id: serial("id").primaryKey(),
  originalId: integer("original_id"), // Reference to the original record ID
  proformaSlipId: integer("proforma_slip_id"), // Reference to the original proforma slip ID
  proformaSlipBackupId: integer("proforma_slip_backup_id"), // Reference to the backup proforma slip ID
  productId: integer("product_id"),
  quantity: integer("quantity"),
  originalQuantity: integer("original_quantity"),
  loadedQuantity: integer("loaded_quantity").default(0),
  loaded: boolean("loaded"),
  srNo: text("sr_no"),
  barcode: text("barcode"),
  itemName: text("item_name"),
  createdAt: timestamp("created_at"),
  backupDate: timestamp("backup_date").defaultNow(), // When the record was backed up
});

export type BackupSettings = typeof backupSettings.$inferSelect;
export type InsertBackupSettings = z.infer<typeof insertBackupSettingsSchema>;

export type ScanHistoryBackup = typeof scanHistoryBackup.$inferSelect;

export type SaleBackup = typeof salesBackup.$inferSelect;
export type ProformaSlipBackup = typeof proformaSlipsBackup.$inferSelect;
export type ProformaSlipItemBackup = typeof proformaSlipItemsBackup.$inferSelect;

// Messages schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  recipientId: integer("recipient_id").references(() => users.id), // Optional for broadcast messages
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  broadcastToAll: boolean("broadcast_to_all").default(false),
  broadcastToDesignation: text("broadcast_to_designation"), // For sending to specific designations
  broadcastToDepartment: text("broadcast_to_department"), // For sending to specific departments
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  senderId: true,
  recipientId: true,
  content: true,
  isRead: true,
  broadcastToAll: true,
  broadcastToDesignation: true,
  broadcastToDepartment: true,
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

// Sale Items schema
export const saleItems = pgTable("sale_items", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id").notNull().references(() => sales.id, { onDelete: "cascade" }),
  sku: text("sku"),
  barcode: text("barcode"),
  name: text("name").notNull(),
  quantity: integer("quantity").notNull().default(0),
  unitPrice: text("unit_price").notNull().default("0"), // Using text for currency values
  totalPrice: text("total_price"),
  category: text("category"),
  hsn: text("hsn"),
  originalQuantity: integer("original_quantity").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertSaleItemSchema = createInsertSchema(saleItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export type SaleItem = typeof saleItems.$inferSelect;
export type InsertSaleItem = z.infer<typeof insertSaleItemSchema>;

// Orders schema
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull(),
  dealer: text("dealer").notNull(),
  plant: text("plant"),
  vehicleNumber: text("vehicle_number"),
  orderDate: text("order_date").default(new Date().toISOString().split('T')[0]),
  status: text("status").default("DRAFT"),
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  notes: text("notes"),
  sentToProforma: boolean("sent_to_proforma").default(false),
  proformaId: integer("proforma_id"),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  sentToProforma: true,
  proformaId: true
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

// Order Items schema
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id),
  srNo: text("sr_no"),
  name: text("name").notNull(),
  barcode: text("barcode"),
  quantity: integer("quantity").notNull().default(0),
  unitPrice: text("unit_price").default("0"),
  totalPrice: text("total_price"),
  category: text("category"),
  hsn: text("hsn"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;