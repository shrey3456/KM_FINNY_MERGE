import React, { useState, useEffect, useMemo } from "react";
import { apiRequest } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableFooter
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { PlantBadge } from "@/components/PlantBadge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Loader2, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Truck, Trash, Eye } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

// Status Badge Component
const StatusBadge: React.FC<{ status: string | null | undefined }> = ({ status }) => {
  // Replace PENDING DESP with READY≈DESP
  let displayStatus = status;
  if (status === "PENDING DESP") {
    displayStatus = "READY≈DESP";
  }
  
  return (
    <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-purple-100 text-purple-800 border border-purple-500">
      {displayStatus ? displayStatus.toUpperCase() : "UNKNOWN"}
    </span>
  );
};

// Optimized Sale Details Dialog
const OptimizedSaleDetailsDialog: React.FC<{ 
  saleId: number, 
  orderNumber: string, 
  saleData: any, 
  isBackup?: boolean,
  buttonSize?: "sm" | "md" | "lg" | "icon"
}> = ({ 
  saleId, 
  orderNumber, 
  saleData, 
  isBackup = false,
  buttonSize = "icon"
}) => {
  // Fetch sale details only when dialog is opened
  const [isOpen, setIsOpen] = useState(false);
  
  // Fetch sale details when dialog is open
  const { data: saleDetails, isLoading: saleLoading } = useQuery({
    queryKey: [`/api/${isBackup ? 'backup/' : ''}sales/${saleId}`],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/${isBackup ? 'backup/' : ''}sales/${saleId}`);
      return res.json();
    },
    enabled: isOpen // Only fetch when dialog is open
  });
  
  // Also fetch items separately to ensure we get them, with generateMissing=true to generate items if missing
  const { data: itemsData, isLoading: itemsLoading } = useQuery({
    queryKey: [`/api/${isBackup ? 'backup/' : ''}sales/${saleId}/items`],
    queryFn: async () => {
      // First try with generateMissing=true to attempt automatic regeneration of missing items
      const res = await apiRequest('GET', `/api/${isBackup ? 'backup/' : ''}sales/${saleId}/items?generateMissing=true`);
      const data = await res.json();
      
      // If we got a response with 'generated' flag, log it for debugging
      if (data.generated) {
        console.log(`Successfully generated missing items for Sale #${saleId}`, data.items);
        // Return just the items array to match the expected format
        return data.items;
      }
      
      return data;
    },
    enabled: isOpen, // Only fetch when dialog is open
    retry: 1 // One retry is enough since we're already generating missing items
  });
  
  const isLoading = saleLoading || itemsLoading;
  
  // Extract sale data with items from the API response
  const sale = saleDetails || saleData;
  
  // Use items from separate API call if available, otherwise use items from sale object
  // Let's console log the items data for debugging
  console.log("itemsData:", itemsData);
  console.log("sale?.items:", sale?.items);
  
  // Also normalize the data format to handle both database field names (snake_case) and client field names (camelCase)
  const items = (itemsData?.length > 0 ? itemsData : sale?.items || []).map((item: any) => {
    console.log("Processing item:", item);
    return {
      // Normalize field names to ensure consistent access in the template
      id: item.id,
      saleId: item.saleId || item.sale_id,
      sku: item.sku,
      barcode: item.barcode,
      name: item.name,
      productId: item.productId || item.product_id,
      quantity: item.quantity || 0,
      unitPrice: item.unitPrice !== undefined ? item.unitPrice : 
                (item.unit_price !== undefined ? parseFloat(item.unit_price) : 0),
      totalPrice: item.totalPrice !== undefined ? item.totalPrice : 
                (item.total_price !== undefined ? parseFloat(item.total_price) : 0),
      category: item.category,
      hsn: item.hsn,
      originalQuantity: item.originalQuantity || item.original_quantity || item.quantity || 0,
      itemName: item.itemName || item.item_name || item.name
    };
  });

  // Format function for dates
  const formatDate = (dateStr: string) => {
    if (!dateStr) return "N/A";
    
    // Handle ISO format with time (2025-04-03T09:09:41.370Z)
    if (dateStr.includes('T')) {
      try {
        const date = new Date(dateStr);
        if (!isNaN(date.getTime())) {
          const day = date.getDate().toString().padStart(2, '0');
          const month = (date.getMonth() + 1).toString().padStart(2, '0');
          const year = date.getFullYear();
          return `${day}/${month}/${year}`;
        }
      } catch (e) {
        // Ignore parsing errors, continue with other methods
      }
    }
    
    // Parse date with hyphen format (DD-MM-YYYY or YYYY-MM-DD)
    if (dateStr.includes('-')) {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        // Check if it's YYYY-MM-DD format (first part is 4-digit year)
        if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
          return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
        // Assume it's DD-MM-YYYY format
        return `${parts[0]}/${parts[1]}/${parts[2]}`;
      }
    }
    // Parse date with slash format (YYYY/MM/DD or DD/MM/YYYY)
    else if (dateStr.includes('/')) {
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        // Check if it's YYYY/MM/DD format (first part is 4-digit year)
        if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
          return `${parts[2]}/${parts[1]}/${parts[0]}`; // Convert to DD/MM/YYYY
        }
        // Already in DD/MM/YYYY format
        return dateStr;
      }
    }
    
    // Last resort: try to parse using standard Date
    try {
      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      }
    } catch (e) {
      // Ignore parsing errors
    }
    
    return dateStr; // If format is unexpected, just show the original
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size={buttonSize}
          className={`${
            buttonSize === "icon" 
              ? "h-8 w-8" 
              : buttonSize === "sm" 
                ? "h-8 w-8" 
                : buttonSize === "md" 
                  ? "h-10 w-10" 
                  : "h-12 w-12"
          } text-[#0B2F6E] hover:text-[#0B2F6E] hover:bg-blue-100 rounded-full bg-blue-50`}
        >
          <Eye className="h-6 w-6 text-[#0B2F6E]" style={{height: '1.5rem', width: '1.5rem'}} />
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[95vw] max-w-6xl max-h-[90vh] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle>Sale Details - #{orderNumber}</DialogTitle>
        </DialogHeader>
        
        {isLoading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 gap-4 py-4">
              <div className="space-y-3">
                <div className="bg-muted/10 p-4 rounded-md border border-muted">
                  <div className="text-sm font-medium pb-2 border-b mb-3">Order Information</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2.5">
                    {/* Left column - Basic Order Details */}
                    <div className="space-y-2.5">
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Order No.:</div>
                        <div className="text-right w-2/3 font-medium">#{sale.orderNumber}</div>
                      </div>
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Date:</div>
                        <div className="text-right w-2/3">{formatDate(sale.date)}</div>
                      </div>
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Party Name:</div>
                        <div className="text-right w-2/3 font-semibold break-words">
                          {sale.dealer && sale.dealer !== "Unknown" ? sale.dealer : 
                           sale.party && sale.party !== "Unknown" ? sale.party : 
                           sale.party_name && sale.party_name !== "Unknown" ? sale.party_name : "N/A"}
                        </div>
                      </div>
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Plant:</div>
                        <div className="text-right w-2/3">
                          {sale.plant && sale.plant !== "Unknown" ? (
                            <PlantBadge plant={sale.plant} />
                          ) : (
                            <span className="text-gray-500">-</span>
                          )}
                        </div>
                      </div>
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Vehicle Number:</div>
                        <div className="text-right w-2/3 break-words">{sale.vehicleNumber || "Not assigned"}</div>
                      </div>
                    </div>

                    {/* Right column - Order Summary & Additional Details */}
                    <div className="space-y-2.5 mt-2.5 md:mt-0">
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Status:</div>
                        <div className="text-right w-2/3">
                          <StatusBadge status={sale.status} />
                        </div>
                      </div>
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Total Quantity:</div>
                        <div className="text-right w-2/3 font-semibold text-green-600">
                          {items?.length > 0 
                            ? items.reduce((sum: number, item: any) => sum + (parseInt(item.quantity) || 0), 0)
                            : sale.quantity || 0}
                        </div>
                      </div>
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-muted-foreground w-1/3">Total Amount:</div>
                        <div className="text-right w-2/3 font-bold text-[#0B2F6E]">
                          {items?.length > 0 
                            ? `₹${items.reduce((sum: number, item: any) => {
                                // Parse totalPrice correctly, handling string/number types
                                const itemTotal = typeof item.totalPrice === 'string' 
                                  ? parseFloat(item.totalPrice) 
                                  : item.totalPrice || 0;
                                return sum + (!isNaN(itemTotal) ? itemTotal : 0);
                              }, 0).toLocaleString()}`
                            : parseFloat(sale.amount || '0') > 0 
                              ? `₹${parseFloat(sale.amount).toLocaleString()}`
                              : <span className="text-gray-500">Not available</span>}
                        </div>
                      </div>
                      {sale.notes && (
                        <div className="flex justify-between items-start">
                          <div className="font-medium text-muted-foreground w-1/3">Storekeeper:</div>
                          <div className="text-right w-2/3">
                            {(() => {
                              const storekeeperMatch = sale.notes.match(/Storekeeper: (.*?) \((.*?)\)/);
                              if (storekeeperMatch && storekeeperMatch.length >= 3) {
                                return (
                                  <div className="flex items-center gap-2 flex-wrap justify-end">
                                    <span>{storekeeperMatch[1]}</span>
                                    <span className="text-xs bg-purple-100 text-purple-800 px-2 py-0.5 rounded">
                                      {storekeeperMatch[2]}
                                    </span>
                                  </div>
                                );
                              }
                              return "Unknown";
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="border rounded-md mt-4">
              <div className="p-3 bg-muted/30 font-medium flex items-center justify-between">
                <div>Item Details</div>
                <div className="text-sm text-muted-foreground">
                  Total Items: {items?.length || 0}
                </div>
              </div>
              {/* On desktop, show traditional table layout */}
              <div className="hidden md:block p-2 max-h-[50vh] overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[60px]">Sr. No.</TableHead>
                      <TableHead className="min-w-[280px]">Item Name</TableHead>
                      <TableHead className="text-center w-[80px] text-green-600">Quantity</TableHead>
                      <TableHead className="text-right w-[120px]">Unit Price</TableHead>
                      <TableHead className="text-right w-[120px]">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items && items.length > 0 ? (
                      items.map((item: any, index: number) => (
                        <TableRow key={index} className="hover:bg-muted/30">
                          <TableCell>{item.srNo || index + 1}</TableCell>
                          <TableCell className="break-words max-w-[200px]">
                            <div className="font-medium">{item.itemName || item.name || "Unknown Item"}</div>
                            {item.category && <div className="text-xs text-muted-foreground mt-1">Category: {item.category}</div>}
                            {item.barcode && <div className="text-xs text-muted-foreground">SAP: {item.barcode}</div>}
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="text-green-600 font-semibold">
                              {typeof item.quantity === 'string' 
                                ? parseInt(item.quantity) || 0
                                : item.quantity || 0}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">₹{
                            typeof item.unitPrice === 'string'
                              ? parseFloat(item.unitPrice).toLocaleString() 
                              : (item.unitPrice || 0).toLocaleString()
                          }</TableCell>
                          <TableCell className="text-right">₹{
                            (() => {
                              let total = 0;
                              if (item.totalPrice) {
                                total = typeof item.totalPrice === 'string' 
                                  ? parseFloat(item.totalPrice) 
                                  : item.totalPrice;
                              } else if (item.unitPrice && item.quantity) {
                                const unitPrice = typeof item.unitPrice === 'string' 
                                  ? parseFloat(item.unitPrice) 
                                  : item.unitPrice;
                                const quantity = typeof item.quantity === 'string' 
                                  ? parseInt(item.quantity) 
                                  : item.quantity;
                                total = unitPrice * quantity;
                              }
                              return isNaN(total) ? 0 : total.toLocaleString();
                            })()
                          }</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-4 text-muted-foreground">
                          No items found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell colSpan={2}>Total</TableCell>
                      <TableCell className="text-center text-green-600 font-semibold">
                        {items?.reduce((sum: number, item: any) => {
                          const quantity = typeof item.quantity === 'string' 
                            ? parseInt(item.quantity) || 0 
                            : item.quantity || 0;
                          return sum + quantity;
                        }, 0) || 0}
                      </TableCell>
                      <TableCell></TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{items?.reduce((sum: number, item: any) => {
                          // Handle both string and number totalPrice values
                          let itemTotal = 0;
                          if (item.totalPrice !== undefined && item.totalPrice !== null) {
                            // Parse totalPrice if it's a string
                            itemTotal = typeof item.totalPrice === 'string' 
                              ? parseFloat(item.totalPrice) 
                              : item.totalPrice;
                          } else if (item.unitPrice && item.quantity) {
                            // Calculate if totalPrice is not available
                            const unitPrice = typeof item.unitPrice === 'string' 
                              ? parseFloat(item.unitPrice) 
                              : item.unitPrice;
                            itemTotal = unitPrice * item.quantity;
                          }
                          return sum + (isNaN(itemTotal) ? 0 : itemTotal);
                        }, 0)?.toLocaleString() || "0"}
                      </TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </div>
              
              {/* On mobile, show improved card-based layout for better readability */}
              <div className="md:hidden max-h-[50vh] overflow-y-auto space-y-4">
                {items && items.length > 0 ? (
                  <>
                    {/* Items list with improved visuals */}
                    <div className="bg-white border rounded-lg shadow-sm">
                      <div className="divide-y">
                        {items.map((item: any, index: number) => (
                          <div key={index} className="p-3 hover:bg-muted/10">
                            <div className="flex justify-between items-center mb-2">
                              <div className="font-medium text-[#0B2F6E]">
                                {item.itemName || item.name || "Unknown Item"}
                              </div>
                              <div className="bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                                <span>Qty:</span> {typeof item.quantity === 'string' ? parseInt(item.quantity) || 0 : item.quantity || 0}
                              </div>
                            </div>
                            
                            {item.barcode && 
                              <div className="text-sm text-muted-foreground mb-2">
                                SAP: {item.barcode}
                              </div>
                            }
                            
                            <div className="flex justify-between items-center p-2 bg-gray-50 rounded-md mt-1">
                              <div className="text-sm">
                                <span className="text-muted-foreground mr-1">Price:</span>
                                <span>₹{typeof item.unitPrice === 'string'
                                  ? parseFloat(item.unitPrice).toLocaleString() 
                                  : (item.unitPrice || 0).toLocaleString()}</span>
                              </div>
                              <div className="text-sm font-medium text-[#0B2F6E]">
                                <span className="text-muted-foreground mr-1">Total:</span>
                                ₹{(() => {
                                  let total = 0;
                                  if (item.totalPrice) {
                                    total = typeof item.totalPrice === 'string' 
                                      ? parseFloat(item.totalPrice) 
                                      : item.totalPrice;
                                  } else if (item.unitPrice && item.quantity) {
                                    const unitPrice = typeof item.unitPrice === 'string' 
                                      ? parseFloat(item.unitPrice) 
                                      : item.unitPrice;
                                    const quantity = typeof item.quantity === 'string' 
                                      ? parseInt(item.quantity) 
                                      : item.quantity;
                                    total = unitPrice * quantity;
                                  }
                                  return isNaN(total) ? 0 : total.toLocaleString();
                                })()}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      {/* Summary footer */}
                      <div className="p-3 bg-gray-50 border-t">
                        <div className="flex justify-between items-center">
                          <div className="font-medium">Grand Total:</div>
                          <div className="font-bold text-[#0B2F6E]">
                            ₹{items.reduce((sum: number, item: any) => {
                              const itemTotal = typeof item.totalPrice === 'string' 
                                ? parseFloat(item.totalPrice) 
                                : item.totalPrice || 0;
                              return sum + (!isNaN(itemTotal) ? itemTotal : 0);
                            }, 0).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-6 bg-white border rounded-lg shadow-sm text-muted-foreground">
                    No items found
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

// OptimizedSalesTable Component
interface OptimizedSalesTableProps {
  data: any[];
  isLoading: boolean;
  handleDeleteSale: (id: number) => void;
  limit?: number;
  onLimitChange?: (limit: number) => void;
  sortField?: string;
  sortDirection?: 'asc' | 'desc';
  onSortChange?: (field: string, direction: 'asc' | 'desc') => void;
}

const OptimizedSalesTable: React.FC<OptimizedSalesTableProps> = ({
  data,
  isLoading,
  handleDeleteSale,
  limit = 50,
  onLimitChange,
  sortField = 'date',
  sortDirection = 'desc',
  onSortChange
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [internalLimit, setInternalLimit] = useState<number>(limit);
  
  // Update internal limit when external limit changes
  useEffect(() => {
    setInternalLimit(limit);
    setCurrentPage(1);
  }, [limit]);

  // No date filtering - use all data
  const filteredData = useMemo(() => {
    return data;
  }, [data]);

  // Sort data based on sort field and direction
  const sortedData = useMemo(() => {
    if (!filteredData) return [];
    
    return [...filteredData].sort((a, b) => {
      let aValue = a[sortField];
      let bValue = b[sortField];
      
      // Special handling for date field
      if (sortField === 'date') {
        // Parse dates for comparison
        const parseDate = (dateStr: string | Date) => {
          if (dateStr instanceof Date) return dateStr;
          
          // Handle ISO format (2025-04-03T09:09:41.370Z)
          if (typeof dateStr === 'string' && dateStr.includes('T')) {
            return new Date(dateStr);
          }
          
          // Handle DD/MM/YYYY format
          if (typeof dateStr === 'string' && dateStr.includes('/')) {
            const parts = dateStr.split('/');
            if (parts.length === 3) {
              // Convert DD/MM/YYYY to YYYY-MM-DD for proper Date parsing
              return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
            }
          }
          
          // Handle DD-MM-YYYY format
          if (typeof dateStr === 'string' && dateStr.includes('-')) {
            const parts = dateStr.split('-');
            if (parts.length === 3) {
              // Convert DD-MM-YYYY to YYYY-MM-DD for proper Date parsing
              return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
            }
          }
          
          return new Date(dateStr || 0);
        };
        
        const dateA = parseDate(aValue);
        const dateB = parseDate(bValue);
        
        if (sortDirection === 'asc') {
          return dateA.getTime() - dateB.getTime();
        } else {
          return dateB.getTime() - dateA.getTime();
        }
      }
      
      // Handle numeric fields
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
      }
      
      // Handle string fields with null checks
      aValue = aValue || '';
      bValue = bValue || '';
      
      if (sortDirection === 'asc') {
        return aValue.toString().localeCompare(bValue.toString());
      } else {
        return bValue.toString().localeCompare(aValue.toString());
      }
    });
  }, [filteredData, sortField, sortDirection]);

  // Paginate data
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * internalLimit;
    const endIndex = startIndex + internalLimit;
    return sortedData.slice(startIndex, endIndex);
  }, [sortedData, currentPage, internalLimit]);

  // Calculate total pages
  const totalPages = Math.ceil(sortedData.length / internalLimit);

  // Format function for dates
  const formatDate = (dateStr: string) => {
    if (!dateStr) return "N/A";
    
    // Handle ISO format with time (2023-04-03T09:09:41.370Z)
    if (dateStr.includes('T')) {
      try {
        const date = new Date(dateStr);
        if (!isNaN(date.getTime())) {
          const day = date.getDate().toString().padStart(2, '0');
          const month = (date.getMonth() + 1).toString().padStart(2, '0');
          const year = date.getFullYear();
          return `${day}/${month}/${year}`;
        }
      } catch (e) {
        // Ignore parsing errors, continue with other methods
      }
    }
    
    // Parse date with hyphen format (DD-MM-YYYY or YYYY-MM-DD)
    if (dateStr.includes('-')) {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        // Check if it's YYYY-MM-DD format (first part is 4-digit year)
        if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
          return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
        // Assume it's DD-MM-YYYY format
        return `${parts[0]}/${parts[1]}/${parts[2]}`;
      }
    }
    // Parse date with slash format (YYYY/MM/DD or DD/MM/YYYY)
    else if (dateStr.includes('/')) {
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        // Check if it's YYYY/MM/DD format (first part is 4-digit year)
        if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
          return `${parts[2]}/${parts[1]}/${parts[0]}`; // Convert to DD/MM/YYYY
        }
        // Already in DD/MM/YYYY format
        return dateStr;
      }
    }
    
    // Last resort: try to parse using standard Date
    try {
      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      }
    } catch (e) {
      // Ignore parsing errors
    }
    
    return dateStr; // If format is unexpected, just show the original
  };

  // Handle sort change
  const handleSortChange = (field: string) => {
    if (onSortChange) {
      if (field === sortField) {
        // Toggle direction if same field
        const newDirection = sortDirection === 'asc' ? 'desc' : 'asc';
        onSortChange(field, newDirection);
      } else {
        // New field, default to 'asc'
        onSortChange(field, 'asc');
      }
    }
  };

  // Determine if viewing database records or backup (memory) records
  const isBackup = data.length > 0 && data[0].hasOwnProperty('memoryId');

  // Check if mobile screen
  const [isMobile, setIsMobile] = useState(false);
  
  // Detect screen size
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    // Check on mount
    checkMobile();
    
    // Add resize listener
    window.addEventListener('resize', checkMobile);
    
    // Clean up
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Check if the data array has display data
  const displayData = paginatedData || [];
  
  // When data is filtered down to 0 entries, reset page to 1
  useEffect(() => {
    if (filteredData.length === 0 && currentPage > 1) {
      setCurrentPage(1);
    }
  }, [filteredData, currentPage]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 justify-between pb-2">
        {/* Mobile view: Show entries dropdown and count text in a row */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full">
          {/* Mobile: Dropdown and count on same row */}
          <div className="flex flex-row flex-wrap items-center gap-2 w-full sm:hidden">
            {/* Entries dropdown */}
            <div className="flex items-center gap-2">
              <div className="text-xs text-muted-foreground whitespace-nowrap">Show entries:</div>
              <select 
                value={internalLimit}
                onChange={(e) => {
                  const newLimit = parseInt(e.target.value);
                  setInternalLimit(newLimit);
                  setCurrentPage(1);
                  if (onLimitChange) onLimitChange(newLimit);
                }}
                className="border rounded px-2 py-1 text-xs"
              >
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
                <option value={500}>500</option>
              </select>
            </div>
            
            {/* Entries count right next to dropdown */}
            <div className="text-xs text-muted-foreground">
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Loading...</span>
                </div>
              ) : (
                <>
                  Showing {displayData.length} of {sortedData.length} entries
                </>
              )}
            </div>
          </div>
          
          {/* Desktop: Original layout */}
          <div className="hidden sm:flex items-center gap-2 order-1">
            <div className="text-sm text-muted-foreground">
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Loading...</span>
                </div>
              ) : (
                <>
                  Showing {displayData.length} of {sortedData.length} entries
                </>
              )}
            </div>
          </div>
          
          <div className="hidden sm:flex items-center gap-2 order-2 ml-4">
            <div className="text-sm text-muted-foreground whitespace-nowrap">Show entries:</div>
            <select 
              value={internalLimit}
              onChange={(e) => {
                const newLimit = parseInt(e.target.value);
                setInternalLimit(newLimit);
                setCurrentPage(1);
                if (onLimitChange) onLimitChange(newLimit);
              }}
              className="border rounded px-2 py-1 text-sm"
            >
              <option value={20}>20</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
              <option value={500}>500</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Desktop Table View */}
      <div className="hidden md:block rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">
                <div 
                  className="flex items-center gap-1 cursor-pointer"
                  onClick={() => handleSortChange('orderNumber')}
                >
                  Order No.
                  {sortField === 'orderNumber' && (
                    sortDirection === 'asc' ? (
                      <ChevronUp size={14} />
                    ) : (
                      <ChevronDown size={14} />
                    )
                  )}
                </div>
              </TableHead>
              
              <TableHead>
                <div 
                  className="flex items-center gap-1 cursor-pointer"
                  onClick={() => handleSortChange('date')}
                >
                  Date
                  {sortField === 'date' && (
                    sortDirection === 'asc' ? (
                      <ChevronUp size={14} />
                    ) : (
                      <ChevronDown size={14} />
                    )
                  )}
                </div>
              </TableHead>
              
              <TableHead>
                <div 
                  className="flex items-center gap-1 cursor-pointer"
                  onClick={() => handleSortChange('dealer')}
                >
                  Party Name
                  {sortField === 'dealer' && (
                    sortDirection === 'asc' ? (
                      <ChevronUp size={14} />
                    ) : (
                      <ChevronDown size={14} />
                    )
                  )}
                </div>
              </TableHead>
              
              <TableHead>Plant</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-center">Quantity</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-right w-[100px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center">
                  <div className="flex justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                </TableCell>
              </TableRow>
            ) : displayData.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center">
                  <div className="text-muted-foreground">
                    No sales found
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              displayData.map((sale) => (
                <TableRow key={`table-${sale.id}`} className="hover:bg-muted/30">
                  {/* Order Number */}
                  <TableCell>
                    <span className="flex items-center gap-1 font-medium">
                      #{sale.orderNumber}
                    </span>
                  </TableCell>
                  
                  {/* Date */}
                  <TableCell>{formatDate(sale.date)}</TableCell>
                  
                  {/* Dealer name column */}
                  <TableCell className="font-medium">
                    {sale.dealer && sale.dealer !== "Unknown" 
                      ? sale.dealer 
                      : sale.party && sale.party !== "Unknown" 
                        ? sale.party 
                        : sale.party_name && sale.party_name !== "Unknown" 
                          ? sale.party_name 
                          : "N/A"}
                  </TableCell>
                  
                  {/* Plant column */}
                  <TableCell>
                    {sale.plant && sale.plant !== "Unknown" ? (
                      <PlantBadge plant={sale.plant} />
                    ) : (
                      <span className="text-gray-500">-</span>
                    )}
                  </TableCell>
                  
                  {/* Status column */}
                  <TableCell>
                    <StatusBadge status={sale.status} />
                  </TableCell>
                  
                  {/* Quantity column */}
                  <TableCell className="text-center font-medium text-green-600">
                    {(() => {
                      // First try to parse sale.quantity, which may be string or number
                      const displayQty = typeof sale.quantity === 'string' 
                        ? parseInt(sale.quantity) 
                        : sale.quantity;
                      
                      // If valid number, display it
                      if (displayQty && !isNaN(displayQty) && displayQty > 0) {
                        return displayQty;
                      }
                      
                      // If we have items array with quantity values, calculate total
                      if (sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
                        return sale.items.reduce((sum, item) => {
                          const itemQty = typeof item.quantity === 'string' 
                            ? parseInt(item.quantity) || 0 
                            : item.quantity || 0;
                          return sum + itemQty;
                        }, 0);
                      }
                      
                      // Default fallback
                      return displayQty || 0;
                    })()}
                  </TableCell>
                  
                  {/* Amount column */}
                  <TableCell className="text-right font-medium">
                    {(() => {
                      // First try to parse sale.amount directly
                      if (sale.amount && parseFloat(sale.amount) > 0) {
                        return `₹${parseFloat(sale.amount).toLocaleString()}`;
                      }
                      
                      // If we have items with totalPrice or unitPrice * quantity, calculate total
                      if (sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
                        const total = sale.items.reduce((sum, item) => {
                          let itemTotal = 0;
                          
                          // If item has totalPrice, use it
                          if (item.totalPrice) {
                            itemTotal = typeof item.totalPrice === 'string' 
                              ? parseFloat(item.totalPrice) 
                              : item.totalPrice;
                          } 
                          // Otherwise calculate from unitPrice * quantity
                          else if (item.unitPrice && item.quantity) {
                            const unitPrice = typeof item.unitPrice === 'string' 
                              ? parseFloat(item.unitPrice) 
                              : item.unitPrice;
                            const quantity = typeof item.quantity === 'string' 
                              ? parseInt(item.quantity) 
                              : item.quantity;
                            itemTotal = unitPrice * quantity;
                          }
                          
                          return sum + (isNaN(itemTotal) ? 0 : itemTotal);
                        }, 0);
                        
                        return total > 0 ? `₹${total.toLocaleString()}` : <span className="text-gray-500">-</span>;
                      }
                      
                      // Default fallback
                      return <span className="text-gray-500">-</span>;
                    })()}
                  </TableCell>
                  
                  {/* Actions column */}
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      {/* Sale Details Dialog */}
                      <OptimizedSaleDetailsDialog 
                        saleId={sale.id} 
                        orderNumber={sale.orderNumber} 
                        saleData={sale}
                        isBackup={isBackup}
                      />
                      
                      {/* Delete action */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600 hover:text-red-800 hover:bg-red-100"
                        onClick={() => handleDeleteSale(sale.id)}
                      >
                        <Trash size={16} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : displayData.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground">
            No sales found
          </div>
        ) : (
          displayData.map((sale) => {
            // Calculate quantity for display
            const calculateQuantity = () => {
              const displayQty = typeof sale.quantity === 'string' 
                ? parseInt(sale.quantity) 
                : sale.quantity;
              
              if (displayQty && !isNaN(displayQty) && displayQty > 0) {
                return displayQty;
              }
              
              if (sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
                return sale.items.reduce((sum, item) => {
                  const itemQty = typeof item.quantity === 'string' 
                    ? parseInt(item.quantity) || 0 
                    : item.quantity || 0;
                  return sum + itemQty;
                }, 0);
              }
              
              return displayQty || 0;
            };
            
            // Calculate amount for display
            const calculateAmount = () => {
              if (sale.amount && parseFloat(sale.amount) > 0) {
                return `₹${parseFloat(sale.amount).toLocaleString()}`;
              }
              
              if (sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
                const total = sale.items.reduce((sum, item) => {
                  let itemTotal = 0;
                  
                  if (item.totalPrice) {
                    itemTotal = typeof item.totalPrice === 'string' 
                      ? parseFloat(item.totalPrice) 
                      : item.totalPrice;
                  } 
                  else if (item.unitPrice && item.quantity) {
                    const unitPrice = typeof item.unitPrice === 'string' 
                      ? parseFloat(item.unitPrice) 
                      : item.unitPrice;
                    const quantity = typeof item.quantity === 'string' 
                      ? parseInt(item.quantity) 
                      : item.quantity;
                    itemTotal = unitPrice * quantity;
                  }
                  
                  return sum + (isNaN(itemTotal) ? 0 : itemTotal);
                }, 0);
                
                return total > 0 ? `₹${total.toLocaleString()}` : "-";
              }
              
              return "-";
            };
            
            // Get dealer/party name
            const dealerName = sale.dealer && sale.dealer !== "Unknown" 
              ? sale.dealer 
              : sale.party && sale.party !== "Unknown" 
                ? sale.party 
                : sale.party_name && sale.party_name !== "Unknown" 
                  ? sale.party_name 
                  : "N/A";
            
            return (
              <div key={`card-${sale.id}`} className="border rounded-md overflow-hidden bg-white p-3">
                {/* Single unified card without dividers */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">#{sale.orderNumber}</span>
                    {sale.plant && sale.plant !== "Unknown" && (
                      <PlantBadge plant={sale.plant} />
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {formatDate(sale.date)}
                  </div>
                </div>
                
                {/* Show dealer/party name directly without the title */}
                <div className="text-gray-600 mb-2">{dealerName}</div>
                
                {/* Flex container for actions and quantity/amount */}
                <div className="flex justify-between items-center mb-3">
                  {/* Actions with circular backgrounds */}
                  <div className="flex items-center gap-2">
                    {/* Sale Details Dialog */}
                    <div className="bg-blue-50 rounded-full">
                      <OptimizedSaleDetailsDialog 
                        saleId={sale.id} 
                        orderNumber={sale.orderNumber} 
                        saleData={sale}
                        isBackup={isBackup}
                        buttonSize="md"
                      />
                    </div>
                    
                    {/* Delete action */}
                    <div className="bg-red-50 rounded-full">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-10 w-10 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full"
                        onClick={() => handleDeleteSale(sale.id)}
                      >
                        <Trash className="h-6 w-6 text-red-500" style={{height: '1.5rem', width: '1.5rem'}} />
                      </Button>
                    </div>
                  </div>
                  
                  {/* Quantity and Amount aligned to the right */}
                  <div className="flex flex-col items-end gap-1">
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-muted-foreground">Qty:</span>
                      <span className="font-medium text-green-600">{calculateQuantity()}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-muted-foreground">Amt:</span>
                      <span className="font-bold text-[#0B2F6E]">{calculateAmount()}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
      
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="text-sm text-muted-foreground order-2 sm:order-1">
            Page {currentPage} of {totalPages}
          </div>
          <div className="flex items-center gap-1 sm:gap-2 order-1 sm:order-2">
            <Button
              variant="outline"
              size="sm"
              className="px-2 h-8"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft size={16} />
            </Button>
            
            {/* Generate page number buttons - fewer on mobile */}
            {Array.from({ length: isMobile ? Math.min(3, totalPages) : Math.min(5, totalPages) }).map((_, index) => {
              let pageNumber: number;
              
              // Logic to calculate page numbers to show, centered around current page if possible
              if (totalPages <= (isMobile ? 3 : 5)) {
                pageNumber = index + 1;
              } else if (currentPage <= (isMobile ? 2 : 3)) {
                pageNumber = index + 1;
              } else if (currentPage >= totalPages - (isMobile ? 1 : 2)) {
                pageNumber = totalPages - (isMobile ? 2 : 4) + index;
              } else {
                pageNumber = currentPage - (isMobile ? 1 : 2) + index;
              }
              
              return (
                <Button
                  key={pageNumber}
                  variant={currentPage === pageNumber ? "default" : "outline"}
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setCurrentPage(pageNumber)}
                >
                  {pageNumber}
                </Button>
              );
            })}
            
            <Button
              variant="outline"
              size="sm"
              className="px-2 h-8"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              <ChevronRight size={16} />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default OptimizedSalesTable;