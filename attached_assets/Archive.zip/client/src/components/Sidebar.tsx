import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { getCurrentUserPermissions } from '../lib/permissions';
import { formatUsername } from '@/lib/format-username';
import { 
  Home, 
  Settings, 
  Users, 
  ShoppingCart,
  Truck,
  LogOut,
  FileText,
  Clipboard,
  Package,
  PieChart,
  UserRound,
  History,
  Activity,
  Receipt,
  IndianRupee,
  Factory,
  ClipboardList
} from 'lucide-react';
import MessageIcon from '../assets/message-icon';
import QuicklineIcon from '../assets/quickline-icon';

interface SidebarProps {
  onLogout?: () => void;
}

interface CurrentUser {
  id: number;
  username: string;
  name?: string;
  role?: string;
  department?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ onLogout }) => {
  const [location] = useLocation();
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);

  useEffect(() => {
    // Get user information from localStorage
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      try {
        const userData = JSON.parse(userStr);
        setCurrentUser(userData);
      } catch (error) {
        console.error('Error parsing user data from localStorage:', error);
      }
    }
  }, []);

  // Handle logout click
  const handleLogoutClick = (e: React.MouseEvent) => {
    if (onLogout) {
      e.preventDefault();
      onLogout();
    }
  };

  // Group menu items by categories as shown in the image
  const menuCategories = [
    {
      title: "MAIN",
      items: [
        { label: 'Home', icon: <Home className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/' },
        { label: 'Messages', icon: <MessageIcon className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/messages' },
        { label: 'Check In/Out', icon: <UserRound className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/inout' },
      ]
    },
    {
      title: "OPERATIONS",
      items: [
        { label: 'Load Operations', icon: <Factory className="h-5 w-5 mr-3 text-[#001d6e]" style={{fill: "#4d7eff"}} />, path: '/load-operations' },
        { label: 'Scan History', icon: <History className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/scan-history' },
        { label: 'Reports', icon: <PieChart className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/reports' },
      ]
    },
    {
      title: "INVENTORY",
      items: [
        { label: 'Inventory', icon: <Package className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/inventory' },
        { label: 'Proforma Slips', icon: <FileText className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/proforma-slips' },
        { label: 'Sales', icon: <div className="mr-3">
          <div className="h-5 w-5 flex items-center justify-center border-2 border-[#001d6e] rounded-sm text-[#001d6e]">
            <span className="text-sm font-bold">₹</span>
          </div>
        </div>, path: '/sales' },
        { label: 'Purchases', icon: <ShoppingCart className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/purchases' },
      ]
    },
    {
      title: "ADMIN",
      items: [
        { label: 'User Management', icon: <Users className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/users' },
        { label: 'Activities', icon: <Activity className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/activities' },
        { label: 'Settings', icon: <Settings className="h-5 w-5 mr-3 text-[#001d6e]" />, path: '/settings' },
      ]
    },
  ];

  // Get user permissions for conditional rendering
  const userPermissions = getCurrentUserPermissions();

  // Filter categories based on user permissions
  const filteredCategories = menuCategories.filter(category => {
    // Hide ADMIN category for non-admin users
    if (category.title === "ADMIN" && !userPermissions.canManageUsers) {
      return false;
    }
    // Hide INVENTORY category for users without inventory access
    if (category.title === "INVENTORY" && !userPermissions.canAccessInventory) {
      return false;
    }
    return true;
  });

  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 bg-white border-r border-gray-200 h-screen">
      {/* Sidebar content */}
      <div className="flex-1 py-4 overflow-y-auto">
        {filteredCategories.map((category, index) => (
          <div key={index} className="mb-6 px-4">
            <h3 className="text-xs font-medium text-[#001d6e] mb-2">{category.title}</h3>
            <ul className="space-y-1">
              {category.items
                .filter(item => {
                  // Check if item requires permission
                  if (item.permission) {
                    // @ts-ignore - We know the permission exists
                    return userPermissions[item.permission] === true;
                  }
                  return true; // Show items with no permission requirement
                })
                .map((item) => (
                <li key={item.path}>
                  <Link 
                    href={item.path}
                    className={`flex items-center py-2 text-sm hover:bg-gray-50 ${
                      location === item.path
                        ? 'text-[#001d6e] font-medium border-l-4 border-[#001d6e] pl-3'
                        : 'text-[#001d6e] font-medium pl-4'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* User profile at bottom */}
      <div className="mt-auto px-4 py-4">
        <div className="p-4 bg-blue-50 rounded-md mb-2">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-[#001d6e] mr-3 flex items-center justify-center text-white font-semibold">
              {currentUser?.username ? 
                currentUser.username.replace('@km-tribe', '').charAt(0).toUpperCase() : 
                ''}
            </div>
            <div>
              <p className="text-sm font-medium text-[#001d6e]">
                {currentUser?.name || (currentUser?.username ? 
                  currentUser.username.replace('@km-tribe', '') : 
                  '')}
              </p>
              <p className="text-xs text-gray-500">
                {currentUser?.department || currentUser?.role || ''}
              </p>
            </div>
          </div>
        </div>

        <Link 
          href="/logout" 
          onClick={handleLogoutClick}
          className="flex items-center text-sm text-[#001d6e] py-2 pl-4 hover:bg-gray-50"
        >
          <LogOut className="h-5 w-5 mr-3 text-[#001d6e]" />
          Log Out
        </Link>
      </div>
    </aside>
  );
};

export default Sidebar;