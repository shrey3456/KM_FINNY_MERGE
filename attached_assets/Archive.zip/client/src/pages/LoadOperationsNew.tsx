// Enhanced OrderLookup function that uses the centralized helper library

import { enhancedOrderLookup, ProformaSlipItem, ProformaSlip } from "@/lib/productLoaderHelper";

// This is a more efficient version that replaces the existing handleOrderLookupForOperation
// It uses the centralized enhancedOrderLookup function from productLoaderHelper.ts
export async function handleOrderLookupForOperation(
  orderNumber: string, 
  setIsOrderSearchLoading: (loading: boolean) => void, 
  setProformaSlipDetails: (data: any) => void, 
  toast: any
) {
  try {
    if (!orderNumber.trim()) {
      toast({
        title: "Error",
        description: "Please enter an order number",
        variant: "destructive",
      });
      return null;
    }
    
    // Use our enhanced order lookup function with improved product data loading
    const processedData = await enhancedOrderLookup(orderNumber, setIsOrderSearchLoading);
    
    // Update the UI with the slip details
    setProformaSlipDetails(processedData);
    
    toast({
      title: "Success",
      description: `Found proforma slip #${processedData.slip.orderNumber}`,
    });
    
    return processedData;
  } catch (error) {
    console.error("Error in handleOrderLookupForOperation:", error);
    
    toast({
      title: "Error",
      description: error instanceof Error ? error.message : "Proforma slip not found with that order number",
      variant: "destructive",
    });
    
    setIsOrderSearchLoading(false);
    return null;
  }
}