import React from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/hooks/use-user";
import { useQuery } from "@tanstack/react-query";
import { format, parseISO } from "date-fns";
import { CheckCircle, XCircle, CalendarClock } from "lucide-react";

export function CheckInOutPage() {
  const { user } = useUser();
  const { toast } = useToast();

  // Fetch check-in/out records without date filtering
  const { data: checkInOuts = [], isLoading } = useQuery({
    queryKey: ['/api/checkinouts'],
    queryFn: async () => {
      const response = await fetch('/api/checkinouts');
      if (!response.ok) {
        throw new Error('Failed to fetch check-in/out records');
      }
      return response.json();
    },
    enabled: !!user,
  });

  // Manage the check-in/out records in a table
  return (
    <div className="container py-4 max-w-7xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Check In & Out Records</CardTitle>
          <CardDescription>
            View and manage employee check-in and check-out records
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center my-8">
              <div className="loading-dots">
                <div className="loading-dots--dot"></div>
                <div className="loading-dots--dot"></div>
                <div className="loading-dots--dot"></div>
              </div>
            </div>
          ) : checkInOuts.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No check-in/out records found
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Designation</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Status</TableHead>
                    {(user?.role === 'admin' || user?.designation?.toLowerCase() === 'director') && (
                      <TableHead>Actions</TableHead>
                    )}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {checkInOuts.map((record: any) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">
                        {record.userName || record.user?.name || 'Unknown'}
                      </TableCell>
                      <TableCell>
                        {record.userDesignation || record.user?.designation || 'N/A'}
                      </TableCell>
                      <TableCell>
                        {record.userDepartment || record.user?.department || 'N/A'}
                      </TableCell>
                      <TableCell>
                        {record.type === 'in' ? (
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                            Check In
                          </Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-800 hover:bg-red-200">
                            Check Out
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <CalendarClock className="h-4 w-4 text-gray-500" />
                          <span>
                            {record.timestamp 
                              ? format(parseISO(record.timestamp), 'MM/dd/yyyy hh:mm a')
                              : 'Unknown time'}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {record.approved ? (
                          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Approved
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="border-amber-500 text-amber-600">
                            <XCircle className="h-3 w-3 mr-1" />
                            Pending
                          </Badge>
                        )}
                      </TableCell>
                      {(user?.role === 'admin' || user?.designation?.toLowerCase() === 'director') && (
                        <TableCell>
                          {!record.approved && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                // Approve record functionality to be implemented
                                // Placeholder toast for now
                                toast({
                                  title: "Record Approved",
                                  description: "The check-in/out record has been approved"
                                });
                              }}
                            >
                              Approve
                            </Button>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default CheckInOutPage;