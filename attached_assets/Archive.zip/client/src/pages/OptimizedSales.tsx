import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import OptimizedSalesTable from "@/components/OptimizedSalesTable";
import TableFilterHeader from "@/components/TableFilterHeader";
import { Loader2, Search, CalendarIcon } from "lucide-react";
import type { Sale } from "@shared/schema";
import { PlantFilter } from "@/components/PlantFilter";
import { Input } from "@/components/ui/input";
import { SingleDateFilter } from "@/components/SingleDateFilter";
import { format, parseISO, isValid } from "date-fns";
import { useSingleDateFilter } from "@/hooks/useSingleDateFilter";

export default function OptimizedSales() {
  const [searchQuery, setSearchQuery] = useState('');
  const [allSalesData, setAllSalesData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Use the hook to manage date filter with persistence
  const { 
    savedDate: selectedDate, 
    saveDateFilter: setSelectedDate,
    clearSavedDateFilter: clearDateFilter,
    isInitialized: dateFilterInitialized
  } = useSingleDateFilter('sales');
  
  // Whether the date filter is actively being applied
  const [isDateFilterActive, setIsDateFilterActive] = useState<boolean>(false);
  
  const [selectedPlants, setSelectedPlants] = useState<string[]>([]);
  const [plantOptions, setPlantOptions] = useState<{value: string, label: string}[]>([]);
  const [entriesLimit, setEntriesLimit] = useState<number>(50); // Increase default to 50
  const [sortField, setSortField] = useState<string>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const { toast } = useToast();

  // Query sales data with minimal processing
  const { data: salesData, isLoading: salesLoading, refetch: refetchSales } = useQuery({
    queryKey: ['/api/sales'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/sales');
      const sales = await res.json();
      
      // Only prefetch items for the first 20 sales for immediate display
      // This prevents the loading animation from running too long
      const prioritySales = sales.slice(0, 20);
      
      // Function to fetch items for a sale
      const fetchItemsForSale = async (sale: any) => {
        try {
          const itemsRes = await fetch(`/api/sales/${sale.id}/items`);
          if (itemsRes.ok) {
            const items = await itemsRes.json();
            if (items && items.length > 0) {
              sale.items = items;
            }
          }
        } catch (err) {
          // Silently fail
        }
      };
      
      // Only fetch items for the first 20 sales
      await Promise.all(prioritySales.map(fetchItemsForSale));
      
      return sales;
    }
  });
  
  // Query sales backup data only if needed
  const { data: salesBackupData, isLoading: salesBackupLoading } = useQuery({
    queryKey: ['/api/backup/sales'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/backup/sales');
      return res.json();
    }
  });

  // Combine and process data only once when loaded
  useEffect(() => {
    // Only process data when both queries complete
    if (salesLoading || salesBackupLoading) {
      setIsLoading(true);
      return;
    }
    
    setIsLoading(false);
    
    if (salesData) {
      let combined = [...salesData];
      
      // Include backup data if available
      if (salesBackupData && Array.isArray(salesBackupData)) {
        const backupSales = salesBackupData.map(backup => ({
          id: backup.originalId || backup.id,
          orderNumber: backup.orderNumber,
          date: backup.date || backup.backupDate,
          dealer: backup.dealer || backup.partyName || "N/A",
          plant: backup.plant,
          status: backup.status,
          quantity: backup.quantity,
          amount: backup.amount || 0,
          notes: backup.notes,
          createdAt: backup.createdAt,
          createdById: backup.createdById,
          isBackup: true
        }));
        
        // Add backup sales, avoiding duplicates
        backupSales.forEach(backupSale => {
          // Check if this order number already exists in combined data
          const existingSale = combined.find(sale => 
            sale.orderNumber === backupSale.orderNumber && 
            formatSameDate(sale.date, backupSale.date)
          );
          
          if (!existingSale) {
            combined.push(backupSale);
          }
        });
      }
      
      setAllSalesData(combined);
      
      // Collect unique plants for filter
      const uniquePlants = new Set<string>();
      combined.forEach(sale => {
        if (sale.plant && typeof sale.plant === 'string' && sale.plant.trim() !== '') {
          uniquePlants.add(sale.plant.trim());
        }
      });
      
      const plantOptionsList = Array.from(uniquePlants).map(plant => ({
        value: plant,
        label: plant
      }));
      
      plantOptionsList.sort((a, b) => a.label.localeCompare(b.label));
      setPlantOptions(plantOptionsList);
    }
  }, [salesData, salesBackupData, salesLoading, salesBackupLoading]);

  // Helper for date comparison
  const formatSameDate = (date1: string | Date, date2: string | Date): boolean => {
    try {
      // Convert both to Date objects for comparison
      const d1 = date1 instanceof Date ? date1 : new Date(date1);
      const d2 = date2 instanceof Date ? date2 : new Date(date2);
      
      // Compare year, month, day
      return (
        d1.getFullYear() === d2.getFullYear() &&
        d1.getMonth() === d2.getMonth() &&
        d1.getDate() === d2.getDate()
      );
    } catch (e) {
      return false;
    }
  };

  // Update the date filter active state when selectedDate changes
  useEffect(() => {
    setIsDateFilterActive(!!selectedDate);
  }, [selectedDate]);

  // Apply search, plant, and date filters to sales data
  const filteredSales = allSalesData.filter(sale => {
    // Apply search filter
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = 
      !searchQuery || 
      (sale.orderNumber && sale.orderNumber.toLowerCase().includes(searchLower)) ||
      (sale.dealer && sale.dealer.toLowerCase().includes(searchLower)) ||
      (sale.plant && sale.plant.toLowerCase().includes(searchLower)) ||
      (sale.status && sale.status.toLowerCase().includes(searchLower));
      
    // Apply plant filter
    const matchesPlant = selectedPlants.length === 0 || 
      (sale.plant && selectedPlants.includes(sale.plant));
    
    // Apply date filter if active
    let matchesDate = true;
    if (isDateFilterActive && selectedDate) {
      try {
        let saleDate: Date;
        if (typeof sale.date === 'string') {
          // Handle common date formats
          saleDate = parseISO(sale.date);
          if (!isValid(saleDate)) {
            // Try to parse DD-MM-YYYY format (common in the system)
            const parts = sale.date.split('-');
            if (parts.length === 3) {
              // Convert DD-MM-YYYY to YYYY-MM-DD for parsing
              saleDate = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
            }
          }
        } else if (sale.date instanceof Date) {
          saleDate = sale.date;
        } else {
          // If we can't parse the date, don't match
          return false;
        }
        
        // Compare just the date part (year, month, day)
        matchesDate = formatSameDate(saleDate, selectedDate);
      } catch (e) {
        // If there's an error parsing the date, don't match
        matchesDate = false;
      }
    }
      
    return matchesSearch && matchesPlant && matchesDate;
  });

  // Handle delete sale action
  const handleDeleteSale = async (id: number) => {
    try {
      // Call API to delete the sale
      await apiRequest('DELETE', `/api/sales/${id}`);
      
      // Show success message
      toast({
        title: "Sale deleted",
        description: "The sale has been successfully deleted.",
        variant: "default",
      });
      
      // Refresh data
      refetchSales();
    } catch (error) {
      console.error("Error deleting sale:", error);
      toast({
        title: "Error",
        description: "Failed to delete the sale. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container px-2 sm:px-4 py-4 space-y-4 sm:space-y-6">
      {/* Header with icon and title */}
      <div className="flex flex-col space-y-1.5">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 flex items-center justify-center border-2 border-[#001d6e] rounded-sm text-[#001d6e]">
            <span className="text-lg font-bold">₹</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#001d6e]">Sales Management</h1>
        </div>
      </div>
      
      {/* Search input - Show only on desktop view */}
      <div className="hidden sm:block w-full">
        <div className="relative w-full">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search order #, party name..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      {/* Plant filter row - visible only on tablet/desktop */}
      <div className="hidden sm:block w-full">
        <PlantFilter
          plantOptions={plantOptions}
          selectedPlants={selectedPlants}
          onPlantChange={setSelectedPlants}
          size="sm"
        />
      </div>
      
      {/* Date filter row with plant filter beside clear icon on mobile */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-2 sm:mb-4">
        <SingleDateFilter 
          pageKey="sales"
          selectedDate={selectedDate}
          onDateChange={(date) => {
            setSelectedDate(date);
            setIsDateFilterActive(!!date);
          }}
          className="w-full sm:w-auto flex-grow-0"
        >
          {/* Plant filter beside the clear icon - only visible on mobile */}
          <div className="sm:hidden">
            <PlantFilter
              plantOptions={plantOptions}
              selectedPlants={selectedPlants}
              onPlantChange={setSelectedPlants}
              size="sm"
            />
          </div>
        </SingleDateFilter>
        
        {/* Search input - Mobile view only (below calendar) */}
        <div className="sm:hidden w-full mt-2">
          <div className="relative w-full">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search order #, party name..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        {/* Only show date filter indicator on tablet/desktop view */}
        {isDateFilterActive && selectedDate && (
          <div className="hidden sm:flex items-center mt-1 sm:mt-0">
            <span className="text-xs sm:text-sm text-muted-foreground bg-muted px-2 py-1 rounded-md whitespace-nowrap">
              Showing sales for {format(selectedDate, 'dd MMM yyyy')}
            </span>
          </div>
        )}
      </div>
      
      {/* Optimized Sales Table */}
      <OptimizedSalesTable
        data={filteredSales}
        isLoading={isLoading}
        handleDeleteSale={handleDeleteSale}
        limit={entriesLimit}
        onLimitChange={setEntriesLimit}
        sortField={sortField}
        sortDirection={sortDirection}
        onSortChange={(field, direction) => {
          setSortField(field);
          setSortDirection(direction);
        }}
      />
    </div>
  );
}