import { useEffect } from 'react';

interface CacheEntry {
  data: any[];
  timestamp: number;
}

const tableStateCache = new Map<string, CacheEntry>();

export function preserveTableState(key: string, data: any[]) {
  if (data && data.length > 0) {
    tableStateCache.set(key, {
      data,
      timestamp: Date.now()
    });
  }
}

export function getPreservedTableState(key: string) {
  const entry = tableStateCache.get(key);
  return entry?.data || [];
}

export function clearTableState(key: string) {
  tableStateCache.delete(key);
}

export function useTableStatePreservation(key: string, data: any[]) {
  useEffect(() => {
    if (data?.length > 0) {
      preserveTableState(key, data);
    }
  }, [key, data]);

  return getPreservedTableState(key);
}

// Export cleanup function for manual cleanup
export function cleanupTableCache() {
  tableStateCache.clear();
}

// Cleanup old entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [id, cache] of tableStateCache.entries()) {
    if (now - cache.timestamp > 3600000) { // 1 hour
      tableStateCache.delete(id);
    }
  }
}, 3600000);