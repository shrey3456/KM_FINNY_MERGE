/**
 * Enhanced saveAllChanges utility function for warehouse pages
 * This function preserves form state and prevents tables from going blank
 * 
 * Usage: Import this into each warehouse component and use it as the saveAllChanges function
 */

import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ensureDialogOpen } from "./formStatePreservation";
import { updateCachedOperation } from "./tableStatePreservation";

/**
 * Save all changes for a loading operation
 * This function will:
 * 1. Preserve form state and keep dialogs open
 * 2. Update the table state to prevent blank tables
 * 3. Save changes to the backend in a batch
 * 
 * @param operationId The operation ID
 * @param items Items to update
 * @param onSuccess Optional callback on success
 * @param onError Optional callback on error
 */
export async function saveAllChanges(
  operationId: number, 
  items: any[], 
  onSuccess?: () => void,
  onError?: (error: any) => void
) {
  console.log("[SaveChanges] Starting save operation...");
  const startTime = performance.now();

  if (!operationId || !items || !items.length) {
    console.log("No operation ID or items to save");
    return;
  }

  try {
    // First, ensure the dialog stays open during the operation
    ensureDialogOpen(operationId);
    
    // Create an array to track all update promises
    const updatePromises = [];

    // Process items in parallel with a limit of 10 concurrent requests
    const batchSize = 10;
    
    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);
      
      const batchPromises = batch.map(async (item) => {
        try {
          const result = await apiRequest(
            `/api/proforma-slip-items/${item.id}`,
            {
              method: "PUT",
              data: { 
                quantity: item.quantity,
                loaded: item.loaded ?? false
              }
            }
          );
          return result;
        } catch (error) {
          console.error(`Error updating item ${item.id}:`, error);
          throw error;
        }
      });
      
      // Wait for the current batch to complete before processing the next batch
      const batchResults = await Promise.all(batchPromises);
      updatePromises.push(...batchResults);
    }

    // All updates completed
    console.log("Updated proforma details after save:", updatePromises);
    
    // Update the cached operation to reflect the changes
    const operation = await apiRequest(
      `/api/loading-operations/${operationId}`,
      { method: "GET" }
    );
    
    if (operation) {
      updateCachedOperation(operation);
    }
    
    const endTime = performance.now();
    console.log(`[SaveChanges] Save operation completed in ${(endTime - startTime).toFixed(2)}ms`);

    // Show success toast
    toast({
      title: "Changes saved",
      description: "All changes have been saved successfully.",
    });

    // Call the onSuccess callback if provided
    if (onSuccess) {
      onSuccess();
    }

    // Ensure the dialog stays open after the operation
    ensureDialogOpen(operationId);
    
  } catch (error) {
    console.error("Error updating items:", error);
    
    // Show error toast
    toast({
      variant: "destructive",
      title: "Error saving changes",
      description: "An error occurred while saving changes. Please try again.",
    });

    // Call the onError callback if provided
    if (onError) {
      onError(error);
    }

    // Even on error, ensure the dialog stays open
    ensureDialogOpen(operationId);
  }
}