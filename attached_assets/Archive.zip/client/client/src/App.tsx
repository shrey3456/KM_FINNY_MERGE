import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Dashboard";
import Scanner from "@/pages/Scanner";
import Inventory from "@/pages/Inventory";
import Reports from "@/pages/Reports";
import Users from "@/pages/Users";
import Settings from "@/pages/Settings";
import Purchases from "@/pages/Purchases";
import LoadOperations from "./pages/LoadOperations";
import Sales from "./pages/Sales";
import Login from "./pages/Login";
import SplashScreen from "./pages/SplashScreen";
import ScanHistoryPage from "./pages/ScanHistoryPage";
import Profile from "./pages/Profile";
import ProformaSlips from "./pages/ProformaSlips";
import Activities from "./pages/Activities";
// BackupPage removed as requested
import MessagesPage from "./pages/MessagesPage";
import CheckInOutPage from "./pages/CheckInOutPage";
import { useState, useEffect, useCallback, Suspense, lazy } from "react";
import Layout from "@/components/Layout";
import { useToast } from "@/hooks/use-toast";
import { getCurrentUserPermissions } from "./lib/permissions";
import ProtectedRoute from "@/components/ProtectedRoute";

// Loading indicator component for Suspense fallback
const LoadingIndicator = () => (
  <div className="flex h-screen w-full items-center justify-center">
    <div className="h-16 w-16 animate-spin rounded-full border-b-2 border-t-2 border-primary"></div>
  </div>
);

// Router component with improved PWA support
function Router() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Check for existing user on mount and PWA status
  useEffect(() => {
    // Check authentication
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      setIsAuthenticated(true);
    }
    
    // Check if already installed
    const isInStandaloneMode = () => 
      (window.matchMedia('(display-mode: standalone)').matches) || 
      (window.navigator as any).standalone || 
      document.referrer.includes('android-app://');
    
    setIsStandalone(isInStandaloneMode());
    
    // Listen for beforeinstallprompt event
    const handleBeforeInstallPrompt = (e: Event) => {
      // Prevent Chrome 76+ from automatically showing the prompt
      e.preventDefault();
      // Stash the event so it can be triggered later
      setDeferredPrompt(e);
    };
    
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);
  
  // Online/offline detection
  useEffect(() => {
    const handleOnlineStatus = () => {
      const isCurrentlyOnline = navigator.onLine;
      setIsOnline(isCurrentlyOnline);
      
      if (!isCurrentlyOnline) {
        toast({
          title: "You're offline",
          description: "The app will continue to work with limited functionality",
          variant: "destructive",
        });
      } else {
        toast({
          title: "You're back online",
          description: "Full functionality has been restored",
          variant: "default",
        });
      }
    };
    
    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);
    
    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, [toast]);
  
  // Show splash screen for 2.5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);
  
  // Handle Login
  const handleLogin = () => {
    setIsAuthenticated(true);
  };
  
  // Handle Logout
  const handleLogout = useCallback(() => {
    localStorage.removeItem('currentUser');
    setIsAuthenticated(false);
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of KM-Tribe",
    });
    navigate('/');
  }, [navigate, toast]);
  
  // Logout route handler
  useEffect(() => {
    const checkLogoutRoute = (location: string) => {
      if (location === '/logout') {
        handleLogout();
      }
    };
    
    // Initial check
    checkLogoutRoute(window.location.pathname);
    
    // Set up listener for route changes
    const handleRouteChange = () => {
      checkLogoutRoute(window.location.pathname);
    };
    
    window.addEventListener('popstate', handleRouteChange);
    
    return () => {
      window.removeEventListener('popstate', handleRouteChange);
    };
  }, [handleLogout]);
  
  // Show splash screen
  if (showSplash) {
    return <SplashScreen />;
  }
  
  // Show login if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }
  
  // Install PWA prompt
  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      return;
    }
    
    // Show the installation prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const choiceResult = await deferredPrompt.userChoice;
    
    if (choiceResult.outcome === 'accepted') {
      toast({
        title: "Installation started",
        description: "KM Tribe is being installed on your device",
      });
    }
    
    // Clear the saved prompt as it can't be used again
    setDeferredPrompt(null);
  };

  return (
    <Layout onLogout={handleLogout}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/scan" component={Scanner} />
        <ProtectedRoute path="/inventory" component={Inventory} requireInventoryAccess={true} />
        <ProtectedRoute path="/purchases" component={Purchases} requireInventoryAccess={true} />
        <Route path="/loading-operations" component={LoadOperations} />
        <ProtectedRoute path="/sales" component={Sales} requireInventoryAccess={true} />
        <Route path="/proforma-slips" component={ProformaSlips} />
        <Route path="/reports" component={Reports} />
        <ProtectedRoute path="/users" component={Users} requireAdmin={true} />
        <ProtectedRoute path="/activities" component={Activities} requireAdmin={true} />
        <ProtectedRoute path="/settings" component={Settings} requireAdmin={true} />

        <Route path="/scan-history" component={ScanHistoryPage} />
        <Route path="/profile" component={Profile} />
        <Route path="/messages" component={MessagesPage} />
        <Route path="/inout" component={CheckInOutPage} />
        <ProtectedRoute path="/checkinout-admin" component={CheckInOutPage} requireAdmin={true} />
        <Route path="/logout">
          {() => {
            handleLogout();
            return null;
          }}
        </Route>
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

// Offline banner component to indicate when the app is offline
const OfflineBanner = ({ isOnline }: { isOnline: boolean }) => {
  if (isOnline) return null;
  
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-yellow-500 p-2 text-center text-sm font-semibold text-black">
      You're offline. Some features may be limited.
    </div>
  );
};

// Install PWA prompt banner
const InstallPromptBanner = ({ 
  deferredPrompt, 
  isStandalone, 
  onInstallClick 
}: { 
  deferredPrompt: any;
  isStandalone: boolean;
  onInstallClick: () => void;
}) => {
  if (isStandalone || !deferredPrompt) return null;
  
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-primary p-2 text-white">
      <div className="flex items-center justify-between">
        <span>Install KM Tribe for offline use</span>
        <button 
          onClick={onInstallClick}
          className="rounded bg-white px-2 py-1 text-sm font-medium text-primary"
        >
          Install
        </button>
      </div>
    </div>
  );
};

function App() {
  // Track online status
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  
  // Handle online/offline status
  useEffect(() => {
    const handleOnlineStatus = () => setIsOnline(navigator.onLine);
    
    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);
    
    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, []);
  
  // Handle PWA installation
  useEffect(() => {
    // Check if already installed
    const isInStandaloneMode = () => 
      (window.matchMedia('(display-mode: standalone)').matches) || 
      (window.navigator as any).standalone || 
      document.referrer.includes('android-app://');
    
    setIsStandalone(isInStandaloneMode());
    
    // Listen for beforeinstallprompt event
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);
  
  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setIsStandalone(true);
    }
    
    setDeferredPrompt(null);
  };
  
  return (
    <QueryClientProvider client={queryClient}>
      <Suspense fallback={<LoadingIndicator />}>
        <Router />
        <Toaster />
        <OfflineBanner isOnline={isOnline} />
        <InstallPromptBanner 
          deferredPrompt={deferredPrompt}
          isStandalone={isStandalone}
          onInstallClick={handleInstallClick}
        />
      </Suspense>
    </QueryClientProvider>
  );
}

export default App;
