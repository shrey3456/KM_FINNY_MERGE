import React from "react";
import { Button } from "@/components/ui/button";
import { BarChart3Icon, TruckIcon, IndianRupeeIcon } from "lucide-react";

interface SalesStatsProps {
  totalAmount: number;
  totalQuantity: number;
  ordersCount: number;
}

const SalesStats: React.FC<SalesStatsProps> = ({ totalAmount, totalQuantity, ordersCount }) => {
  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant="outline"
        size="sm"
        className="h-9 border-dashed flex items-center gap-1.5"
      >
        <IndianRupeeIcon className="h-3.5 w-3.5 text-green-500" />
        <span className="font-bold">₹{totalAmount.toLocaleString()}</span>
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        className="h-9 border-dashed flex items-center gap-1.5"
      >
        <BarChart3Icon className="h-3.5 w-3.5 text-blue-500" />
        <span className="font-bold">{totalQuantity.toLocaleString()}</span>
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        className="h-9 border-dashed flex items-center gap-1.5"
      >
        <TruckIcon className="h-3.5 w-3.5 text-amber-500" />
        <span className="font-bold">{ordersCount}</span>
      </Button>
    </div>
  );
};

export default SalesStats;