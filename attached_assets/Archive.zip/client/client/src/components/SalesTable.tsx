import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableFooter
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { PlantBadge } from "@/components/PlantBadge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Loader2, Store, Trash2Icon, Trash, Truck } from "lucide-react";

interface StatusBadgeProps {
  status: string | null | undefined;
}

// Create a custom status badge with consistent purple styling
const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  return (
    <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-purple-100 text-purple-800 border border-purple-500">
      {status ? status.toUpperCase() : "UNKNOWN"}
    </span>
  );
};

// SaleDetailsDialog component to fetch and display sale details
interface SaleDetailsDialogProps {
  saleId: number;
  orderNumber: string;
  saleData: any;
  isBackup?: boolean;
}

const SaleDetailsDialog: React.FC<SaleDetailsDialogProps> = ({ saleId, orderNumber, saleData, isBackup = false }) => {
  // Fetch the sale details
  const { data: saleDetails, isLoading: loadingSale } = useQuery({
    queryKey: [`/api/${isBackup ? 'backup/' : ''}sales/${saleId}`],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/${isBackup ? 'backup/' : ''}sales/${saleId}`);
      return res.json();
    }
  });

  // Fetch the sale items specifically 
  const { data: saleItems, isLoading: loadingItems } = useQuery({
    queryKey: [`/api/${isBackup ? 'backup/' : ''}sales/${saleId}/items`],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/${isBackup ? 'backup/' : ''}sales/${saleId}/items`);
      return res.json();
    },
    enabled: !!saleId
  });

  // Combine loading states
  const isLoading = loadingSale || loadingItems;
  
  // Extract sale data with items from the API response
  const sale = saleDetails || saleData;
  const items = saleItems || sale?.items || [];

  // Format function for dates
  const formatDate = (dateStr: string) => {
    if (!dateStr) return "N/A";
    
    // Handle ISO format with time (2025-04-03T09:09:41.370Z)
    if (dateStr.includes('T')) {
      try {
        const date = new Date(dateStr);
        if (!isNaN(date.getTime())) {
          const day = date.getDate().toString().padStart(2, '0');
          const month = (date.getMonth() + 1).toString().padStart(2, '0');
          const year = date.getFullYear();
          return `${day}/${month}/${year}`;
        }
      } catch (e) {
        // Ignore parsing errors, continue with other methods
      }
    }
    
    // Parse date with hyphen format (DD-MM-YYYY or YYYY-MM-DD)
    if (dateStr.includes('-')) {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        // Check if it's YYYY-MM-DD format (first part is 4-digit year)
        if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
          return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
        // Assume it's DD-MM-YYYY format
        return `${parts[0]}/${parts[1]}/${parts[2]}`;
      }
    }
    // Parse date with slash format (YYYY/MM/DD or DD/MM/YYYY)
    else if (dateStr.includes('/')) {
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        // Check if it's YYYY/MM/DD format (first part is 4-digit year)
        if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
          return `${parts[2]}/${parts[1]}/${parts[0]}`; // Convert to DD/MM/YYYY
        }
        // Already in DD/MM/YYYY format
        return dateStr;
      }
    }
    
    // Last resort: try to parse using standard Date
    try {
      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      }
    } catch (e) {
      // Ignore parsing errors
    }
    
    return dateStr; // If format is unexpected, just show the original
  };

  return (
    <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>Sale Details - #{orderNumber}</DialogTitle>
      </DialogHeader>
      
      {isLoading ? (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
            <div className="space-y-3 md:col-span-2">
              <div className="grid grid-cols-2 gap-2">
                <div className="font-medium text-muted-foreground">Order No.:</div>
                <div>#{sale.orderNumber}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="font-medium text-muted-foreground">Date:</div>
                <div>{formatDate(sale.date)}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="font-medium text-muted-foreground">Party Name:</div>
                <div className="font-semibold">{sale.dealer}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="font-medium text-muted-foreground">Plant:</div>
                <div>
                  {sale.plant ? (
                    <PlantBadge plant={sale.plant} />
                  ) : (
                    "Unknown"
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="font-medium text-muted-foreground">Vehicle Number:</div>
                <div>{sale.vehicleNumber || "Not assigned"}</div>
              </div>
              {sale.notes && (
                <div className="grid grid-cols-2 gap-2">
                  <div className="font-medium text-muted-foreground">Storekeeper:</div>
                  <div>
                    {(() => {
                      const storekeeperMatch = sale.notes.match(/Storekeeper: (.*?) \((.*?)\)/);
                      if (storekeeperMatch && storekeeperMatch.length >= 3) {
                        return (
                          <div className="flex items-center gap-2">
                            <span>{storekeeperMatch[1]}</span>
                            <span className="text-xs bg-purple-100 text-purple-800 px-2 py-0.5 rounded">
                              {storekeeperMatch[2]}
                            </span>
                          </div>
                        );
                      }
                      return "Unknown";
                    })()}
                  </div>
                </div>
              )}
            </div>
            <div className="bg-muted/10 p-4 rounded-md border border-muted">
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="font-medium text-muted-foreground">Status:</div>
                  <div>
                    <StatusBadge status={sale.status} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="font-medium text-muted-foreground">Total Quantity:</div>
                  <div className="font-semibold text-green-600">{sale.quantity}</div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="font-medium text-muted-foreground">Total Amount:</div>
                  <div className="font-bold text-blue-600">₹{sale.amount?.toLocaleString()}</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border rounded-md mt-4">
            <div className="p-3 bg-muted/30 font-medium flex items-center justify-between">
              <div>Item Details</div>
              <div className="text-sm text-muted-foreground">
                Total Items: {items?.length || 0}
              </div>
            </div>
            <div className="p-2 max-h-[50vh] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[60px]">Sr. No.</TableHead>
                    <TableHead className="w-[100px]">SKU</TableHead>
                    <TableHead className="min-w-[250px]">Item Name</TableHead>
                    <TableHead className="text-center w-[80px] text-green-600">Quantity</TableHead>
                    <TableHead className="text-right w-[120px]">Unit Price</TableHead>
                    <TableHead className="text-right w-[120px]">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items && items.length > 0 ? (
                    items.map((item: any, index: number) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell>{item.srNo || index + 1}</TableCell>
                        <TableCell className="font-medium">{item.sku || item.barcode || "N/A"}</TableCell>
                        <TableCell className="break-words max-w-[200px]">
                          <div className="font-medium">{item.itemName || item.name || "Unknown Item"}</div>
                          {item.category && <div className="text-xs text-muted-foreground mt-1">Category: {item.category}</div>}
                          {item.hsn && <div className="text-xs text-muted-foreground">HSN: {item.hsn}</div>}
                        </TableCell>
                        <TableCell className="text-center">
                          <span className="text-green-600 font-semibold">{item.quantity || 0}</span>
                        </TableCell>
                        <TableCell className="text-right">₹{(item.unitPrice || 0).toLocaleString()}</TableCell>
                        <TableCell className="text-right">₹{(item.totalPrice || (item.unitPrice || 0) * (item.quantity || 0)).toLocaleString()}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4 text-muted-foreground">
                        No items found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
                <TableFooter>
                  <TableRow>
                    <TableCell colSpan={3}>Total</TableCell>
                    <TableCell className="text-center text-green-600 font-semibold">
                      {items?.reduce((sum: number, item: any) => sum + (item.quantity || 0), 0) || 0}
                    </TableCell>
                    <TableCell></TableCell>
                    <TableCell className="text-right font-semibold">
                      ₹{items?.reduce((sum: number, item: any) => 
                        sum + (item.totalPrice || (item.unitPrice || 0) * (item.quantity || 0)), 0)?.toLocaleString() || "0"}
                    </TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
          </div>
        </>
      )}
    </DialogContent>
  );
};

interface SalesTableProps {
  isLoading: boolean;
  backupLoading?: boolean;
  data: any[];
  handleDeleteSale: (id: number) => void;
  handleBatchDeleteSales?: (ids: number[]) => void;
  limit?: number;
  onLimitChange?: (limit: number) => void;
  sortField?: string;
  sortDirection?: 'asc' | 'desc';
  onSortChange?: (field: string, direction: 'asc' | 'desc') => void;
}

const SalesTable: React.FC<SalesTableProps> = ({
  isLoading,
  backupLoading,
  data,
  handleDeleteSale,
  handleBatchDeleteSales,
  limit = 15,
  onLimitChange,
  sortField = 'date',
  sortDirection = 'desc',
  onSortChange
}) => {
  const [showAll, setShowAll] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState(1);
  // Keep local copy of the limit to ensure it's always used correctly
  const [internalLimit, setInternalLimit] = useState<number>(limit);
  // Selected sales for batch operations
  const [selectedSales, setSelectedSales] = useState<number[]>([]);
  
  // Update internal limit when external limit changes
  useEffect(() => {
    setInternalLimit(limit);
    setCurrentPage(1);
  }, [limit]);
  
  // Clear selections when data changes
  useEffect(() => {
    setSelectedSales([]);
  }, [data]);
  
  // When internal limit changes, notify parent component
  useEffect(() => {
    // Only notify if onLimitChange is provided and the internal limit is different from external limit
    if (onLimitChange && internalLimit !== limit) {
      onLimitChange(internalLimit);
    }
  }, [internalLimit, onLimitChange, limit]);

  // Calculate pagination using the internal limit
  const totalPages = Math.ceil(data.length / internalLimit);
  
  // Get current page of data - show either paginated data or all data if showAll is true
  const displayData = showAll 
    ? data 
    : data.slice((currentPage - 1) * internalLimit, Math.min(currentPage * internalLimit, data.length));
    
  // Handle select all functionality
  const toggleSelectAll = () => {
    // Get all selectable sales (non-backup) from the current display data
    const selectableSales = displayData.filter(sale => !sale.isBackup);
    
    // Calculate if all selectable items are currently selected
    const allSelected = selectableSales.length > 0 && 
                      selectableSales.every(sale => {
                        const numericId = typeof sale.id === 'string' ? parseInt(sale.id, 10) : sale.id;
                        return selectedSales.includes(numericId);
                      });
    
    if (allSelected) {
      // If all are selected, unselect all
      console.log("Unselecting all sales");
      setSelectedSales([]);
    } else {
      // Otherwise, select all non-backup items
      const nonBackupIds = selectableSales.map(sale => {
        const numericId = typeof sale.id === 'string' ? parseInt(sale.id, 10) : sale.id;
        return numericId;
      });
      console.log("Selecting all non-backup sales:", nonBackupIds);
      setSelectedSales(nonBackupIds);
    }
  };

  // Handle individual item selection toggle
  const toggleSelectItem = (id: number, isSelected: boolean) => {
    console.log(`Toggle sale ${id} to ${isSelected ? 'selected' : 'unselected'}`);
    if (isSelected) {
      // Make sure we don't add duplicate IDs and ensure id is a number
      setSelectedSales(prev => {
        const numericId = typeof id === 'string' ? parseInt(id, 10) : id;
        if (prev.includes(numericId)) return prev;
        return [...prev, numericId];
      });
    } else {
      const numericId = typeof id === 'string' ? parseInt(id, 10) : id;
      setSelectedSales(prev => prev.filter(saleId => saleId !== numericId));
    }
  };

  // Handle batch delete action
  const handleBatchDelete = () => {
    if (selectedSales.length === 0 || !handleBatchDeleteSales) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedSales.length} selected sales? This action cannot be undone.`)) {
      handleBatchDeleteSales(selectedSales);
    }
  };

  return (
    <>
      {/* Batch Actions Bar */}
      {handleBatchDeleteSales && (
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">
              {selectedSales.length > 0 ? (
                <span className="text-blue-600">{selectedSales.length} sales selected</span>
              ) : (
                <span className="text-gray-500">Select sales to perform batch actions</span>
              )}
            </span>
          </div>
          {selectedSales.length > 0 && (
            <Button 
              variant="destructive" 
              size="sm" 
              onClick={handleBatchDelete}
              className="flex items-center gap-1"
            >
              <Trash className="h-3.5 w-3.5" />
              Delete Selected ({selectedSales.length})
            </Button>
          )}
        </div>
      )}
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {handleBatchDeleteSales && (
                <TableHead className="w-[40px]">
                  <Checkbox 
                    checked={
                      displayData.filter(s => !s.isBackup).length > 0 && 
                      displayData.filter(s => !s.isBackup).every(sale => {
                        const numericId = typeof sale.id === 'string' ? parseInt(sale.id, 10) : sale.id;
                        return selectedSales.includes(numericId);
                      })
                    }
                    onCheckedChange={toggleSelectAll}
                    aria-label="Select all"
                  />
                </TableHead>
              )}
              <TableHead 
                className={`cursor-pointer hover:bg-muted/30 ${sortField === 'date' ? 'bg-muted/20' : ''} w-[100px]`}
                onClick={() => onSortChange && onSortChange('date', sortField === 'date' && sortDirection === 'desc' ? 'asc' : 'desc')}
              >
                <div className="flex items-center">
                  Date
                  {sortField === 'date' && (
                    sortDirection === 'asc' 
                      ? <ChevronUp className="ml-1 h-4 w-4" /> 
                      : <ChevronDown className="ml-1 h-4 w-4" />
                  )}
                </div>
              </TableHead>
              <TableHead 
                className={`cursor-pointer hover:bg-muted/30 ${sortField === 'orderNumber' ? 'bg-muted/20' : ''} w-[120px]`}
                onClick={() => onSortChange && onSortChange('orderNumber', sortField === 'orderNumber' && sortDirection === 'desc' ? 'asc' : 'desc')}
              >
                <div className="flex items-center">
                  Order No.
                  {sortField === 'orderNumber' && (
                    sortDirection === 'asc' 
                      ? <ChevronUp className="ml-1 h-4 w-4" /> 
                      : <ChevronDown className="ml-1 h-4 w-4" />
                  )}
                </div>
              </TableHead>
              <TableHead className="min-w-[200px]">Party Name</TableHead>
              <TableHead className="w-[120px]">Plant</TableHead>
              <TableHead className="w-[120px]">Status</TableHead>
              <TableHead className="w-[100px]">Quantity</TableHead>
              <TableHead className="w-[120px]">Amount</TableHead>
              <TableHead className="w-[100px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading || backupLoading ? (
              <TableRow>
                <TableCell colSpan={handleBatchDeleteSales ? 9 : 8} className="text-center py-10">
                  <div className="flex justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                </TableCell>
              </TableRow>
            ) : data && data.length > 0 ? (
              displayData.map((sale) => (
                <TableRow 
                  key={sale.id} 
                  className={sale.isBackup ? "bg-blue-50" : ""}
                  title={sale.isBackup ? "Archived Record (from backup)" : ""}
                >
                  {handleBatchDeleteSales && (
                    <TableCell>
                      {!sale.isBackup && (
                        <Checkbox 
                          checked={selectedSales.includes(
                            typeof sale.id === 'string' ? parseInt(sale.id, 10) : sale.id
                          )}
                          onCheckedChange={(checked) => toggleSelectItem(
                            typeof sale.id === 'string' ? parseInt(sale.id, 10) : sale.id, 
                            !!checked
                          )}
                          aria-label={`Select sale ${sale.orderNumber}`}
                        />
                      )}
                    </TableCell>
                  )}
                  <TableCell>
                    {sale.date
                      ? (() => {
                          try {
                            // Always format to DD/MM/YYYY regardless of input format
                            
                            // Handle ISO format (2025-04-03T09:09:41.370Z)
                            if (sale.date.includes('T')) {
                              const date = new Date(sale.date);
                              const day = date.getDate().toString().padStart(2, '0');
                              const month = (date.getMonth() + 1).toString().padStart(2, '0');
                              const year = date.getFullYear();
                              return `${day}/${month}/${year}`;
                            } 
                            // Handle hyphenated formats (both DD-MM-YYYY and YYYY-MM-DD)
                            else if (sale.date.includes('-')) {
                              const parts = sale.date.split('-');
                              if (parts.length === 3) {
                                // Check if it's YYYY-MM-DD format (first part is 4-digit year)
                                if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
                                  // Convert from YYYY-MM-DD to DD/MM/YYYY
                                  return `${parts[2]}/${parts[1]}/${parts[0]}`;
                                }
                                // Assume it's DD-MM-YYYY format
                                return `${parts[0]}/${parts[1]}/${parts[2]}`;
                              }
                            }
                            // Handle YYYY/MM/DD format
                            else if (sale.date.includes('/')) {
                              const parts = sale.date.split('/');
                              if (parts.length === 3) {
                                // Check if first part is a 4-digit year (YYYY/MM/DD format)
                                if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
                                  // Convert from YYYY/MM/DD to DD/MM/YYYY
                                  return `${parts[2]}/${parts[1]}/${parts[0]}`;
                                }
                                // Already in DD/MM/YYYY format
                                return sale.date;
                              }
                            }
                            
                            // For any other format, try to parse and format to DD/MM/YYYY
                            const fallbackDate = new Date(sale.date);
                            if (!isNaN(fallbackDate.getTime())) {
                              const day = fallbackDate.getDate().toString().padStart(2, '0');
                              const month = (fallbackDate.getMonth() + 1).toString().padStart(2, '0');
                              const year = fallbackDate.getFullYear();
                              return `${day}/${month}/${year}`;
                            }
                            
                            // If all else fails, return original
                            return sale.date;
                          } catch (error) {
                            // If any error in formatting, return original
                            return sale.date;
                          }
                        })()
                      : "N/A"}
                  </TableCell>
                  <TableCell className="font-medium">
                    {sale.isBackup && (
                      <span className="inline-flex items-center justify-center mr-1 w-4 h-4 rounded-full bg-blue-100 text-blue-800 text-xs">
                        H
                      </span>
                    )}
                    #{sale.orderNumber}
                  </TableCell>
                  <TableCell>{sale.dealer}</TableCell>
                  <TableCell>
                    {sale.plant ? (
                      <PlantBadge plant={sale.plant} />
                    ) : (
                      "Unknown"
                    )}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={sale.status} />
                  </TableCell>
                  <TableCell>{sale.quantity}</TableCell>
                  <TableCell>₹{sale.amount?.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="h-7 px-2 text-xs">
                            View
                          </Button>
                        </DialogTrigger>
                        <SaleDetailsDialog 
                          saleId={sale.id} 
                          orderNumber={sale.orderNumber}
                          saleData={sale}
                          isBackup={!!sale.isBackup}
                        />
                      </Dialog>
                      {!sale.isBackup ? (
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-50" 
                          title="Delete sales record"
                          onClick={() => handleDeleteSale(
                            typeof sale.id === 'string' ? parseInt(sale.id, 10) : sale.id
                          )}
                        >
                          <Trash2Icon className="h-3.5 w-3.5" />
                        </Button>
                      ) : (
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-7 w-7 text-gray-300 cursor-not-allowed" 
                          title="Cannot delete archived record"
                          disabled
                        >
                          <Trash2Icon className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={10} className="text-center py-10">
                  No sales found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
          {data && data.length > 0 && (
            <TableFooter className="bg-muted/50">
              <TableRow>
                {/* Add an empty cell for the checkbox column when batch delete is enabled */}
                {handleBatchDeleteSales && (
                  <TableCell>
                    {/* Empty cell for checkbox column */}
                  </TableCell>
                )}
                <TableCell className="font-semibold">
                  Total
                </TableCell>
                <TableCell className="font-semibold text-gray-700">
                  {/* Total order count */}
                  {data.length}
                </TableCell>
                <TableCell className="font-semibold text-gray-700">
                  {/* Unique party count */}
                  {new Set(data.map(sale => sale.dealer)).size}
                </TableCell>
                <TableCell>
                  {/* Empty cell */}
                </TableCell>
                <TableCell>
                  {/* Empty cell */}
                </TableCell>
                <TableCell className="font-semibold text-green-600">
                  {/* Total quantity */}
                  {data.reduce((sum, sale) => sum + (sale.quantity || 0), 0)}
                </TableCell>
                <TableCell className="font-semibold text-blue-600">
                  {/* Total amount */}
                  ₹{data.reduce((sum, sale) => sum + (sale.amount || 0), 0).toLocaleString()}
                </TableCell>
                <TableCell>
                  <div className="flex items-center justify-end">
                    {data.length > internalLimit && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 px-2 mr-2 text-xs flex items-center gap-1" 
                        onClick={() => setShowAll(!showAll)}
                      >
                        {showAll ? (
                          <>
                            <ChevronUp className="h-3 w-3" />
                            <span>Show Less</span>
                          </>
                        ) : (
                          <>
                            <ChevronDown className="h-3 w-3" />
                            <span>Show All</span>
                          </>
                        )}
                      </Button>
                    )}
                    
                    {onLimitChange && (
                      <div className="flex items-center gap-2">
                        {/* Pagination controls when not showing all */}
                        {!showAll && totalPages > 1 && (
                          <div className="flex items-center gap-1 mr-3">
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="h-6 w-6"
                              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                              disabled={currentPage === 1}
                            >
                              <ChevronLeft className="h-3 w-3" />
                            </Button>
                            
                            <span className="text-xs px-2">
                              Page {currentPage} of {totalPages}
                            </span>
                            
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="h-6 w-6"
                              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                              disabled={currentPage === totalPages}
                            >
                              <ChevronRight className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                        
                        {/* Entries per page dropdown */}
                        <div className="flex items-center gap-1">
                          <span className="text-xs whitespace-nowrap">Show entries:</span>
                          <select 
                            className="h-6 text-xs border rounded px-1 bg-background"
                            value={internalLimit}
                            onChange={(e) => {
                              const newLimit = Number(e.target.value);
                              if (newLimit !== internalLimit) {
                                // Update internal limit
                                setInternalLimit(newLimit);
                                // Reset to page 1 when changing limit
                                setCurrentPage(1);
                                // Notify parent component immediately with the new value
                                if (onLimitChange) {
                                  onLimitChange(newLimit);
                                }
                              }
                            }}
                            aria-label="Number of entries to display"
                          >
                            <option value={15}>15</option>
                            <option value={25}>25</option>
                            <option value={50}>50</option>
                            <option value={100}>100</option>
                            <option value={200}>200</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            </TableFooter>
          )}
        </Table>
      </div>
    </>
  );
};

export default SalesTable;