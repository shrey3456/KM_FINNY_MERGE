import React from 'react';
import { Link, useLocation } from 'wouter';
import { getCurrentUserPermissions } from '../lib/permissions';
import { 
  Home, 
  Package, 
  ScanLine, 
  User,
  ShoppingCart,
  TruckIcon,
  DollarSignIcon,
  LogOut
} from 'lucide-react';
import MessageIcon from '../assets/message-icon';

interface MobileNavigationProps {
  onLogout?: () => void;
}

const MobileNavigation: React.FC<MobileNavigationProps> = ({ onLogout }) => {
  const [location] = useLocation();
  
  const handleLogoutClick = (e: React.MouseEvent) => {
    if (onLogout) {
      e.preventDefault();
      onLogout();
    }
  };

  return (
    <nav className="lg:hidden bg-white border-t border-gray-200">
      <div className="flex justify-between items-center px-4">
        {/* Message icon on the left */}
        <Link 
          href="/messages" 
          className={`flex flex-col items-center py-3 px-2 ${
            location === '/messages' ? 'text-primary' : 'text-gray-500'
          }`}
        >
          <MessageIcon className="h-8 w-8" />
        </Link>
        
        {/* Home icon in the center */}
        <Link 
          href="/" 
          className={`flex flex-col items-center py-3 px-2 ${
            location === '/' ? 'text-primary' : 'text-gray-500'
          }`}
        >
          <Home className="h-8 w-8" />
        </Link>
        
        {/* Profile icon on the right */}
        <Link 
          href="/profile" 
          className={`flex flex-col items-center py-3 px-2 ${
            location === '/profile' ? 'text-primary' : 'text-gray-500'
          }`}
        >
          <User className="h-8 w-8" />
        </Link>
      </div>
    </nav>
  );
};

export default MobileNavigation;
