import { useQuery } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import { apiRequest } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Calendar, Activity, Filter, RefreshCcw, Search, User, CheckCircle2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

type ActivityData = {
  id: number;
  pageName: string;
  action: string;
  entityType: string;
  entityId: string | null;
  details: string | null;
  userId: number | null;
  userName: string | null;
  createdAt: string;
};

export default function Activities() {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [actionFilter, setActionFilter] = useState("all-actions");
  const [pageFilter, setPageFilter] = useState("all-pages");
  const [liveUpdate, setLiveUpdate] = useState(true);
  const [activityCount, setActivityCount] = useState(0);
  const [newActivities, setNewActivities] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout>();
  const limit = 50; // Increased limit to show more activities
  const offset = (currentPage - 1) * limit;

  // Fetch activities data
  const { 
    data, 
    isLoading, 
    refetch, 
    isRefetching, 
    dataUpdatedAt
  } = useQuery({
    queryKey: ["activities", limit, offset],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", `/api/activities`);
        if (!res.ok) {
          throw new Error(`Failed to fetch activities: ${res.status}`);
        }
        const activities = await res.json();
        
        // Update activity count - exclude test entries
        if (activities && Array.isArray(activities)) {
          // Filter out test activities
          const validActivities = activities.filter(
            (activity) => 
              activity.pageName?.toLowerCase() !== 'test' && 
              activity.action?.toLowerCase() !== 'test'
          );
          
          const previousCount = activityCount;
          setActivityCount(validActivities.length);
          
          // Calculate new activities
          if (previousCount > 0 && validActivities.length > previousCount) {
            const diff = validActivities.length - previousCount;
            setNewActivities((prev) => prev + diff);
            if (diff > 0) {
              toast({
                title: `${diff} New ${diff === 1 ? "Activity" : "Activities"}`,
                description: "New activities have been logged",
                variant: "default",
              });
            }
          }
        }
        
        return activities;
      } catch (error) {
        console.error("Error fetching activities:", error);
        return [];
      }
    },
    refetchInterval: liveUpdate ? 5000 : false, // Poll every 5 seconds if live update is enabled
  });

  // Show a notification when there are new activities
  useEffect(() => {
    if (newActivities > 0 && !isRefetching) {
      // Reset new activities counter when user manually refreshes
      setNewActivities(0);
    }
  }, [isRefetching, newActivities]);

  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // Filter data based on search query and filters, excluding test entries
  const filteredData = data
    ? data.filter((activity: ActivityData) => {
        // Exclude test entries completely
        if (activity.pageName?.toLowerCase() === 'test' || 
            activity.action?.toLowerCase() === 'test') {
          return false;
        }
        
        const matchesSearch =
          searchQuery === "" ||
          activity.pageName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          activity.action?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          activity.entityType?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (activity.userName &&
            activity.userName.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (activity.details &&
            activity.details.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesAction =
          actionFilter === "all-actions" || 
          activity.action?.toLowerCase() === actionFilter.toLowerCase();

        const matchesPage =
          pageFilter === "all-pages" || 
          activity.pageName?.toLowerCase() === pageFilter.toLowerCase();

        return matchesSearch && matchesAction && matchesPage;
      })
    : [];

  // Sort activities by newest first (createdAt desc)
  const sortedData = filteredData.sort((a, b) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  // Extract unique action types and page names for filters, excluding test entries
  const actionTypes = data 
    ? Array.from(new Set(data.map((activity: ActivityData) => activity.action)))
        .filter(Boolean)
        .filter((action) => action?.toLowerCase() !== 'test')
    : [];
    
  const pageNames = data
    ? Array.from(new Set(data.map((activity: ActivityData) => activity.pageName)))
        .filter(Boolean)
        .filter((page) => page?.toLowerCase() !== 'test')
    : [];

  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return format(date, "dd-MM-yyyy HH:mm:ss");
    } catch (error) {
      return dateString;
    }
  };

  // Format JSON details for display
  const formatDetails = (details: string | null) => {
    if (!details) return "—";
    try {
      const parsed = JSON.parse(details);
      return Object.entries(parsed)
        .map(([key, value]) => `${key}: ${value}`)
        .join(", ");
    } catch (error) {
      return details;
    }
  };

  // Get badge color based on action type
  const getActionBadgeColor = (action: string) => {
    switch (action.toLowerCase()) {
      case "create":
        return "bg-green-100 text-green-800 hover:bg-green-100";
      case "update":
        return "bg-blue-100 text-blue-800 hover:bg-blue-100";
      case "delete":
        return "bg-red-100 text-red-800 hover:bg-red-100";
      case "import":
        return "bg-purple-100 text-purple-800 hover:bg-purple-100";
      case "export":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100";
      case "test":
        return "bg-teal-100 text-teal-800 hover:bg-teal-100";
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-100";
    }
  };

  const paginated = sortedData.slice(0, limit);
  const totalPages = Math.ceil(sortedData.length / limit);

  return (
    <div className="container-fluid px-4 md:px-6 py-6 space-y-6 max-w-full">
      <div className="flex flex-col space-y-4">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <h2 className="text-2xl font-bold tracking-tight flex items-center">
            <Activity className="h-6 w-6 mr-2 text-[#001d6e]" />
            <span className="text-[#001d6e]">Activities</span>
            <Badge variant="outline" className="ml-2">
              {activityCount} Total
            </Badge>
          </h2>
          
          <div className="flex gap-2">
            <Button
              variant={liveUpdate ? "default" : "outline"}
              size="sm"
              onClick={() => setLiveUpdate(!liveUpdate)}
              className="w-full md:w-auto"
            >
              {liveUpdate ? (
                <>
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Live Updates On
                </>
              ) : (
                <>
                  <RefreshCcw className="h-4 w-4 mr-2" />
                  Live Updates Off
                </>
              )}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              className="w-full md:w-auto"
              disabled={isRefetching}
            >
              <RefreshCcw className={`h-4 w-4 mr-2 ${isRefetching ? "animate-spin" : ""}`} />
              Refresh {newActivities > 0 && `(${newActivities} new)`}
            </Button>
          </div>
        </div>

        {/* Last updated timestamp */}
        <div className="text-sm text-muted-foreground">
          Last updated: {dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString() : "Never"}
          {liveUpdate && " • Live updates enabled"}
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search activities..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select
              value={actionFilter}
              onValueChange={setActionFilter}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Filter by action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-actions">All Actions</SelectItem>
                {actionTypes.map((action) => {
                  const actionValue = action as string;
                  return actionValue ? (
                    <SelectItem key={actionValue} value={actionValue.toLowerCase()}>
                      {actionValue.charAt(0).toUpperCase() + actionValue.slice(1)}
                    </SelectItem>
                  ) : null;
                })}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select 
              value={pageFilter} 
              onValueChange={setPageFilter}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Filter by page" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-pages">All Pages</SelectItem>
                {pageNames.map((page) => {
                  const pageValue = page as string;
                  return pageValue ? (
                    <SelectItem key={pageValue} value={pageValue.toLowerCase()}>
                      {pageValue}
                    </SelectItem>
                  ) : null;
                })}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Activity Log</CardTitle>
          <CardDescription>
            Track all user activities across the application in real-time
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, index) => (
                <div key={index} className="flex flex-col gap-2">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-5 w-3/4" />
                </div>
              ))}
            </div>
          ) : paginated.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-muted-foreground">
                {data?.length === 0 
                  ? "No activities recorded yet" 
                  : "No activities match the current filters"}
              </p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Time</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Page</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Entity</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginated.map((activity: ActivityData) => (
                      <TableRow key={activity.id}>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                            <span>{formatDate(activity.createdAt)}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span>{activity.userName || "System"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{activity.pageName}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getActionBadgeColor(activity.action || '')}>
                            {activity.action}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {activity.entityType}
                          {activity.entityId && ` #${activity.entityId}`}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {formatDetails(activity.details)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {totalPages > 1 && (
                <div className="mt-4">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                          className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>

                      {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                        let pageNum = i + 1;
                        if (totalPages > 5) {
                          if (currentPage > 3 && currentPage < totalPages - 1) {
                            pageNum = currentPage - 2 + i;
                          } else if (currentPage >= totalPages - 1) {
                            pageNum = totalPages - 4 + i;
                          }
                        }
                        
                        return (
                          <PaginationItem key={i}>
                            <PaginationLink
                              onClick={() => setCurrentPage(pageNum)}
                              isActive={currentPage === pageNum}
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}

                      {totalPages > 5 && currentPage < totalPages - 2 && (
                        <PaginationItem>
                          <PaginationEllipsis />
                        </PaginationItem>
                      )}

                      {totalPages > 5 && currentPage < totalPages - 1 && (
                        <PaginationItem>
                          <PaginationLink
                            onClick={() => setCurrentPage(totalPages)}
                            isActive={currentPage === totalPages}
                          >
                            {totalPages}
                          </PaginationLink>
                        </PaginationItem>
                      )}

                      <PaginationItem>
                        <PaginationNext
                          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                          className={
                            currentPage === totalPages ? "pointer-events-none opacity-50" : ""
                          }
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}