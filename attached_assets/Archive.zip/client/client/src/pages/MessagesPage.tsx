import React, { useState, useEffect, useRef } from "react";
import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/hooks/use-user";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format, parseISO } from "date-fns";
import { Send, Image, Paperclip, MoreVertical, Users, UserCircle2, CheckCircle2, Search, Bell } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import MessageIcon from "../assets/message-icon";

export function MessagesPage() {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [previousMessageCount, setPreviousMessageCount] = useState(0);
  const [lastMessageId, setLastMessageId] = useState<number | null>(null);

  // Fetch users for displaying user info
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      return response.json();
    },
    enabled: !!user,
  });

  // Fetch all group messages
  const { data: groupMessages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/messages/conversation'],
    queryFn: async () => {
      const response = await fetch('/api/messages/conversation');
      if (!response.ok) {
        throw new Error('Failed to fetch group messages');
      }
      return response.json();
    },
    enabled: !!user?.id,
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: any) => {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messageData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to send message');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Clear the message input and refetch conversation
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/messages/conversation'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to send message: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Request notification permission
  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      toast({
        title: "Notifications Not Supported",
        description: "This browser does not support desktop notifications",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const permission = await Notification.requestPermission();
      setNotificationsEnabled(permission === "granted");
      
      if (permission === "granted") {
        toast({
          title: "Notifications Enabled",
          description: "You will now receive notifications for new messages",
        });
      } else {
        toast({
          title: "Notifications Disabled",
          description: "You will not receive notifications for new messages",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error requesting notification permission:", error);
    }
  };

  // Check notification permission on component mount
  useEffect(() => {
    if (!("Notification" in window)) return;
    
    // Check if permission is already granted
    if (Notification.permission === "granted") {
      setNotificationsEnabled(true);
    }
  }, []);

  // Check and trigger notifications for new messages
  useEffect(() => {
    if (!groupMessages || !notificationsEnabled || !user) return;
    
    // Only notify if we have messages and the count has increased
    if (groupMessages.length > 0 && 
        groupMessages.length > previousMessageCount && 
        previousMessageCount > 0) {
      
      // Get the latest message
      const latestMessage = groupMessages[groupMessages.length - 1];
      
      // Only notify if it's not from the current user and it's a new message
      if (latestMessage.senderId !== user.id && 
          (!lastMessageId || latestMessage.id !== lastMessageId)) {
        
        const sender = findUserById(latestMessage.senderId);
        const senderName = sender?.name || sender?.username || "Unknown User";
        
        // Create and show notification
        try {
          const notification = new Notification("KM-Tribe Team Chat", {
            body: `${senderName}: ${latestMessage.content.substring(0, 60)}${latestMessage.content.length > 60 ? '...' : ''}`,
            icon: "/favicon.ico", // Use app icon
          });
          
          // Close notification after 5 seconds
          setTimeout(() => notification.close(), 5000);
          
          // Store the last notified message ID
          setLastMessageId(latestMessage.id);
        } catch (error) {
          console.error("Error showing notification:", error);
        }
      }
    }
    
    // Update previous count
    setPreviousMessageCount(groupMessages.length);
  }, [groupMessages, notificationsEnabled, user, previousMessageCount, lastMessageId]);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [groupMessages]);

  // Find user by ID helper function
  const findUserById = (userId: number) => {
    return users.find((u: any) => u.id === userId) || null;
  };

  // Handle send message
  const handleSendMessage = () => {
    if (!message.trim() || !user?.id) return;
    
    // Creating a message to all users (group message)
    sendMessageMutation.mutate({
      senderId: user.id,
      recipientId: 0, // 0 indicates group message
      content: message,
      isRead: false,
      broadcastToAll: true
    });
  };

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Implementation will be added later for file uploads
    toast({
      title: "File Upload",
      description: "File upload functionality will be implemented soon",
    });
  };

  return (
    <div className="container py-4 h-[calc(100vh-8rem)]">
      <Card className="h-full flex flex-col">
        {/* Group Chat Header */}
        <CardHeader className="pb-3 border-b">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-[#001d6e] mr-3 flex items-center justify-center">
                <MessageIcon className="h-5 w-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg text-[#001d6e]">Tribe team chat</CardTitle>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="bg-blue-50 rounded-full px-3 py-1 text-xs text-[#001d6e] font-medium">
                {users.length} Members
              </div>
              <Button
                variant="ghost"
                size="icon"
                title={notificationsEnabled ? "Notifications enabled" : "Enable notifications"}
                onClick={requestNotificationPermission}
                className={notificationsEnabled ? "text-[#001d6e] relative" : "text-gray-400 relative"}
              >
                {notificationsEnabled ? (
                  <>
                    <Bell className="h-5 w-5 fill-current" />
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border border-white"></span>
                  </>
                ) : (
                  <Bell className="h-5 w-5" />
                )}
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="max-h-80 overflow-y-auto">
                  <DropdownMenuItem disabled className="font-medium text-[#001d6e]">
                    <Users className="h-4 w-4 mr-2" />
                    All Members ({users.length})
                  </DropdownMenuItem>
                  
                  {users.map((member: any) => (
                    <DropdownMenuItem key={member.id} className="py-2">
                      <div className="flex items-center space-x-2">
                        <Avatar className="h-6 w-6">
                          <AvatarFallback className="bg-[#001d6e] text-white text-xs">
                            {member?.name?.charAt(0) || member?.username?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm">{member.name || member.username}</p>
                          <p className="text-xs text-gray-500">{member.role || 'User'}</p>
                        </div>
                        {member.isOnline && (
                          <div className="w-2 h-2 rounded-full bg-green-500 ml-auto" 
                            title="Online"></div>
                        )}
                      </div>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardHeader>
        
        {/* Messages area */}
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
          {messagesLoading ? (
            <div className="flex justify-center py-8">
              <div className="loading-dots">
                <div className="loading-dots--dot"></div>
                <div className="loading-dots--dot"></div>
                <div className="loading-dots--dot"></div>
              </div>
            </div>
          ) : groupMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12 text-gray-500">
              <div className="p-4 rounded-full bg-gray-100 mb-4">
                <MessageIcon className="h-10 w-10 text-[#001d6e]" />
              </div>
              <p>No messages yet</p>
              <p className="text-sm mt-1">Send a message to start the group chat</p>
            </div>
          ) : (
            groupMessages.map((msg: any) => {
              const isSender = msg.senderId === user?.id;
              const sender = findUserById(msg.senderId);
              
              return (
                <div 
                  key={msg.id} 
                  className={`flex items-start ${isSender ? 'justify-end' : 'justify-start'}`}
                >
                  {!isSender ? (
                    <Avatar className="h-8 w-8 mr-2 mt-1 flex-shrink-0">
                      <AvatarFallback className="bg-[#001d6e] text-white text-xs">
                        {sender?.name?.charAt(0) || sender?.username?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  ) : null}
                  
                  <div className="flex flex-col max-w-[80%]">
                  
                  {isSender && (
                    <div className="flex justify-end mb-1 mr-1">
                      <span className="text-xs text-gray-500">
                        You
                      </span>
                    </div>
                  )}
                    {!isSender && (
                      <span className="text-xs text-gray-500 mb-1 ml-1">
                        {sender?.name || sender?.username || 'Unknown User'}
                      </span>
                    )}
                    <div 
                      className={`rounded-lg px-4 py-2 ${
                        isSender 
                          ? 'bg-[#001d6e] text-white rounded-br-none'
                          : 'bg-gray-100 text-gray-800 rounded-bl-none'
                      }`}
                    >
                      <p className="break-words">{msg.content}</p>
                      <p className={`text-xs mt-1 ${isSender ? 'text-blue-100' : 'text-gray-500'}`}>
                        {msg.createdAt 
                          ? format(parseISO(msg.createdAt), 'MMM d, h:mm a')
                          : 'Just now'
                        }
                      </p>
                    </div>
                  </div>
                  {isSender && (
                    <Avatar className="h-8 w-8 ml-2 mt-1 flex-shrink-0 order-2">
                      <AvatarFallback className="bg-[#001d6e] text-white text-xs">
                        {user?.name?.charAt(0) || user?.username?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </CardContent>
        
        {/* Message input */}
        <div className="p-4 border-t">
          <div className="flex space-x-2">
            <Button 
              variant="outline"
              size="icon"
              type="button"
              onClick={() => fileInputRef.current?.click()}
            >
              <Paperclip className="h-5 w-5" />
            </Button>
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              onChange={handleFileUpload}
            />
            <Input
              placeholder="Type a message to the group..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
            <Button 
              type="button" 
              onClick={handleSendMessage}
              disabled={!message.trim()}
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

export default MessagesPage;