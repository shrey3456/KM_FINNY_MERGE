import { useEffect, useState } from 'react';
import tribeLogo from "../assets/tribe-logo.png";

// Add rotation keyframes to index.css
const rotateKeyframes = `
@keyframes rotate360 {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
`;

const SplashScreen = () => {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    // Start fade out animation after 2 seconds
    const timer = setTimeout(() => {
      setFadeOut(true);
    }, 2000);

    // Add the keyframes to the document
    const styleEl = document.createElement('style');
    styleEl.textContent = rotateKeyframes;
    document.head.appendChild(styleEl);

    return () => {
      clearTimeout(timer);
      document.head.removeChild(styleEl);
    };
  }, []);

  return (
    <div 
      className={`flex flex-col items-center justify-center min-h-screen bg-white transition-opacity duration-500 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      <div className="w-40 h-40 mb-8">
        <img 
          src={tribeLogo} 
          alt="KM-Tribe Logo" 
          className="w-full h-full object-contain" 
          style={{ animation: 'rotate360 3s linear forwards' }}
        />
      </div>
      <div className="absolute bottom-6 text-gray-500 text-sm">
        © {new Date().getFullYear()} KM-Tribe
      </div>
    </div>
  );
};

export default SplashScreen;