import ScannerView from '@/components/ScannerView';

const Scanner = () => {
  return (
    <div className="flex-1 overflow-y-auto">
      <div className="w-full">
        {/* Scanner Component - Full width for maximum scanning area */}
        <div className="px-4 pt-4 pb-4">
          <ScannerView onScanComplete={(result) => {
            // Additional logic after scan if needed
            console.log('Scan completed:', result);
          }} />
        </div>
      </div>
    </div>
  );
};

export default Scanner;
