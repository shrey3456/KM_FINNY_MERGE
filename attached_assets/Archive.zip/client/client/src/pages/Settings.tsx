import { useLocation } from 'wouter';
import MobileMenu from '@/components/ui/mobile-menu';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { useState } from 'react';
import { Smartphone, Radio, QrCode, Zap, Shield, Database } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

const Settings = () => {
  const [location] = useLocation();
  const form = useForm();
  const { toast } = useToast();
  const [isClearing, setIsClearing] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  
  const clearInventory = async () => {
    if (!confirm("Are you sure you want to clear all inventory data? This action cannot be undone.")) {
      return;
    }
    
    setIsClearing(true);
    try {
      const response = await fetch('/api/products/clear', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Success",
          description: "Inventory data cleared successfully",
          variant: "default"
        });
        console.log("Inventory cleared:", data);
      } else {
        const errorData = await response.text();
        toast({
          title: "Error",
          description: "Failed to clear inventory data",
          variant: "destructive"
        });
        console.error("Error clearing inventory:", errorData);
      }
    } catch (error) {
      console.error("Error clearing inventory:", error);
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsClearing(false);
    }
  };
  
  const resetStock = async () => {
    if (!confirm("Are you sure you want to reset all stock values to zero? This action cannot be undone.")) {
      return;
    }
    
    setIsResetting(true);
    try {
      const response = await fetch('/api/products/reset-stock', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Success",
          description: `Stock values reset successfully. ${data.updatedCount} products updated.`,
          variant: "default"
        });
        console.log("Stock reset:", data);
      } else {
        const errorData = await response.text();
        toast({
          title: "Error",
          description: "Failed to reset stock values",
          variant: "destructive"
        });
        console.error("Error resetting stock:", errorData);
      }
    } catch (error) {
      console.error("Error resetting stock:", error);
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsResetting(false);
    }
  };
  
  return (
    <>
      {/* Mobile Header */}
      <header className="lg:hidden bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-white font-bold">
              KM
            </div>
            <h1 className="text-xl font-bold">KM-Tribe</h1>
          </div>
          <MobileMenu currentPath={location} />
        </div>
      </header>
      
      <div className="flex-1 overflow-y-auto p-4 lg:p-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl font-bold">Settings</h2>
            <p className="text-gray-600">Configure application preferences</p>
          </div>
          
          <Tabs defaultValue="scanner">
            <TabsList className="mb-6">
              <TabsTrigger value="scanner">Scanner</TabsTrigger>
              <TabsTrigger value="app">Application</TabsTrigger>
              <TabsTrigger value="data">Data Management</TabsTrigger>
            </TabsList>
            
            <TabsContent value="scanner">
              <Card>
                <CardHeader>
                  <CardTitle>Scanner Settings</CardTitle>
                  <CardDescription>Configure how the barcode scanner functions</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="camera-flash">Camera Flash</Label>
                        <p className="text-sm text-muted-foreground">
                          Enable camera flash by default when scanning
                        </p>
                      </div>
                      <Switch id="camera-flash" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="continuous-scan">Continuous Scanning</Label>
                        <p className="text-sm text-muted-foreground">
                          Allow scanning multiple barcodes without closing dialog
                        </p>
                      </div>
                      <Switch id="continuous-scan" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="auto-detect">Auto Detection</Label>
                        <p className="text-sm text-muted-foreground">
                          Automatically detect and scan barcodes without pressing button
                        </p>
                      </div>
                      <Switch id="auto-detect" defaultChecked />
                    </div>
                    
                    <div className="border-t pt-4">
                      <h4 className="text-sm font-medium mb-2">Supported Barcode Types</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-y-2">
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="ean13" defaultChecked />
                          <label htmlFor="ean13" className="text-sm">EAN-13</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="ean8" defaultChecked />
                          <label htmlFor="ean8" className="text-sm">EAN-8</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="upc" defaultChecked />
                          <label htmlFor="upc" className="text-sm">UPC-A/UPC-E</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="code128" defaultChecked />
                          <label htmlFor="code128" className="text-sm">Code 128</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="code39" defaultChecked />
                          <label htmlFor="code39" className="text-sm">Code 39</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="qr" defaultChecked />
                          <label htmlFor="qr" className="text-sm">QR Code</label>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button>Save Settings</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="app">
              <Card>
                <CardHeader>
                  <CardTitle>Application Settings</CardTitle>
                  <CardDescription>Configure general application preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="dark-mode">Dark Mode</Label>
                        <p className="text-sm text-muted-foreground">
                          Switch between light and dark theme
                        </p>
                      </div>
                      <Switch id="dark-mode" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="notifications">Notifications</Label>
                        <p className="text-sm text-muted-foreground">
                          Enable notifications for important events
                        </p>
                      </div>
                      <Switch id="notifications" defaultChecked />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="language">Language</Label>
                      <select 
                        id="language" 
                        className="w-full flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      >
                        <option value="en">English</option>
                        <option value="es">Español</option>
                        <option value="fr">Français</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button>Save Settings</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="data">
              <Card>
                <CardHeader>
                  <CardTitle>Data Management</CardTitle>
                  <CardDescription>Manage your application data</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg bg-gray-50">
                      <h4 className="font-medium flex items-center"><Database className="h-4 w-4 mr-2" /> Data Export</h4>
                      <p className="text-sm text-gray-600 mt-1 mb-3">Export your scan history and inventory data</p>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Export Inventory</Button>
                        <Button variant="outline" size="sm">Export Scan History</Button>
                      </div>
                    </div>
                    
                    <div className="p-4 border rounded-lg bg-gray-50">
                      <h4 className="font-medium flex items-center"><Database className="h-4 w-4 mr-2" /> Data Import</h4>
                      <p className="text-sm text-gray-600 mt-1 mb-3">Import inventory data from CSV</p>
                      <Button variant="outline" size="sm">Import Data</Button>
                    </div>
                    
                    <div className="p-4 border border-red-200 rounded-lg bg-red-50">
                      <h4 className="font-medium text-red-600 flex items-center"><Shield className="h-4 w-4 mr-2" /> Danger Zone</h4>
                      <p className="text-sm text-red-600 mt-1 mb-3">These actions are irreversible</p>
                      <div className="flex flex-wrap gap-2">
                        <Button 
                          variant="destructive" 
                          size="sm"
                        >
                          Clear Scan History
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={clearInventory}
                          disabled={isClearing}
                        >
                          {isClearing ? "Clearing..." : "Clear Inventory"}
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={resetStock}
                          disabled={isResetting}
                        >
                          {isResetting ? "Resetting..." : "Reset Stock Values"}
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm"
                        >
                          Reset Application
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
};

export default Settings;
