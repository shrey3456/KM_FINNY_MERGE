import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { DateRange } from "react-day-picker";
import SalesTable from "@/components/SalesTable";
import SalesStats from "@/components/SalesStats";
import TableFilterHeader from "@/components/TableFilterHeader";
// Removed TablePagination
import { Loader2, Search, Clipboard } from "lucide-react";
import type { Sale } from "@shared/schema";
import { PlantFilter } from "@/components/PlantFilter";
import { Input } from "@/components/ui/input";
import { SingleDateFilter } from "@/components/SingleDateFilter";
import { useSingleDateFilter, SingleDateFilterStorage } from "@/hooks/useSingleDateFilter";
import { format } from "date-fns"; // Import format for date formatting

// Helper function to format date to DD/MM/YYYY
const formatDateToDDMMYYYY = (date: Date): string => {
  return format(date, 'dd/MM/yyyy');
};

// Utility function to parse dates in various formats
// This is a shared function used by both the filtering and sorting logic
const parseDateUniversal = (dateStr: string | Date | null | undefined): Date => {
  if (!dateStr) return new Date(0);
  
  try {
    if (typeof dateStr === 'string') {
      // Handle ISO format (2025-04-03T09:09:41.370Z)
      if (dateStr.includes('T')) {
        return new Date(dateStr);
      }
      // Handle DD/MM/YYYY format with slashes (standard format)
      else if (dateStr.includes('/')) {
        const parts = dateStr.split('/');
        if (parts.length === 3) {
          // Create date using day, month (0-based), year
          // Check if year needs to be expanded from 2-digit to 4-digit
          let year = parseInt(parts[2]);
          if (year < 100) {
            year = year < 50 ? 2000 + year : 1900 + year;
          }
          return new Date(year, parseInt(parts[1]) - 1, parseInt(parts[0]));
        }
      }
      // Handle DD-MM-YYYY or YYYY-MM-DD format with hyphens
      else if (dateStr.includes('-')) {
        const parts = dateStr.split('-');
        if (parts.length === 3) {
          // Check if it's YYYY-MM-DD format (first part is 4-digit year)
          if (parts[0].length === 4 && !isNaN(parseInt(parts[0]))) {
            return new Date(
              parseInt(parts[0]), // year
              parseInt(parts[1]) - 1, // month (0-based)
              parseInt(parts[2]) // day
            );
          } else {
            // Assume it's DD-MM-YYYY format
            // Check if year needs to be expanded from 2-digit to 4-digit
            let year = parseInt(parts[2]);
            if (year < 100) {
              year = year < 50 ? 2000 + year : 1900 + year;
            }
            return new Date(year, parseInt(parts[1]) - 1, parseInt(parts[0]));
          }
        }
      }
    }
    
    // Default case, try direct conversion
    return new Date(dateStr);
  } catch (e) {
    console.error("Date parsing error:", e, "for date:", dateStr);
    return new Date(0);
  }
};

export default function Sales() {
  const [searchQuery, setSearchQuery] = useState('');
  const [allSalesData, setAllSalesData] = useState<any[]>([]);
  // Initialize with today's date as default filter
  const { savedDate: selectedDate, saveDateFilter: setSelectedDate, isLocked, isInitialized, setLocked } = useSingleDateFilter('sales-page');
  // Single date filter is now managed by useSingleDateFilter hook
  const [selectedPlants, setSelectedPlants] = useState<string[]>([]);
  const [plantOptions, setPlantOptions] = useState<{value: string, label: string}[]>([]);
  const [entriesLimit, setEntriesLimit] = useState<number>(15); // Default is 15 entries
  const [sortField, setSortField] = useState<string>('date'); // Default sort by date
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc'); // Default newest first
  const { toast } = useToast();

  // Query all existing sales records from the database
  const { data: salesData, isLoading: salesLoading } = useQuery({
    queryKey: ['/api/sales'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/sales');
      return res.json();
    }
  });
  
  // Query sales backup data (historical data)
  const { data: salesBackupData, isLoading: salesBackupLoading } = useQuery({
    queryKey: ['/api/backup/sales'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/backup/sales');
      return res.json();
    }
  });

  // Store combined sales data in state for filtering
  useEffect(() => {
    if (salesData) {
      // Create a combined dataset with current and historical data
      let combined = [...salesData];
      
      // If we have backup data, transform it to match the format of current data and add it
      if (salesBackupData && Array.isArray(salesBackupData)) {
        const backupSales = salesBackupData.map(backup => ({
          id: backup.originalId || backup.id,
          orderNumber: backup.orderNumber,
          date: backup.date || backup.backupDate,  // Use original date or backup date
          dealer: backup.dealer || backup.partyName || "Unknown",
          plant: backup.plant,
          status: backup.status,
          quantity: backup.quantity,
          amount: backup.amount,
          notes: backup.notes,
          createdAt: backup.createdAt,
          createdById: backup.createdById,
          isBackup: true // Flag to indicate this is from backup
        }));
        
        // Add backup data while avoiding duplicates (based on order number and date)
        backupSales.forEach(backupSale => {
          // Only add if not already in the current data
          if (!combined.some(sale => {
            // First check order number match
            if (sale.orderNumber !== backupSale.orderNumber) {
              return false;
            }
            
            // Parse the DD-MM-YYYY date strings properly for both dates
            const parseDateString = (dateStr: string | Date) => {
              if (typeof dateStr === 'string' && dateStr.includes('-')) {
                const parts = dateStr.split('-');
                if (parts.length === 3) {
                  return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
                }
              }
              return new Date(dateStr);
            };
            
            const saleDate = parseDateString(sale.date);
            const backupDate = parseDateString(backupSale.date);
            
            return saleDate.toDateString() === backupDate.toDateString();
          })) {
            combined.push(backupSale);
          }
        });
      }
      
      setAllSalesData(combined);
      
      // Collect unique plants for the filter
      const uniquePlants = new Set<string>();
      
      combined.forEach(sale => {
        if (sale.plant && typeof sale.plant === 'string' && sale.plant.trim() !== '') {
          uniquePlants.add(sale.plant.trim());
        }
      });
      
      // Convert to options format for the PlantFilter component
      const plantOptionsList = Array.from(uniquePlants).map(plant => ({
        value: plant,
        label: plant
      }));
      
      // Sort plant options alphabetically
      plantOptionsList.sort((a, b) => a.label.localeCompare(b.label));
      
      setPlantOptions(plantOptionsList);
    }
  }, [salesData, salesBackupData]);

  // Query loading operations with ONLY "READY≈DESP" status for sales - without pagination
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['/api/loading-operations', 'READY≈DESP'],
    queryFn: async () => {
      // Fetch all operations with "READY≈DESP" status without pagination
      const res = await apiRequest('GET', `/api/loading-operations?status=READY≈DESP`);
      const loadingOps = await res.json();
      
      // For each loading operation, fetch the associated proforma slip to get details
      const enhancedOps = await Promise.all(
        loadingOps.map(async (op: any) => {
          try {
            // Get the proforma slip details to extract additional data
            const slipRes = await apiRequest('GET', `/api/proforma-slips/order/${op.referenceNumber}`);
            const slipData = await slipRes.json();
            
            // Get the slip items to calculate the total amount
            let totalAmount = 0;
            let enhancedItems = [];
            
            if (slipData && slipData.items && Array.isArray(slipData.items)) {
              // For each item in the slip, get the price from the inventory
              enhancedItems = await Promise.all(slipData.items.map(async (item: any, index: number) => {
                if (item && item.productId) {
                  try {
                    // Fetch product details from inventory to get the price
                    const productRes = await apiRequest('GET', `/api/products/${item.productId}`);
                    const productData = await productRes.json();
                    
                    // Calculate item total price: price * quantity
                    const itemQuantity = item.quantity || 0;
                    const unitPrice = productData.sellingPrice ? parseFloat(productData.sellingPrice) : 0;
                    const totalPrice = unitPrice * itemQuantity;
                    totalAmount += totalPrice;
                    
                    // Make sure we have all the quantity information
                    const originalQuantity = item.originalQuantity || itemQuantity;
                    
                    // Calculate extra quantity (loaded more than proforma)
                    const extraQuantity = itemQuantity > originalQuantity ? itemQuantity - originalQuantity : 0;
                    
                    // Calculate remain quantity (loaded less than proforma)
                    const remainQuantity = originalQuantity > itemQuantity ? originalQuantity - itemQuantity : 0;
                    
                    console.log(`Sale Item - ${productData.name}: Original: ${originalQuantity}, Loaded: ${itemQuantity}, Extra: ${extraQuantity}, Remain: ${remainQuantity}`);
                    
                    return {
                      ...item,
                      srNo: productData.srNo || index + 1,
                      itemName: productData.name || "Unknown Item",
                      sku: productData.barcode || "N/A",
                      originalQuantity: originalQuantity, // Ensure this is passed through
                      extraQuantity: extraQuantity,       // Calculate and pass through
                      remainQuantity: remainQuantity,     // Calculate and pass through
                      unitPrice: unitPrice,
                      totalPrice: totalPrice
                    };
                  } catch (err) {
                    console.error("Error fetching product info:", err);
                    const itemQuantity = item.quantity || 0;
                    const originalQuantity = item.originalQuantity || itemQuantity;
                    
                    return {
                      ...item,
                      srNo: index + 1,
                      itemName: "Unknown Item",
                      sku: "N/A",
                      originalQuantity: originalQuantity,
                      extraQuantity: 0,
                      remainQuantity: 0,
                      unitPrice: 0,
                      totalPrice: 0
                    };
                  }
                }
                return item;
              }));
            }
            
            // Combine the data to create a sale-like object from the loading operation
            const saleObject = {
              ...op,
              id: op.id,
              orderNumber: op.referenceNumber,
              date: op.createdAt,
              dealer: slipData.slip?.partyName || "Unknown",
              plant: slipData.slip?.plant || "Unknown",
              quantity: slipData.slip?.totalQuantity || 0,
              amount: totalAmount,
              status: "READY≈DESP", // Always display as READY≈DESP
              items: enhancedItems
            };
            
            // Automatically create a sales record if one doesn't exist
            const existingSale = salesData?.find((sale: any) => sale.orderNumber === op.referenceNumber);
            if (!existingSale) {
              try {
                // First create the sale
                const saleResponse = await apiRequest('POST', '/api/sales', {
                  orderNumber: op.referenceNumber,
                  dealer: slipData.slip?.partyName || "Unknown",
                  plant: slipData.slip?.plant || "Unknown",
                  quantity: slipData.slip?.totalQuantity || 0,
                  amount: totalAmount,
                  notes: `Auto-generated from Load Operation #${op.id}. Storekeeper: ${op.createdBy || "Unknown"}`,
                  status: "PENDING DESP",
                  createdById: op.createdById || 1,
                  // Use the original proforma slip order date instead of current date
                  date: slipData.slip?.orderDate ? slipData.slip?.orderDate : formatDateToDDMMYYYY(new Date()),
                  vehicleNumber: op.vehicleNumber || slipData.slip?.vehicleNumber
                });
                
                // Get the created sale data
                const saleData = await saleResponse.json();
                
                // Then add all the item details
                if (saleData && saleData.id && enhancedItems.length > 0) {
                  await apiRequest('POST', `/api/sales/${saleData.id}/items`, {
                    items: enhancedItems.map(item => ({
                      saleId: saleData.id,
                      sku: item.sku || null,
                      barcode: item.barcode || null,
                      name: item.itemName || "Unknown Item",
                      quantity: item.quantity || 0,
                      originalQuantity: item.originalQuantity || item.quantity || 0,
                      unitPrice: item.unitPrice || 0,
                      totalPrice: item.totalPrice || 0,
                      category: item.category || null,
                      hsn: item.hsn || null
                    }))
                  });
                }
                
                // Invalidate sales query to refresh data
                queryClient.invalidateQueries({ queryKey: ['/api/sales'] });
              } catch (error) {
                console.error("Error creating sales record:", error);
              }
            }
            
            return saleObject;
          } catch (error) {
            console.error("Error fetching proforma slip:", error);
            return {
              ...op,
              id: op.id,
              orderNumber: op.referenceNumber,
              date: op.createdAt,
              dealer: "Unknown",
              plant: "Unknown",
              quantity: 0,
              amount: 0,
              status: "READY≈DESP",
              items: []
            };
          }
        })
      );
      
      // Combine both existing sales data and enhanced operations
      const combinedData = [...enhancedOps];
      
      // Add any unique sales records that don't have corresponding loading operations
      if (salesData) {
        const loadingOpRefs = enhancedOps.map(op => op.orderNumber);
        const uniqueSales = salesData.filter((sale: any) => 
          !loadingOpRefs.includes(sale.orderNumber)
        );
        
        combinedData.push(...uniqueSales);
      }
      
      return combinedData;
    },
  });

  const handleAddSale = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const orderNumber = formData.get('orderNumber') as string;
    const dealer = formData.get('dealer') as string;
    const plant = formData.get('plant') as string;
    const quantity = parseInt(formData.get('quantity') as string || '0');
    const amount = parseInt(formData.get('amount') as string || '0');
    const notes = formData.get('notes') as string;
    const status = formData.get('status') as string;

    try {
      await apiRequest('POST', '/api/sales', {
        orderNumber,
        dealer,
        plant,
        quantity,
        amount,
        notes,
        status,
        createdById: 1, // Default admin for now
        date: formatDateToDDMMYYYY(new Date()), // Use standardized DD/MM/YYYY format
      });

      toast({
        title: "Success",
        description: "Sale record created successfully",
      });

      // Refresh sales data
      queryClient.invalidateQueries({ queryKey: ['/api/sales'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create sale record",
        variant: "destructive",
      });
    }
  };

  // Badge variant function no longer needed, now using the StatusBadge component from SalesTable
  
  // Previously had a custom StatusBadge component here, but now using the one from SalesTable component
  
  const handleDeleteSale = async (id: number) => {
    try {
      if (!window.confirm("Are you sure you want to delete this sales record? This action cannot be undone.")) {
        return;
      }
      
      await apiRequest('DELETE', `/api/sales/${id}`);
      
      toast({
        title: "Success",
        description: "Sales record deleted successfully",
      });
      
      // Refresh sales data
      queryClient.invalidateQueries({ queryKey: ['/api/sales'] });
    } catch (error) {
      console.error("Error deleting sales record:", error);
      toast({
        title: "Error",
        description: "Failed to delete sales record",
        variant: "destructive",
      });
    }
  };
  
  const handleBatchDeleteSales = async (ids: number[]) => {
    try {
      if (ids.length === 0) return;
      
      // Ensure all IDs are numbers (not strings)
      const numericIds = ids.map(id => typeof id === 'string' ? parseInt(id, 10) : id);
      
      console.log("Attempting to delete the following sales IDs:", numericIds);
      
      // Use the batch delete endpoint
      const response = await apiRequest('POST', '/api/sales/batch-delete', { ids: numericIds });
      const result = await response.json();
      
      console.log("Server response:", result);
      
      // Extract success and failed counts from the results object
      const successCount = result.results?.success?.length || 0;
      // Failed items are objects with id and reason
      const failedCount = result.results?.failed?.length || 0;
      
      // Display success/failure message
      if (successCount > 0) {
        toast({
          title: "Success",
          description: `Successfully deleted ${successCount} sales records`,
        });
        
        // Refresh sales data
        queryClient.invalidateQueries({ queryKey: ['/api/sales'] });
      } else {
        // If no successes at all, show a more prominent error
        toast({
          title: "No sales were deleted",
          description: "The operation completed but no records were removed",
          variant: "destructive",
        });
      }
      
      // If any failures, show warning
      if (failedCount > 0) {
        toast({
          title: "Warning",
          description: `Failed to delete ${failedCount} sales records`,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error performing batch deletion:", error);
      toast({
        title: "Error",
        description: "Failed to delete sales records",
        variant: "destructive",
      });
    }
  };

  // Using single date filter via useSingleDateFilter hook

  // Filter combined data based on search query, single date, and selected plants
  const filteredData = allSalesData?.filter(sale => {
    // Filter by search query
    if (searchQuery.trim() && !sale.orderNumber?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filter by single date (if a date is selected)
    if (selectedDate && sale.date) {
      try {
        // Parse the sale date using our universal parsing function
        const saleDate = parseDateUniversal(sale.date);
        
        // Set time components to zero for date-only comparison
        const filterDate = new Date(selectedDate);
        filterDate.setHours(0, 0, 0, 0);
        
        // Set time to beginning of day for proper comparison
        const saleDay = new Date(saleDate);
        saleDay.setHours(0, 0, 0, 0);
        
        // For debugging
        console.log(`Comparing dates: Filter date = ${filterDate.toISOString()}, Sale date = ${saleDay.toISOString()}`);
        
        // Compare only the date part (year, month, day)
        if (saleDay.getFullYear() !== filterDate.getFullYear() || 
            saleDay.getMonth() !== filterDate.getMonth() || 
            saleDay.getDate() !== filterDate.getDate()) {
          return false;
        }
      } catch (error) {
        console.error("Error filtering by date:", error, "for date:", sale.date);
        return false; // Exclude entries with invalid dates
      }
    }
    
    // Filter by selected plants
    if (selectedPlants.length > 0 && sale.plant) {
      if (!selectedPlants.includes(sale.plant)) {
        return false;
      }
    }
    
    return true;
  });
  
  // Sort the filtered data based on the selected sort field
  const sortedData = filteredData?.sort((a, b) => {
    if (sortField === 'orderNumber') {
      // Sort by order number (numeric comparison if possible)
      const orderA = a.orderNumber || '';
      const orderB = b.orderNumber || '';
      
      // Try to extract numeric parts for numeric comparison
      const numA = parseInt(orderA.replace(/\D/g, ''));
      const numB = parseInt(orderB.replace(/\D/g, ''));
      
      if (!isNaN(numA) && !isNaN(numB)) {
        return sortDirection === 'asc' ? numA - numB : numB - numA;
      }
      
      // Fallback to string comparison
      return sortDirection === 'asc' 
        ? orderA.localeCompare(orderB) 
        : orderB.localeCompare(orderA);
    } else if (sortField === 'date') {
      // Parse and convert dates for comparison
      let dateA: Date;
      let dateB: Date;
      
      // Use our universal date parsing function
      // Parse both dates
      dateA = parseDateUniversal(a.date);
      dateB = parseDateUniversal(b.date);
      
      // Sort by timestamp
      return sortDirection === 'asc' ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime();
    }
    
    // Default sorting by date descending
    return 0;
  });

  // Calculate total sales amount for all filtered data (not just visible rows)
  const totalAmount = filteredData?.reduce((acc, sale) => acc + (sale.amount || 0), 0) || 0;
  
  // Calculate total quantity for all filtered data (not just visible rows)
  const totalQuantity = filteredData?.reduce((acc, sale) => acc + (sale.quantity || 0), 0) || 0;

  return (
    <div className="container-fluid px-4 md:px-6 py-6 space-y-6 max-w-full">
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold tracking-tight flex items-center">
            <div className="h-6 w-6 mr-2 flex items-center justify-center border-2 border-[#001d6e] rounded-md text-[#001d6e]">
              <span className="text-sm font-bold">₹</span>
            </div>
            <span className="text-[#001d6e]">Sales</span>
          </h2>
        </div>
        
        {/* Full-width search bar above other filters */}
        <div className="relative w-full">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by order number..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          <SingleDateFilter
            selectedDate={selectedDate}
            onDateChange={(date: Date | null) => {
              // Using the proper method from useSingleDateFilter hook
              setSelectedDate(date);
              console.log("Date filter changed to:", date);
            }}
            isLocked={isLocked}
            onLockChange={(locked: boolean) => setLocked(locked)}
            className="scale-90"
          />
          
          <PlantFilter
            selectedPlants={selectedPlants}
            onPlantChange={setSelectedPlants}
            plantOptions={plantOptions}
          />
          
          <SalesStats 
            totalAmount={totalAmount}
            totalQuantity={totalQuantity}
            ordersCount={sortedData?.length || 0}
          />
        </div>
      </div>
      
      <SalesTable 
        isLoading={isLoading}
        backupLoading={salesBackupLoading}
        data={sortedData || []}
        handleDeleteSale={handleDeleteSale}
        handleBatchDeleteSales={handleBatchDeleteSales}
        limit={entriesLimit}
        onLimitChange={(newLimit) => setEntriesLimit(newLimit)}
        sortField={sortField}
        sortDirection={sortDirection}
        onSortChange={(field, direction) => {
          setSortField(field);
          setSortDirection(direction);
        }}
      />
    </div>
  );
}