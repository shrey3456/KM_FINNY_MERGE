import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { User } from '@shared/schema';

const Profile = () => {
  // Get the current user ID from local storage (if available)
  const userId = localStorage.getItem('userId');

  // Fetch user details
  const { data: user, isLoading, error } = useQuery({
    queryKey: ['/api/users', userId],
    queryFn: () => fetch(`/api/users/${userId}`).then(res => res.json()),
    enabled: !!userId, // Only run the query if we have a userId
  });

  if (isLoading) {
    return (
      <div className="p-6 flex justify-center items-center min-h-[50vh]">
        <div className="animate-pulse text-primary">Loading profile...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-red-500">Error loading profile information</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-muted-foreground">No profile information available</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">User Profile</h1>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border border-muted">
              <AvatarFallback className="text-lg font-medium">
                {user.name ? user.name.substring(0, 2).toUpperCase() : user.username.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-xl">{user.name || 'User'}</h2>
              <p className="text-muted-foreground text-sm">{user.username}</p>
            </div>
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <Separator className="my-4" />
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Role</h3>
              <p>{user.role || 'Not specified'}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Department</h3>
              <p>{user.department || 'Not specified'}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
              <p>{user.email || 'Not specified'}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
              <p>{user.phone || 'Not specified'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Profile;