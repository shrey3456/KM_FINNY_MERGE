// Role-based permissions system

export enum UserRole {
  READ = "read",
  READ_WRITE = "read/write",
  ADMIN = "admin",
  SUPER_ADMIN = "super-admin"
}

export interface Permissions {
  canRead: boolean;
  canCreate: boolean;
  canUpdate: boolean;
  canDelete: boolean;
  canManageUsers: boolean;
  canClearData: boolean;
  canManageSettings: boolean;
  canAccessInventory: boolean; // Permission to access inventory pages
  canDeleteOperationalItems: boolean; // Permission to delete scan history, load slips, and proforma slips
  canEditReadyDespOperations: boolean; // Permission to edit load slips with "READY≈DESP" status
}

// Define default permissions for different roles
export function getPermissionsForRole(role?: string): Permissions {
  switch (role) {
    case UserRole.SUPER_ADMIN:
      return {
        canRead: true,
        canCreate: true,
        canUpdate: true,
        canDelete: true,
        canManageUsers: true,
        canClearData: true,
        canManageSettings: true,
        canAccessInventory: true,
        canDeleteOperationalItems: true,
        canEditReadyDespOperations: true
      };
    case UserRole.ADMIN:
      return {
        canRead: true,
        canCreate: true,
        canUpdate: true,
        canDelete: true,
        canManageUsers: true,
        canClearData: true,
        canManageSettings: true,
        canAccessInventory: true,
        canDeleteOperationalItems: true,
        canEditReadyDespOperations: true
      };
    case UserRole.READ_WRITE:
      return {
        canRead: true,
        canCreate: true,
        canUpdate: true,
        canDelete: false,
        canManageUsers: false,
        canClearData: false,
        canManageSettings: false,
        canAccessInventory: false,
        canDeleteOperationalItems: false,
        canEditReadyDespOperations: false
      };
    case UserRole.READ:
      return {
        canRead: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        canManageUsers: false,
        canClearData: false,
        canManageSettings: false,
        canAccessInventory: false,
        canDeleteOperationalItems: false,
        canEditReadyDespOperations: false
      };
    default:
      // Default to read-only if role is unknown
      return {
        canRead: true,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
        canManageUsers: false,
        canClearData: false,
        canManageSettings: false,
        canAccessInventory: false,
        canDeleteOperationalItems: false,
        canEditReadyDespOperations: false
      };
  }
}

// Check if user can access inventory based on designation only
function canUserAccessInventory(user: any): boolean {
  if (!user) return false;
  
  // Allow access if user is admin or super-admin
  if (user.role === 'admin' || user.role === 'super-admin') {
    return true;
  }
  
  // Check designation - ONLY allow access to director, head, manager
  const allowedDesignations = ['director', 'head', 'manager'];
  if (user.designation) {
    const designation = user.designation.toLowerCase();
    // Use exact match or check if word begins with the allowed designation
    if (allowedDesignations.some(allowed => 
      designation === allowed || 
      designation.startsWith(allowed + ' ') || 
      designation.includes(' ' + allowed)
    )) {
      return true;
    }
  }
  
  return false;
}

// Check if user can delete operational items based on designation
function canUserDeleteOperationalItems(user: any): boolean {
  if (!user) return false;
  
  // Allow access if user is admin or super-admin
  if (user.role === 'admin' || user.role === 'super-admin') {
    return true;
  }
  
  // Check designation - ONLY allow deletion to director, head, manager, supervisor
  const allowedDesignations = ['director', 'head', 'manager', 'supervisor'];
  if (user.designation) {
    const designation = user.designation.toLowerCase();
    
    // Explicitly exclude assistant designation
    if (designation === 'assistant' || designation.includes('assistant')) {
      return false;
    }
    
    // Use exact match or check if word begins with the allowed designation
    if (allowedDesignations.some(allowed => 
      designation === allowed || 
      designation.startsWith(allowed + ' ') || 
      designation.includes(' ' + allowed)
    )) {
      return true;
    }
  }
  
  return false;
}

// Function to check if a role is admin or super-admin
export function isAdminOrSuperAdmin(role: string): boolean {
  return role === 'admin' || role === 'super-admin';
}

// Get current user permissions
export function getCurrentUserPermissions(): Permissions {
  try {
    const currentUserStr = localStorage.getItem('currentUser');
    if (!currentUserStr) {
      return getPermissionsForRole(); // Default permissions if no user
    }
    
    const currentUser = JSON.parse(currentUserStr);
    const basePermissions = getPermissionsForRole(currentUser.role);
    
    // Check if user can access inventory based on designation only
    const canAccessInventory = canUserAccessInventory(currentUser);
    
    // Check if user can delete operational items based on designation
    const canDeleteOperationalItems = canUserDeleteOperationalItems(currentUser);
    
    // Check if user can edit operations with READY≈DESP status
    // Only admin and super-admin can edit these operations
    const canEditReadyDespOperations = currentUser.role === 'admin' || currentUser.role === 'super-admin';
    
    return {
      ...basePermissions,
      canAccessInventory,
      canDeleteOperationalItems,
      canEditReadyDespOperations
    };
  } catch (error) {
    console.error('Error getting current user permissions:', error);
    return getPermissionsForRole(); // Default permissions on error
  }
}